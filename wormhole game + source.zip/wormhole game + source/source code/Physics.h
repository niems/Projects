#ifndef PHYSICS_H
#define PHYSICS_H

#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
using namespace std;

class Physics
{
private:
	bool condition1;
	bool condition2;
	bool condition3;
	bool condition4;



public:
	
	bool collisionDetection(sf::Vector2f &position1, sf::Vector2f &position1_dimensions, sf::Vector2f &position2, sf::Vector2f &position2_dimensions);
	bool offScreen(sf::Vector2f &object_position, sf::Vector2f &object_image_dimensions, sf::Vector2f &camera_view, sf::RenderWindow &App);	//if the object goes off the screen, return true.

};

#endif
