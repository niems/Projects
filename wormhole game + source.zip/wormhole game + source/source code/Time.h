#ifndef	TIME_H
#define TIME_H

#include <SFML\Graphics.hpp>

class Time
{
private:
	sf::Clock clock;
	bool paused;	//if true, clock.getElapsedTime() isn't added to 'time'. When it's unpaused after being paused, make sure to reset the sf::Clock clock;
	float time;		//this is what is returned

public:	
	Time() { paused = false; time = 0; }
	float GetElapsedTime() { return( time );  }		//returns the elapsed time
	void Reset()  { clock.Reset(); time = 0;  }		//resets the timer
	void Pause()  { paused = true; }				//the elapsed time of the clock isn't added to the 'time'
	void Resume() { paused = false; clock.Reset(); }//unpauses the clock, resuming adding the clock.getElapsedTime to 'time'

	void Update()
	{
		if( paused == false )
		{
			time += clock.GetElapsedTime();
			clock.Reset();
		}
	}
};


#endif
