#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <ctime>	//for rand()
#include <cmath>
#include <vector>
#include <iomanip>
#include <fstream>
#include <string>
#include <iostream>
#include "Animation.h"
#include "Physics.h"
#include "Health.h"
#include "Time.h"


using namespace std;

int main()
{
	Time clocked;
	srand( time(0) );
	sf::Font font;
	string string_temp = "";
	char temp_storage[5];
	sf::String music_control_string;
	sf::String music_volume_string;
	sf::String sound_fx_control_string;
	sf::String sound_fx_volume_string;
	sf::Music background_music;
	sf::Clock music_display_clock;
	sf::Clock music_clock;
	sf::Clock sound_fx_clock;
	int music_volume = 10;
	int sound_fx_volume = 30;
	bool music_control = false;	//if 'm' is pressed, this will be set to true and you will be able to change the volume of the music
	bool sound_fx_control = false;	//if 'f' is pressed, this will be set to true and you will be able to change the volume of the sound fx
	unsigned int highest_level_survival_mode = 0;
	unsigned int highest_level_normal_mode = 0;
	unsigned int most_enemies_survival_mode = 0;
	unsigned int most_enemies_normal_mode = 0;
	Physics collisions;	//used for collision detection
	sf::RenderWindow App( sf::VideoMode(900, 600, 32), "Wormh0le  :  By Zach Niemann" );
	sf::Clock clock;
	float SCREEN_W = App.GetWidth();
	float SCREEN_H = App.GetHeight();


	if( !font.LoadFromFile("fonts\\leadcoat.ttf") )
	{
		cout << "Failed to load font." << endl;
		App.Close();
	}

	music_control_string.SetFont( font );
	music_control_string.SetSize( 30 );
	music_control_string.SetText("Music Control: OFF");
	music_control_string.SetPosition( SCREEN_W / 3, 10 );
	
	music_volume_string.SetFont( font );
	music_volume_string.SetSize( 30 );
	music_volume_string.SetPosition( SCREEN_W / 3, 10 );
	itoa(music_volume, temp_storage, 10);
	string_temp = temp_storage;

	music_volume_string.SetText( "Music Volume: " + string_temp );

	sound_fx_control_string.SetFont( font );
	sound_fx_control_string.SetSize( 30 );
	sound_fx_control_string.SetText("Sound FX Control: OFF");
	sound_fx_control_string.SetPosition( SCREEN_W / 3, 10 );

	sound_fx_volume_string.SetFont( font );
	sound_fx_volume_string.SetSize( 30 );
	sound_fx_volume_string.SetPosition( SCREEN_W / 3, 10 );
	itoa(sound_fx_volume, temp_storage, 10);
	string_temp = temp_storage;

	sound_fx_volume_string.SetText( "Sound FX Volume: " + string_temp );


	if( !background_music.OpenFromFile("music\\background_music.ogg") )
	{
		cout << "Failed to load background music" << endl;
	}

	background_music.SetVolume( music_volume );
	background_music.Play();
	background_music.SetLoop(true);
	
	ifstream config_file("config.txt");	//used for the screen resolution

	if( config_file.fail() )	//failed to open the file
	{
		cout << "Failed to load the config file." << endl;
		App.Close();
	}

	config_file >> SCREEN_W;
	config_file >> SCREEN_H;
	

	ifstream config_file2("config2.txt");	//used for the high scores

	if( config_file2.fail() )	//the file failed to open
	{
		cout << "Failed to load config file 2" << endl;
		App.Close();
	}

	//gets the high scores from the file
	config_file2 >> highest_level_normal_mode;
	config_file2 >> most_enemies_normal_mode;
	config_file2 >> highest_level_survival_mode;
	config_file2 >> most_enemies_survival_mode;
	config_file2.close();


	if( SCREEN_W == 0 && SCREEN_H == 0 )
	{
		App.Create( sf::VideoMode( 800, 600, 32 ), "Wormhole  :  By Zach Niemann", sf::Style::Fullscreen );
	}

	else
	{
		App.Create( sf::VideoMode( SCREEN_W, SCREEN_H, 32 ), "Wormhole  :  By Zach Niemann" );
	}


	////////////////////////////////////////////////////////////////////////////////////////
	//Sound setup
	sf::Clock enemy_follow_sound_clock;		//checks to see if it's been long enough for the follow enemy to say something
	float enemy_follow_sound_limit = 5.0;	//allows the follow enemy to say something no more often than every 5 seconds.
	int enemy_follow_sound_count = 3;		//number of sounds the cycle through
	vector<sf::Sound> enemy_follow_sounds;	//stores all the sounds for the enemy to cycle through

	sf::SoundBuffer enemy_spawn_buffer;
	sf::SoundBuffer explosion_buffer;
	sf::SoundBuffer click_buffer;
	sf::SoundBuffer ship_selection_buffer;
	sf::SoundBuffer come_closer_buffer;
	sf::SoundBuffer you_cannot_hide_buffer;
	sf::SoundBuffer you_will_not_escape_buffer;
	sf::SoundBuffer time_to_die_buffer;

	sf::Sound enemy_spawn_sound;
	sf::Sound explosion_sound;
	sf::Sound click_sound;
	sf::Sound ship_selection_sound;
	sf::Sound come_closer_sound;
	sf::Sound you_cannot_hide_sound;
	sf::Sound you_will_not_escape_sound;
	sf::Sound time_to_die_sound;

	if( !enemy_spawn_buffer.LoadFromFile("sounds\\warp.wav") )
	{
		cout << "Failed to load enemy spawn sound." << endl;
		App.Close();
	}

	enemy_spawn_sound.SetBuffer( enemy_spawn_buffer );
	enemy_spawn_sound.SetVolume( sound_fx_volume + 10 );


	if( !explosion_buffer.LoadFromFile("sounds\\explosion.wav") )
	{
		cout << "Failed to load explosion sound." << endl;
		App.Close();
	}

	explosion_sound.SetBuffer( explosion_buffer );
	explosion_sound.SetVolume( sound_fx_volume );
	
	if( !click_buffer.LoadFromFile("sounds\\click_sound.wav") )
	{
		cout << "Failed to load click sound." << endl;
		App.Close();
	}

	click_sound.SetBuffer( click_buffer );


	if( !ship_selection_buffer.LoadFromFile("sounds\\ship_choose2.wav") )
	{
		cout << "Failed to load ship selection sound." << endl;
		App.Close();
	}

	ship_selection_sound.SetBuffer( ship_selection_buffer );
	ship_selection_sound.SetVolume( 100 );

	if( !come_closer_buffer.LoadFromFile("sounds\\come_closer2.wav") )
	{
		cout << "Failed to load 'come closer' sound." << endl;
		App.Close();
	}

	come_closer_sound.SetBuffer( come_closer_buffer );
	come_closer_sound.SetVolume(100);
	enemy_follow_sounds.push_back( come_closer_sound );


	if( !you_cannot_hide_buffer.LoadFromFile("sounds\\you_cannot_hide2.wav") )
	{
		cout << "Failed to load 'you cannot hide' sound." << endl;
		App.Close();
	}

	you_cannot_hide_sound.SetBuffer( you_cannot_hide_buffer );
	you_cannot_hide_sound.SetVolume( 100 );
	enemy_follow_sounds.push_back( you_cannot_hide_sound );


	if( !time_to_die_buffer.LoadFromFile("sounds\\time_to_die.wav") )
	{
		cout << "Failed to load 'time to die' sound." << endl;
		App.Close();
	}

	time_to_die_sound.SetBuffer( time_to_die_buffer );
	time_to_die_sound.SetVolume( 100 );

	if( !you_will_not_escape_buffer.LoadFromFile("sounds\\you_will_not_escape2.wav") )
	{
		cout << "Failed to load 'you will not escape' sound." << endl;
		App.Close();
	}

	you_will_not_escape_sound.SetBuffer( you_will_not_escape_buffer );
	you_will_not_escape_sound.SetVolume( 100 );
	enemy_follow_sounds.push_back( you_will_not_escape_sound );

	//end sound setup
	//////////////////////////////////////////////////////////////////////////////////////////


	//////////////////////////////////////////////
	//background setup
	sf::Image background_image;
	sf::Sprite background_sprite;

	if( !background_image.LoadFromFile("images\\space3.png") )
	{
		cout << "Failed to load background image." << endl;
		App.Close();
	}

	background_sprite.SetImage( background_image );
	background_sprite.Resize( SCREEN_W, SCREEN_H );
	//end background setup
	////////////////////////////////////////////

	////////////////////////////////////////////
	//level setup
	Animation wormhole_animation;		//this will be created and  updated every level once the countdown reaches 0.
	bool level_complete = false;	//if true, that means the player finished the level by getting to the wormhole
	bool survival_mode = false;		//if true, the player's health is not restored once completing a level
	sf::Clock wormhole_clock;
	sf::Image wormhole_image;
	sf::Sprite wormhole_sprite;
	sf::Vector2f wormhole_temp_position(SCREEN_W / 2, SCREEN_H / 2);	//where the wormhole is created
	float wormhole_row_sprites = 1;
	float wormhole_column_sprites = 22;
	float wormhole_animation_limit = 0.05;
	float wormhole_width = 0;
	float wormhole_height = 0;
	
	if( !wormhole_image.LoadFromFile("images\\blackhole90.png") )
	{
		cout << "Failed to load wormhole image." << endl;
		App.Close();
	}

	wormhole_image.CreateMaskFromColor( sf::Color(255, 0, 255) );
	wormhole_sprite.SetImage( wormhole_image );
	wormhole_sprite.SetCenter( wormhole_image.GetWidth() / 2, wormhole_image.GetHeight() / 2 );
	wormhole_sprite.SetPosition( ( ( SCREEN_W - 290 ) + 280 ) / 2, (SCREEN_H / 2.5) + ( (wormhole_image.GetHeight() / wormhole_row_sprites) / 1.5 ) );

	wormhole_width = wormhole_image.GetWidth() / wormhole_column_sprites;
	wormhole_height = wormhole_image.GetHeight() / wormhole_row_sprites;
	//wormhole_animation.initializeCoordinates(wormhole_row_sprites, wormhole_column_sprites, wormhole_animation_limit, sf::Vector2f( wormhole_image.GetWidth(), wormhole_image.GetHeight() ), 0, wormhole_sprite, wormhole_temp_position );

	sf::String game_paused_string;		//displayed when the game is paused.
	sf::Clock pause_clock;		//used to see if it's been long enough to toggle if the game is paused
	bool game_paused = false;	//if true, the game is paused
	const int COUNTDOWN_TIME = 35;
	int level = 1;	//current level, after the countdown is met, level is incremented
	int countdown = COUNTDOWN_TIME;	//each level lasts this many seconds.
	sf::Clock countdown_clock;	//keeps track of how much time has elaped to determine if the player has finished the level
	sf::String countdown_string;	//displays the countdown timer
	sf::String level_string;		//displays the level
	sf::String life_string;			//displays the player's life
	sf::String number_of_enemies_string;	//displays the number of enemies on the screen
	sf::String start_game_countdown_string;		//displays the number of seconds before the game starts

	//level text setup
	string level_base_text = "Level: ";
	string current_level_text = "";
	itoa(level, temp_storage, 10);
	current_level_text = temp_storage;

	level_string.SetText( level_base_text + current_level_text );
	level_string.SetFont( font );
	level_string.SetSize( 25 );
	level_string.SetPosition(SCREEN_W - 100, 10.0);

	//countdown text setup
	string countdown_base_text = "Wormhole in: ";
	string current_countdown_text = "";
	itoa(countdown, temp_storage, 10);
	current_countdown_text = temp_storage;

	countdown_string.SetText( countdown_base_text + current_countdown_text );
	countdown_string.SetFont( font );
	countdown_string.SetSize( 25 );
	countdown_string.SetPosition(5.0, 10.0);


	//number of enemies setup
	string number_of_enemies_base_text = "Number of enemies: ";
	string current_number_of_enemies_text = "";

	number_of_enemies_string.SetFont( font );
	number_of_enemies_string.SetSize( 25 );
	number_of_enemies_string.SetPosition( SCREEN_W - 260, SCREEN_H - 50 );

	//life setup
	string current_life_text = "";
	string base_life_text = " / 100";

	life_string.SetFont( font );
	life_string.SetSize( 25 );
	life_string.SetPosition( 10.0, SCREEN_H - 50 );

	//start game text setup
	string start_game_countdown_text = "";
	start_game_countdown_string.SetText("");
	start_game_countdown_string.SetSize( 70 );
	start_game_countdown_string.SetPosition( SCREEN_W / 2.15, SCREEN_H / 2.15 );
	start_game_countdown_string.SetColor( sf::Color(255, 0, 0) );

	itoa(countdown - 30, temp_storage, 10);
	start_game_countdown_text = temp_storage;
	start_game_countdown_string.SetText( start_game_countdown_text );


	//game paused text setup
	game_paused_string.SetText("Paused");
	game_paused_string.SetFont( font );
	game_paused_string.SetSize( 60 );
	game_paused_string.SetPosition( (SCREEN_W / 2) - 83, (SCREEN_H / 2) - 40 );


	//end level setup
	////////////////////////////////////////////

	//////////////////////////////////////////////
	//start screen setup
	bool start_game = false;				//if true, the game starts, otherwise it stays on the starting screen
	bool screen_resolution_menu = false;	//if true, the screen resolutions are displayed and the player can choose one
	bool game_mechanics_menu = false;		//if true, the game mechanics are displayed
	bool game_mode_menu = false;			//if true, game modes are displayed

	sf::Vector2f mouse_position;			//used to store the mouse position
	sf::Clock start_game_clock;				//used to determine
	sf::String start_game_string;
	sf::String screen_resolution_string;
	sf::String screen_resolution_800_600_string;
	sf::String screen_resolution_1024_768_string;
	sf::String screen_resolution_1280_800_string;
	sf::String screen_resolution_1280_1024_string;
	sf::String screen_resolution_1680_1050_string;
	sf::String screen_resolution_1920_1080_string;
	sf::String game_mechanics_string;
	sf::String game_mechanics_options1_string;
	sf::String game_mechanics_options2_string;
	sf::String game_mechanics_options3_string;
	sf::String game_mechanics_options4_string;
	sf::String game_mechanics_options5_string;
	sf::String game_mechanics_options6_string;
	sf::String game_mode_string;	//if the player is going to play the game in normal mode or survival mode(health is not restored after completing a level).
	sf::String game_mode_option1_string;
	sf::String game_mode_option2_string;
	sf::String highest_level_string;
	sf::String most_enemies_string;
	sf::String game_tip1_string;
	sf::String game_tip2_string;
	sf::String game_tip3_string;
	

	float default_menu_x = 5.0;	//where the default menu starts
	float game_mechanics_x = SCREEN_W - 290;
	float screen_resolution_options_x = 10.0;
	float game_mechanics_options_x = SCREEN_W - 285;

	start_game_string.SetText("Start Game");
	start_game_string.SetFont( font );
	start_game_string.SetSize( 40 );
	start_game_string.SetPosition( default_menu_x, SCREEN_H / 5 );

	screen_resolution_string.SetText("Screen Resolution");
	screen_resolution_string.SetFont( font );
	screen_resolution_string.SetSize( 40 );
	screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );

	screen_resolution_800_600_string.SetText("800 x 600");
	screen_resolution_800_600_string.SetFont( font );
	screen_resolution_800_600_string.SetSize( 28 );
	screen_resolution_800_600_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.8);

	screen_resolution_1024_768_string.SetText("1024 x 768");
	screen_resolution_1024_768_string.SetFont( font );
	screen_resolution_1024_768_string.SetSize( 28 );
	screen_resolution_1024_768_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.6 );

	screen_resolution_1280_800_string.SetText("1280 X 800");
	screen_resolution_1280_800_string.SetFont( font );
	screen_resolution_1280_800_string.SetSize( 28 );
	screen_resolution_1280_800_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.45 );

	screen_resolution_1280_1024_string.SetText("1280 x 1024");
	screen_resolution_1280_1024_string.SetFont( font );
	screen_resolution_1280_1024_string.SetSize( 28 );
	screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
	screen_resolution_1280_1024_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.3 );

	screen_resolution_1680_1050_string.SetText("1680 X 1050");
	screen_resolution_1680_1050_string.SetFont( font );
	screen_resolution_1680_1050_string.SetSize( 28 );
	screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
	screen_resolution_1680_1050_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.17 );

	screen_resolution_1920_1080_string.SetText("1920 x 1080");
	screen_resolution_1920_1080_string.SetFont( font );
	screen_resolution_1920_1080_string.SetSize( 28 );
	screen_resolution_1920_1080_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.07 );
	

	game_mechanics_string.SetText("Game Mechanics");
	game_mechanics_string.SetFont( font );
	game_mechanics_string.SetSize( 40 );
	game_mechanics_string.SetPosition( game_mechanics_x, SCREEN_H / 2.2 );

	game_mechanics_options1_string.SetText("-W,A,S,D to move the player");
	game_mechanics_options1_string.SetFont( font );
	game_mechanics_options1_string.SetSize( 25 );
	game_mechanics_options1_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.8 );

	game_mechanics_options2_string.SetText("-SHIFT to move faster");
	game_mechanics_options2_string.SetFont( font );
	game_mechanics_options2_string.SetSize( 25 );
	game_mechanics_options2_string.SetPosition( game_mechanics_options_x,  SCREEN_H / 1.6 );

	game_mechanics_options3_string.SetText("-30 seconds per level");
	game_mechanics_options3_string.SetFont( font );
	game_mechanics_options3_string.SetSize( 25 );
	game_mechanics_options3_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.45 );

	game_mechanics_options4_string.SetText("-Get to the wormhole");
	game_mechanics_options4_string.SetFont( font );
	game_mechanics_options4_string.SetSize( 25 );
	game_mechanics_options4_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.3 );

	game_mechanics_options5_string.SetText("-Warning : Don't stand still!");
	game_mechanics_options5_string.SetFont( font );
	game_mechanics_options5_string.SetSize( 25 );
	game_mechanics_options5_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.07 );

	game_mechanics_options6_string.SetText("-ESCAPE to pause game");
	game_mechanics_options6_string.SetFont( font );
	game_mechanics_options6_string.SetSize( 25 );
	game_mechanics_options6_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.17 );


	game_mode_string.SetText("Game Mode: Normal");
	game_mode_string.SetFont( font );
	game_mode_string.SetSize( 40 );
	game_mode_string.SetPosition( game_mechanics_x - 30, SCREEN_H / 5 );
	
	game_mode_option1_string.SetText("-Normal");
	game_mode_option1_string.SetFont( font );
	game_mode_option1_string.SetSize( 32 );
	game_mode_option1_string.SetPosition( game_mechanics_x - 25, (SCREEN_H / 5) + 60 );

	game_mode_option2_string.SetText("-Survival");
	game_mode_option2_string.SetFont( font );
	game_mode_option2_string.SetSize( 32 );
	game_mode_option2_string.SetPosition( SCREEN_W - 120, (SCREEN_H / 5) + 60 );


	string highest_level_temp = "";
	highest_level_string.SetFont( font );
	highest_level_string.SetSize( 25 );
	highest_level_string.SetPosition( 15, 10 );

	if( highest_level_normal_mode != 0 )
	{
		itoa( highest_level_normal_mode, temp_storage, 10 );
		highest_level_temp = temp_storage;
		highest_level_string.SetText("Highest level reached: " + highest_level_temp );
	}

	else
	{
		highest_level_string.SetText("Highest level reached: N/A");
	}


	string most_enemies_temp = "";
	most_enemies_string.SetFont( font );
	most_enemies_string.SetSize( 25 );
	most_enemies_string.SetPosition( SCREEN_W - 300, 10 );
	
	
	if( most_enemies_normal_mode != 0 )
	{
		itoa( most_enemies_normal_mode, temp_storage, 10 );
		most_enemies_temp = temp_storage;
		most_enemies_string.SetText("Most enemies on screen: " + most_enemies_temp );
	}

	else
	{
		most_enemies_string.SetText( "Most enemies on screen: N/A" );
	}


	game_tip1_string.SetText("-Ships regenerate health every two waves");
	game_tip1_string.SetFont( font );
	game_tip1_string.SetSize( 25 );
	game_tip1_string.SetPosition( 15, SCREEN_H / 1.7 );

	game_tip2_string.SetText("-(Normal Mode): Restores health upon level completion");
	game_tip2_string.SetFont( font );
	game_tip2_string.SetSize( 25 );
	game_tip2_string.SetPosition( 15, SCREEN_H / 1.45 );

	game_tip3_string.SetText("-(Survival Mode): Does not restore health upon level completion");
	game_tip3_string.SetFont( font );
	game_tip3_string.SetSize( 25 );
	game_tip3_string.SetPosition( 15, SCREEN_H / 1.25 );

	//creates enemies for the background of the menu screen
	//START HERE
	Animation enemy_startscreen_animation;
	Animation enemy_startscreen_warp_animation;
	sf::Clock enemy_startscreen_clock;
	sf::Image background_startscreen_image;
	sf::Image enemy_startscreen_image;
	sf::Image enemy_startscreen_warp_image;
	sf::Sprite background_startscreen_sprite;
	sf::Sprite enemy_startscreen_sprite;
	sf::Sprite enemy_startscreen_warp_sprite;
	vector<sf::Vector2f> enemy_startscreen_position;
	vector<sf::Vector2f> enemy_startscreen_speed;
	const float enemy_startscreen_row_sprites = 1;
	const float enemy_startscreen_warp_row_sprites = 1;
	const float enemy_startscreen_column_sprites = 6;
	const float enemy_startscreen_warp_column_sprites = 15;
	float enemy_startscreen_animation_limit = 0.1;
	float enemy_startscreen_warp_animation_limit = 0.025;
	int startscreen_number_of_enemies = 20;

	if( !background_startscreen_image.LoadFromFile("images\\space3.png") )
	{
		cout << "Failed to load background startscreen image." << endl;
		App.Close();
	}

	background_startscreen_sprite.SetImage( background_startscreen_image );
	background_startscreen_sprite.Resize( SCREEN_W, SCREEN_H );

	if( !enemy_startscreen_image.LoadFromFile("images\\power_ball.png") )
	{
		cout << "Failed to load enemy startscreen image." << endl;
		App.Close();
	}

	enemy_startscreen_image.CreateMaskFromColor( sf::Color(255, 0, 255) );
	enemy_startscreen_sprite.SetImage( enemy_startscreen_image );

	const float enemy_startscreen_width = enemy_startscreen_image.GetWidth() / enemy_startscreen_column_sprites;
	const float enemy_startscreen_height = enemy_startscreen_image.GetHeight() / enemy_startscreen_row_sprites;

	if( !enemy_startscreen_warp_image.LoadFromFile("images\\warp_inverted.png") )
	{
		cout << "Failed to load enemy startscreen warp image." << endl;
		App.Close();
	}

	enemy_startscreen_warp_image.CreateMaskFromColor( sf::Color(255, 0, 255) );
	enemy_startscreen_warp_sprite.SetImage( enemy_startscreen_warp_image );

	const float enemy_startscreen_warp_width = enemy_startscreen_warp_image.GetWidth() / enemy_startscreen_warp_column_sprites;
	const float enemy_startscreen_warp_height = enemy_startscreen_warp_image.GetHeight() / enemy_startscreen_warp_row_sprites;


	App.Draw( background_startscreen_sprite );
	App.Draw( start_game_string );
	App.Draw( screen_resolution_string );
	App.Display();
	
		for(int i = 0; i < startscreen_number_of_enemies; i++)	//creates enemies for the background menu
	{
		//ALSO PUT WARP IN ANIMATION HERE.
		//creates the animation for the current enemy, along with it's warp in position and speed.
		enemy_startscreen_animation.initializeStandard( enemy_startscreen_row_sprites, enemy_startscreen_column_sprites, enemy_startscreen_animation_limit, sf::Vector2f( enemy_startscreen_image.GetWidth(), enemy_startscreen_image.GetHeight() ), 0, enemy_startscreen_sprite );
		enemy_startscreen_position.push_back( sf::Vector2f( rand() % static_cast<int>(SCREEN_W - enemy_startscreen_width - 5), rand() % static_cast<int>(SCREEN_H - enemy_startscreen_height - 5) ) );
		enemy_startscreen_speed.push_back( sf::Vector2f( rand() % static_cast<int>(SCREEN_W / 8) + 100, rand() % static_cast<int>(SCREEN_H / 8) + 100 ) );

		enemy_startscreen_warp_animation.initializeCoordinates( enemy_startscreen_warp_row_sprites, enemy_startscreen_warp_column_sprites, enemy_startscreen_warp_animation_limit, sf::Vector2f( enemy_startscreen_warp_image.GetWidth(), enemy_startscreen_warp_image.GetHeight() ), 0, enemy_startscreen_warp_sprite, sf::Vector2f(enemy_startscreen_position.back().x - enemy_startscreen_width, enemy_startscreen_position.back().y - enemy_startscreen_height) );
		enemy_startscreen_warp_animation.setCurrentlyAnimating(true);

		if( i == (startscreen_number_of_enemies - 1) )	//last iteration
		{
			enemy_spawn_sound.Play();
		}
	}

	while( start_game == false && App.IsOpened() )
	{ 
		sf::Event e;

		while( App.GetEvent( e ) )
		{
			if( e.Type == sf::Event::Closed || (e.Type == sf::Event::KeyPressed && e.Key.Code == sf::Key::Escape) )
			{
				App.Close();
			}

		}

		/*
		if( start_game_clock.GetElapsedTime() >= 0.1 )
		{
			cout << "Screen width: " << SCREEN_W - 290 << endl;
			cout << "Screen height: " << SCREEN_H / 2.0 << endl;
			cout << "X: " << App.GetInput().GetMouseX() << endl;
			cout << "Y: " << App.GetInput().GetMouseY() << endl << endl;

			start_game_clock.Reset();
		}
		*/

		if( App.GetInput().IsMouseButtonDown( sf::Mouse::Left ) && start_game_clock.GetElapsedTime() >= 0.5 )	//if the player presses the left mouse button down
		{
			start_game_clock.Reset();

			//gets the current mouse position
			mouse_position.x = App.GetInput().GetMouseX();
			mouse_position.y = App.GetInput().GetMouseY();

			//start game position
			if( mouse_position.x >= default_menu_x && mouse_position.x <= ( default_menu_x + 236 ) && mouse_position.y >= (SCREEN_H / 5) && mouse_position.y <= ( (SCREEN_H / 5) + 55 ) )
			{
				start_game = true;	//starts the game
				click_sound.Play();
			}

			//screen resolution position
			else if( mouse_position.x >= default_menu_x && mouse_position.x <= ( default_menu_x + 335 ) && mouse_position.y >= (SCREEN_H / 2.2) && mouse_position.y <= ( (SCREEN_H / 2.2) + 50) )
			{
				if( screen_resolution_menu == false )
				{
					screen_resolution_menu = true;
					click_sound.Play();
				}

				else
				{
					screen_resolution_menu = false;	//reset
					click_sound.Play();
				}
			}

			//game mechanics position
			else if( mouse_position.x >= game_mechanics_x && mouse_position.x <= ( game_mechanics_x + 280 ) && mouse_position.y >= ( SCREEN_H / 2.2 ) && mouse_position.y <= ( (SCREEN_H / 2.2) + 50) )
			{
				if( game_mechanics_menu == false )
				{
					game_mechanics_menu = true;	//display the game mechanics
					click_sound.Play();
				}

				else
				{
					game_mechanics_menu = false;	//don't display the game mechanics
					click_sound.Play();
				}

			}

			//game mode position
			else if( mouse_position.x >= ( SCREEN_W - 290 ) && mouse_position.x <= SCREEN_W && mouse_position.y >= (SCREEN_H / 5) && mouse_position.y <= ( (SCREEN_H / 5) + 55 ) )
			{
				if( game_mode_menu == false )
				{
					game_mode_menu = true;	//display the game mode menu
					click_sound.Play();
				}

				else
				{
					game_mode_menu = false;	//don't display the game mode menu
					click_sound.Play();
				}
			}

			//game mode positions
			if( game_mode_menu == true )
			{
				//normal game mode
				if( mouse_position.x >= ( game_mechanics_x - 25 ) && mouse_position.x <= ( game_mechanics_x + 95 ) && mouse_position.y >= (SCREEN_H / 5) + 60 && mouse_position.y <= (SCREEN_H / 5) + 100 )
				{
					survival_mode = false;	//the player isn't playing survival mode, so their health is restored upon completing a level
					game_mode_string.SetText("Game Mode: Normal");
					click_sound.Play();

					//resets high score text
					if( highest_level_normal_mode != 0 )
					{
						itoa( highest_level_normal_mode, temp_storage, 10 );
						highest_level_temp = temp_storage;
						highest_level_string.SetText( "Highest level reached: " + highest_level_temp );
					}

					else
					{
						highest_level_string.SetText( "Highest level reached: N/A" );
					}

					if( most_enemies_normal_mode != 0 )
					{
						itoa( most_enemies_normal_mode, temp_storage, 10 );
						most_enemies_temp = temp_storage;
						most_enemies_string.SetText( "Most enemies on screen: " + most_enemies_temp );
					}

					else
					{
						most_enemies_string.SetText( "Most enemies on screen: N/A" );
					}
				}

				else if( mouse_position.x >= ( SCREEN_W - 120 ) && mouse_position.x <= SCREEN_W && mouse_position.y >= (SCREEN_H / 5) + 60 && mouse_position.y <= (SCREEN_H / 5) + 100 )
				{
					survival_mode = true;	//the player is playing in survival mode, so their health isn't restored upon completing a level
					game_mode_string.SetText("Game Mode: Survival");
					click_sound.Play();

					if( highest_level_survival_mode != 0 )
					{
						itoa( highest_level_survival_mode, temp_storage, 10 );
						highest_level_temp = temp_storage;
						highest_level_string.SetText( "Highest level reached: " + highest_level_temp );
					}

					else
					{
						highest_level_string.SetText( "Highest level reached: N/A" );
					}

					if( most_enemies_survival_mode != 0 )
					{
						itoa( most_enemies_survival_mode, temp_storage, 10 );
						most_enemies_temp = temp_storage;
						most_enemies_string.SetText( "Most enemies on screen: " + most_enemies_temp );
					}

					else
					{
						most_enemies_string.SetText( "Most enemies on screen: N/A" );
					}
				}


			}

			//SCREEN RESOLUTION POSITIONS
			if( screen_resolution_menu == true )
			{
				//800x600
				if( mouse_position.x >= ( screen_resolution_options_x - 10 ) && mouse_position.x <= ( screen_resolution_options_x + 115 ) && mouse_position.y >= (SCREEN_H / 1.8) && mouse_position.y <= ( (SCREEN_H / 1.8) + 30) )
				{
					click_sound.Play();

					//writes the new screen resolution to the file
					ofstream output_file("config.txt");
					output_file << 800 << endl;
					output_file << 600 << endl;
					output_file.close();	//closes the file

					App.Create( sf::VideoMode( 800, 600, 32 ), "Wormhole  :  By Zach Niemann" );	//creates the new size for the screen
					SCREEN_W = App.GetWidth();
					SCREEN_H = App.GetHeight();

					game_mechanics_options_x = SCREEN_W - 285;
					game_mechanics_x = SCREEN_W - 290;

					wormhole_sprite.SetPosition( ( ( SCREEN_W - 290 ) + 280 ) / 2, (SCREEN_H / 2.5) + ( (wormhole_image.GetHeight() / wormhole_row_sprites) / 1.5 ) );

					background_sprite.Resize( SCREEN_W, SCREEN_H );	//resize the background image
					background_startscreen_sprite.Resize( SCREEN_W, SCREEN_H );

					wormhole_temp_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//where the wormhole is created

					//reset all of the menu positions
					start_game_string.SetPosition( default_menu_x, SCREEN_H / 5 );
					screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
					screen_resolution_800_600_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.8);
					screen_resolution_1024_768_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.6 );
					screen_resolution_1280_800_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.45 );
					screen_resolution_1280_1024_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.3 );
					screen_resolution_1680_1050_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.17 );
					screen_resolution_1920_1080_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.07 );
					game_mechanics_string.SetPosition( game_mechanics_x, SCREEN_H / 2.2 );
					game_mechanics_options1_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.8 );
					game_mechanics_options2_string.SetPosition( game_mechanics_options_x,  SCREEN_H / 1.6 );
					game_mechanics_options3_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.45 );
					game_mechanics_options4_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.3 );
					game_mechanics_options5_string.SetPosition( game_mechanics_options_x - 25, SCREEN_H / 1.07 );
					game_mechanics_options6_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.17 );
					game_mode_string.SetPosition( game_mechanics_x - 30, SCREEN_H / 5 );
					game_mode_option1_string.SetPosition( game_mechanics_x - 25, (SCREEN_H / 5) + 60 );
					game_mode_option2_string.SetPosition( SCREEN_W - 120, (SCREEN_H / 5) + 60 );
					most_enemies_string.SetPosition( SCREEN_W - 300, 10 );
					highest_level_string.SetPosition( 15, 10 );
					game_tip1_string.SetPosition( 15, SCREEN_H / 1.7 );
					game_tip2_string.SetPosition( 15, SCREEN_H / 1.45 );
					game_tip3_string.SetPosition( 15, SCREEN_H / 1.25 );

					//reset game bars
					level_string.SetPosition(SCREEN_W - 100, 10.0);
					number_of_enemies_string.SetPosition( SCREEN_W - 260, SCREEN_H - 50 );
					life_string.SetPosition( 10.0, SCREEN_H - 50 );
					start_game_countdown_string.SetPosition( SCREEN_W / 2.15, SCREEN_H / 2.15 );
					sound_fx_control_string.SetPosition( SCREEN_W / 3, 10 );
					sound_fx_volume_string.SetPosition( SCREEN_W / 3, 10 );
					music_control_string.SetPosition( SCREEN_W / 3, 10 );
					music_volume_string.SetPosition( SCREEN_W / 3, 10 );
					game_paused_string.SetPosition( (SCREEN_W / 2) - 83, (SCREEN_H / 2) - 20 );

				}

				//1024x768
				else if( mouse_position.x >= ( screen_resolution_options_x - 10 ) && mouse_position.x <= ( screen_resolution_options_x + 125 ) && mouse_position.y >= (SCREEN_H / 1.6) && mouse_position.y <= ( (SCREEN_H / 1.6) + 30) )
				{
					click_sound.Play();
					//writes the new screen resolution to the file
					ofstream output_file("config.txt");
					output_file << 1024 << endl;
					output_file << 768 << endl;
					output_file.close();	//closes the file

					App.Create( sf::VideoMode( 1024, 768, 32 ), "Wormhole  :  By Zach Niemann" );	//creates the new size for the screen
					SCREEN_W = App.GetWidth();
					SCREEN_H = App.GetHeight();

					game_mechanics_options_x = SCREEN_W - 285;
					game_mechanics_x = SCREEN_W - 290;

					wormhole_sprite.SetPosition( ( ( SCREEN_W - 290 ) + 280 ) / 2, (SCREEN_H / 2.5) + ( (wormhole_image.GetHeight() / wormhole_row_sprites) / 1.5 ) );

					background_sprite.Resize( SCREEN_W, SCREEN_H );	//resize the background image
					background_startscreen_sprite.Resize( SCREEN_W, SCREEN_H );

					wormhole_temp_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//where the wormhole is created

					//reset all of the menu positions
					start_game_string.SetPosition( default_menu_x, SCREEN_H / 5 );
					screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
					screen_resolution_800_600_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.8);
					screen_resolution_1024_768_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.6 );
					screen_resolution_1280_800_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.45 );
					screen_resolution_1280_1024_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.3 );
					screen_resolution_1680_1050_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.17 );
					screen_resolution_1920_1080_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.07 );
					game_mechanics_string.SetPosition( game_mechanics_x, SCREEN_H / 2.2 );
					game_mechanics_options1_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.8 );
					game_mechanics_options2_string.SetPosition( game_mechanics_options_x,  SCREEN_H / 1.6 );
					game_mechanics_options3_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.45 );
					game_mechanics_options4_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.3 );
					game_mechanics_options5_string.SetPosition( game_mechanics_options_x - 25, SCREEN_H / 1.07 );
					game_mechanics_options6_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.17 );
					game_mode_string.SetPosition( game_mechanics_x - 30, SCREEN_H / 5 );
					game_mode_option1_string.SetPosition( game_mechanics_x - 25, (SCREEN_H / 5) + 60 );
					game_mode_option2_string.SetPosition( SCREEN_W - 120, (SCREEN_H / 5) + 60 );
					most_enemies_string.SetPosition( SCREEN_W - 300, 10 );
					highest_level_string.SetPosition( 15, 10 );
					game_tip1_string.SetPosition( 15, SCREEN_H / 1.7 );
					game_tip2_string.SetPosition( 15, SCREEN_H / 1.45 );
					game_tip3_string.SetPosition( 15, SCREEN_H / 1.25 );


					//reset game bars
					level_string.SetPosition(SCREEN_W - 100, 10.0);
					number_of_enemies_string.SetPosition( SCREEN_W - 260, SCREEN_H - 50 );
					life_string.SetPosition( 10.0, SCREEN_H - 50 );
					start_game_countdown_string.SetPosition( SCREEN_W / 2.15, SCREEN_H / 2.15 );
					sound_fx_control_string.SetPosition( SCREEN_W / 3, 10 );
					sound_fx_volume_string.SetPosition( SCREEN_W / 3, 10 );
					music_control_string.SetPosition( SCREEN_W / 3, 10 );
					music_volume_string.SetPosition( SCREEN_W / 3, 10 );
					game_paused_string.SetPosition( (SCREEN_W / 2) - 83, (SCREEN_H / 2) - 20 );

				}

				//1280x800
				else if( mouse_position.x >= ( screen_resolution_options_x - 10 ) && mouse_position.x <= ( screen_resolution_options_x + 125 ) && mouse_position.y >= (SCREEN_H / 1.45) && mouse_position.y <= ( (SCREEN_H / 1.45) + 30) )
				{
					click_sound.Play();

						//writes the new screen resolution to the file
					ofstream output_file("config.txt");
					output_file << 1280 << endl;
					output_file << 800 << endl;
					output_file.close();	//closes the file

					App.Create( sf::VideoMode( 1280, 800, 32 ), "Wormhole  :  By Zach Niemann" );	//creates the new size for the screen
					SCREEN_W = App.GetWidth();
					SCREEN_H = App.GetHeight();

					wormhole_sprite.SetPosition( ( ( SCREEN_W - 290 ) + 280 ) / 2, (SCREEN_H / 2.5) + ( (wormhole_image.GetHeight() / wormhole_row_sprites) / 1.5 ) );
					wormhole_temp_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//where the wormhole is created

					game_mechanics_options_x = SCREEN_W - 285;
					game_mechanics_x = SCREEN_W - 290;

					background_sprite.Resize( SCREEN_W, SCREEN_H );	//resize the background image
					background_startscreen_sprite.Resize( SCREEN_W, SCREEN_H );

					//reset all of the menu positions
					start_game_string.SetPosition( default_menu_x, SCREEN_H / 5 );
					screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
					screen_resolution_800_600_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.8);
					screen_resolution_1024_768_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.6 );
					screen_resolution_1280_800_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.45 );
					screen_resolution_1280_1024_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.3 );
					screen_resolution_1680_1050_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.17 );
					screen_resolution_1920_1080_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.07 );
					game_mechanics_string.SetPosition( game_mechanics_x, SCREEN_H / 2.2 );
					game_mechanics_options1_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.8 );
					game_mechanics_options2_string.SetPosition( game_mechanics_options_x,  SCREEN_H / 1.6 );
					game_mechanics_options3_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.45 );
					game_mechanics_options4_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.3 );
					game_mechanics_options5_string.SetPosition( game_mechanics_options_x - 25, SCREEN_H / 1.07 );
					game_mechanics_options6_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.17 );
					game_mode_string.SetPosition( game_mechanics_x - 30, SCREEN_H / 5 );
					game_mode_option1_string.SetPosition( game_mechanics_x - 25, (SCREEN_H / 5) + 60 );
					game_mode_option2_string.SetPosition( SCREEN_W - 120, (SCREEN_H / 5) + 60 );
					most_enemies_string.SetPosition( SCREEN_W - 300, 10 );
					highest_level_string.SetPosition( 15, 10 );
					game_tip1_string.SetPosition( 15, SCREEN_H / 1.7 );
					game_tip2_string.SetPosition( 15, SCREEN_H / 1.45 );
					game_tip3_string.SetPosition( 15, SCREEN_H / 1.25 );

					//reset game bars
					level_string.SetPosition(SCREEN_W - 100, 10.0);
					number_of_enemies_string.SetPosition( SCREEN_W - 260, SCREEN_H - 50 );
					life_string.SetPosition( 10.0, SCREEN_H - 50 );
					start_game_countdown_string.SetPosition( SCREEN_W / 2.15, SCREEN_H / 2.15 );
					sound_fx_control_string.SetPosition( SCREEN_W / 3, 10 );
					sound_fx_volume_string.SetPosition( SCREEN_W / 3, 10 );
					music_control_string.SetPosition( SCREEN_W / 3, 10 );
					music_volume_string.SetPosition( SCREEN_W / 3, 10 );
					game_paused_string.SetPosition( (SCREEN_W / 2) - 83, (SCREEN_H / 2) - 20 );

				}

				//1280x1024
				else if( mouse_position.x >= ( screen_resolution_options_x - 10 ) && mouse_position.x <= ( screen_resolution_options_x + 135 ) && mouse_position.y >= (SCREEN_H / 1.3) && mouse_position.y <= ( (SCREEN_H / 1.3) + 30) )
				{
					click_sound.Play();

						//writes the new screen resolution to the file
					ofstream output_file("config.txt");
					output_file << 1280 << endl;
					output_file << 1024 << endl;
					output_file.close();	//closes the file

					App.Create( sf::VideoMode( 1280, 1024, 32 ), "Wormhole  :  By Zach Niemann" );	//creates the new size for the screen
					SCREEN_W = App.GetWidth();
					SCREEN_H = App.GetHeight();

					wormhole_sprite.SetPosition( ( ( SCREEN_W - 290 ) + 280 ) / 2, (SCREEN_H / 2.5) + ( (wormhole_image.GetHeight() / wormhole_row_sprites) / 1.5 ) );
					wormhole_temp_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//where the wormhole is created

					game_mechanics_options_x = SCREEN_W - 285;
					game_mechanics_x = SCREEN_W - 290;

					background_sprite.Resize( SCREEN_W, SCREEN_H );	//resize the background image
					background_startscreen_sprite.Resize( SCREEN_W, SCREEN_H );

					//reset all of the menu positions
					start_game_string.SetPosition( default_menu_x, SCREEN_H / 5 );
					screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
					screen_resolution_800_600_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.8);
					screen_resolution_1024_768_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.6 );
					screen_resolution_1280_800_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.45 );
					screen_resolution_1280_1024_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.3 );
					screen_resolution_1680_1050_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.17 );
					screen_resolution_1920_1080_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.07 );
					game_mechanics_string.SetPosition( game_mechanics_x, SCREEN_H / 2.2 );
					game_mechanics_options1_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.8 );
					game_mechanics_options2_string.SetPosition( game_mechanics_options_x,  SCREEN_H / 1.6 );
					game_mechanics_options3_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.45 );
					game_mechanics_options4_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.3 );
					game_mechanics_options5_string.SetPosition( game_mechanics_options_x - 25, SCREEN_H / 1.07 );
					game_mechanics_options6_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.17 );
					game_mode_string.SetPosition( game_mechanics_x - 30, SCREEN_H / 5 );
					game_mode_option1_string.SetPosition( game_mechanics_x - 25, (SCREEN_H / 5) + 60 );
					game_mode_option2_string.SetPosition( SCREEN_W - 120, (SCREEN_H / 5) + 60 );
					most_enemies_string.SetPosition( SCREEN_W - 300, 10 );
					highest_level_string.SetPosition( 15, 10 );
					game_tip1_string.SetPosition( 15, SCREEN_H / 1.7 );
					game_tip2_string.SetPosition( 15, SCREEN_H / 1.45 );
					game_tip3_string.SetPosition( 15, SCREEN_H / 1.25 );

					//reset game bars
					level_string.SetPosition(SCREEN_W - 100, 10.0);
					number_of_enemies_string.SetPosition( SCREEN_W - 260, SCREEN_H - 50 );
					life_string.SetPosition( 10.0, SCREEN_H - 50 );
					start_game_countdown_string.SetPosition( SCREEN_W / 2.15, SCREEN_H / 2.15 );
					sound_fx_control_string.SetPosition( SCREEN_W / 3, 10 );
					sound_fx_volume_string.SetPosition( SCREEN_W / 3, 10 );
					music_control_string.SetPosition( SCREEN_W / 3, 10 );
					music_volume_string.SetPosition( SCREEN_W / 3, 10 );
					game_paused_string.SetPosition( (SCREEN_W / 2) - 83, (SCREEN_H / 2) - 20 );

				}

				//1680x1050
				else if( mouse_position.x >= ( screen_resolution_options_x - 10 ) && mouse_position.x <= ( screen_resolution_options_x + 135 ) && mouse_position.y >= (SCREEN_H / 1.17) && mouse_position.y <= ( (SCREEN_H / 1.17) + 30) )
				{
					click_sound.Play();

						//writes the new screen resolution to the file
					ofstream output_file("config.txt");
					output_file << 1680 << endl;
					output_file << 1050 << endl;
					output_file.close();	//closes the file

					App.Create( sf::VideoMode( 1680, 1050, 32 ), "Wormhole  :  By Zach Niemann" );	//creates the new size for the screen
					SCREEN_W = App.GetWidth();
					SCREEN_H = App.GetHeight();

					wormhole_sprite.SetPosition( ( ( SCREEN_W - 290 ) + 280 ) / 2, (SCREEN_H / 2.5) + ( (wormhole_image.GetHeight() / wormhole_row_sprites) / 1.5 ) );
					wormhole_temp_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//where the wormhole is created

					game_mechanics_options_x = SCREEN_W - 285;
					game_mechanics_x = SCREEN_W - 290;

					background_sprite.Resize( SCREEN_W, SCREEN_H );	//resize the background image
					background_startscreen_sprite.Resize( SCREEN_W, SCREEN_H );

					//reset all of the menu positions
					start_game_string.SetPosition( default_menu_x, SCREEN_H / 5 );
					screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
					screen_resolution_800_600_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.8);
					screen_resolution_1024_768_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.6 );
					screen_resolution_1280_800_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.45 );
					screen_resolution_1280_1024_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.3 );
					screen_resolution_1680_1050_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.17 );
					screen_resolution_1920_1080_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.07 );
					game_mechanics_string.SetPosition( game_mechanics_x, SCREEN_H / 2.2 );
					game_mechanics_options1_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.8 );
					game_mechanics_options2_string.SetPosition( game_mechanics_options_x,  SCREEN_H / 1.6 );
					game_mechanics_options3_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.45 );
					game_mechanics_options4_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.3 );
					game_mechanics_options5_string.SetPosition( game_mechanics_options_x - 25, SCREEN_H / 1.07 );
					game_mechanics_options6_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.17 );
					game_mode_string.SetPosition( game_mechanics_x - 30, SCREEN_H / 5 );
					game_mode_option1_string.SetPosition( game_mechanics_x - 25, (SCREEN_H / 5) + 60 );
					game_mode_option2_string.SetPosition( SCREEN_W - 120, (SCREEN_H / 5) + 60 );
					most_enemies_string.SetPosition( SCREEN_W - 300, 10 );
					highest_level_string.SetPosition( 15, 10 );
					game_tip1_string.SetPosition( 15, SCREEN_H / 1.7 );
					game_tip2_string.SetPosition( 15, SCREEN_H / 1.45 );
					game_tip3_string.SetPosition( 15, SCREEN_H / 1.25 );

					//reset game bars
					level_string.SetPosition(SCREEN_W - 100, 10.0);
					number_of_enemies_string.SetPosition( SCREEN_W - 260, SCREEN_H - 50 );
					life_string.SetPosition( 10.0, SCREEN_H - 50 );
					start_game_countdown_string.SetPosition( SCREEN_W / 2.15, SCREEN_H / 2.15 );
					sound_fx_control_string.SetPosition( SCREEN_W / 3, 10 );
					sound_fx_volume_string.SetPosition( SCREEN_W / 3, 10 );
					music_control_string.SetPosition( SCREEN_W / 3, 10 );
					music_volume_string.SetPosition( SCREEN_W / 3, 10 );
					game_paused_string.SetPosition( (SCREEN_W / 2) - 83, (SCREEN_H / 2) - 20 );
				}

				//1920x1080
				else if( mouse_position.x >= ( screen_resolution_options_x - 10 ) && mouse_position.x <= ( screen_resolution_options_x + 135 ) && mouse_position.y >= (SCREEN_H / 1.07) && mouse_position.y <= ( (SCREEN_H / 1.07) + 30) )
				{
					click_sound.Play();

					//writes the new screen resolution to the file
					ofstream output_file("config.txt");
					output_file << 1920 << endl;
					output_file << 1080 << endl;
					output_file.close();	//closes the file

					App.Create( sf::VideoMode( 1920, 1080, 32 ), "Wormhole  :  By Zach Niemann" );	//creates the new size for the screen
					SCREEN_W = App.GetWidth();
					SCREEN_H = App.GetHeight();

					wormhole_sprite.SetPosition( ( ( SCREEN_W - 290 ) + 280 ) / 2, (SCREEN_H / 2.5) + ( (wormhole_image.GetHeight() / wormhole_row_sprites) / 1.5 ) );
					wormhole_temp_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//where the wormhole is created

					game_mechanics_options_x = SCREEN_W - 285;
					game_mechanics_x = SCREEN_W - 290;

					background_sprite.Resize( SCREEN_W, SCREEN_H );	//resize the background image
					background_startscreen_sprite.Resize( SCREEN_W, SCREEN_H );

					//reset all of the menu positions
					start_game_string.SetPosition( default_menu_x, SCREEN_H / 5 );
					screen_resolution_string.SetPosition( default_menu_x, SCREEN_H / 2.2 );
					screen_resolution_800_600_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.8);
					screen_resolution_1024_768_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.6 );
					screen_resolution_1280_800_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.45 );
					screen_resolution_1280_1024_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.3 );
					screen_resolution_1680_1050_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.17 );
					screen_resolution_1920_1080_string.SetPosition( screen_resolution_options_x, SCREEN_H / 1.07 );
					game_mechanics_string.SetPosition( game_mechanics_x, SCREEN_H / 2.2 );
					game_mechanics_options1_string.SetPosition( game_mechanics_options_x - 5, SCREEN_H / 1.8 );
					game_mechanics_options2_string.SetPosition( game_mechanics_options_x,  SCREEN_H / 1.6 );
					game_mechanics_options3_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.45 );
					game_mechanics_options4_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.3 );
					game_mechanics_options5_string.SetPosition( game_mechanics_options_x - 25, SCREEN_H / 1.07 );
					game_mechanics_options6_string.SetPosition( game_mechanics_options_x, SCREEN_H / 1.17 );
					game_mode_string.SetPosition( game_mechanics_x - 30, SCREEN_H / 5 );
					game_mode_option1_string.SetPosition( game_mechanics_x - 25, (SCREEN_H / 5) + 60 );
					game_mode_option2_string.SetPosition( SCREEN_W - 120, (SCREEN_H / 5) + 60 );
					most_enemies_string.SetPosition( SCREEN_W - 300, 10 );
					highest_level_string.SetPosition( 15, 10 );
					game_tip1_string.SetPosition( 15, SCREEN_H / 1.7 );
					game_tip2_string.SetPosition( 15, SCREEN_H / 1.45 );
					game_tip3_string.SetPosition( 15, SCREEN_H / 1.25 );

					//reset game bars
					level_string.SetPosition(SCREEN_W - 100, 10.0);
					number_of_enemies_string.SetPosition( SCREEN_W - 260, SCREEN_H - 50 );
					life_string.SetPosition( 10.0, SCREEN_H - 50 );
					start_game_countdown_string.SetPosition( SCREEN_W / 2.15, SCREEN_H / 2.15 );
					sound_fx_control_string.SetPosition( SCREEN_W / 3, 10 );
					sound_fx_volume_string.SetPosition( SCREEN_W / 3, 10 );
					music_control_string.SetPosition( SCREEN_W / 3, 10 );
					music_volume_string.SetPosition( SCREEN_W / 3, 10 );
					game_paused_string.SetPosition( (SCREEN_W / 2) - 83, (SCREEN_H / 2) - 20 );

				}

			}

			
		}
		
		
		if( wormhole_clock.GetElapsedTime() >= wormhole_animation_limit)
		{
			wormhole_clock.Reset();
			wormhole_sprite.Rotate(-15);
		}
		
		//updates the enemies
		for(int i = 0; i < enemy_startscreen_animation.size(); i++)	//updates the position of the current enemy and also implements screen boundaries
			{
				enemy_startscreen_position[i].x += ( enemy_startscreen_speed[i].x * enemy_startscreen_clock.GetElapsedTime() );
				enemy_startscreen_position[i].y += ( enemy_startscreen_speed[i].y * enemy_startscreen_clock.GetElapsedTime() );

				if( enemy_startscreen_position[i].x < 0.0 || ( enemy_startscreen_position[i].x + enemy_startscreen_width ) > SCREEN_W )	//if the enemy has hit a side of the screen on the x axis
				{
					enemy_startscreen_speed[i].x *= -1.0;	//changes the direction of the enemy since it's hit the side of the screen

					if( enemy_startscreen_position[i].x < 0.0 )
					{
						enemy_startscreen_position[i].x = 1.0;
					}

					else
					{
						enemy_startscreen_position[i].x = SCREEN_W - enemy_startscreen_width - 1.0;
					}
				}

				if( enemy_startscreen_position[i].y < 0.0 || ( enemy_startscreen_position[i].y + enemy_startscreen_height ) > SCREEN_H )	//if the enemy has hit a side of the screen on the y axis
				{
					enemy_startscreen_speed[i].y *= -1;	//changes the direction of the enemy since it's hit the side of the screen

					if( enemy_startscreen_position[i].y < 0.0 )
					{
						enemy_startscreen_position[i].y = 1.0;
					}

					else
					{
						enemy_startscreen_position[i].y = SCREEN_H - enemy_startscreen_height - 1.0;
					}

				}

				if( i == enemy_startscreen_animation.size() - 1 )	//if 'i' is on it's last iteration before the loop breaks
				{
					enemy_startscreen_clock.Reset();
				}
			
			}

			for(int i = 0; i < enemy_startscreen_warp_animation.size(); i++)	//updates the warp in animation
			{
				if( enemy_startscreen_warp_animation.update_runthrough_stationary_new(i, enemy_startscreen_warp_animation_limit) == false ) //if the current animation has finished
				{
					enemy_startscreen_warp_animation.erase(i);
				}
			}

			for(int i = 0; i < enemy_startscreen_animation.size(); i++)	//updates the enemy animation
			{
				enemy_startscreen_animation.update_loop_moving( i, enemy_startscreen_position[i], enemy_startscreen_animation_limit );
			}


			App.Clear();
			App.Draw( background_startscreen_sprite );

			for(int i = 0; i < enemy_startscreen_warp_animation.size(); i++)	//draws all the enemy warp animations to the screen
			{
				enemy_startscreen_warp_animation.draw(i, App);
			}

			for(int i = 0; i < enemy_startscreen_animation.size(); i++)	//draws all the enemy animations to the screen
			{
				enemy_startscreen_animation.draw(i, App);
			}

			App.Draw( start_game_string );
			App.Draw( screen_resolution_string );
			App.Draw( game_mechanics_string );
			App.Draw( game_mode_string );

			if( screen_resolution_menu == true )	//if the screen resolutions are being displayed
			{
				App.Draw( screen_resolution_800_600_string );
				App.Draw( screen_resolution_1024_768_string );
				App.Draw( screen_resolution_1280_800_string );
				App.Draw( screen_resolution_1280_1024_string );
				App.Draw( screen_resolution_1680_1050_string );
				App.Draw( screen_resolution_1920_1080_string );
			}

			if( game_mechanics_menu == true )
			{
				App.Draw( game_mechanics_options1_string );
				App.Draw( game_mechanics_options2_string );
				App.Draw( game_mechanics_options3_string );
				App.Draw( game_mechanics_options4_string );
				App.Draw( game_mechanics_options5_string );
				App.Draw( game_mechanics_options6_string );
			}

			if( game_mode_menu == true )
			{
				App.Draw( game_mode_option1_string );
				App.Draw( game_mode_option2_string );
			}

			App.Draw( highest_level_string );
			App.Draw( most_enemies_string );
			App.Draw( wormhole_sprite );
			App.Display();
			

	}


	//deletes all the enemies created for the start screen
	for(int i = enemy_startscreen_animation.size() - 1; i >= 0; i--)
	{
		enemy_startscreen_animation.erase(i);
		enemy_startscreen_position.erase( enemy_startscreen_position.begin() + i );
		enemy_startscreen_speed.erase( enemy_startscreen_speed.begin() + i );
	}
	//end start screen setup
	/////////////////////////////////////////////


	////////////////////////////////////////////
	//ship selection setup
	Animation player_animation;
	Animation red_ship_animation;
	Animation yellow_ship_animation;
	Animation blue_ship_animation;
	sf::Clock ship_select_clock;
	sf::String ship_selection_text;
	sf::Vector2f red_ship_position( 170, (SCREEN_H / 10) + 90 );
	sf::Vector2f yellow_ship_position( 10, (SCREEN_H / 10) + 90 );
	sf::Vector2f blue_ship_position( 340, (SCREEN_H / 10) + 85 );
	sf::Image red_ship_image;
	sf::Image yellow_ship_image;
	sf::Image blue_ship_image;
	sf::Sprite ship_sprite;

	bool ship_selected = false;	//true if the player has picked the ship to use
	float ship_animation_limit = 0.06;
	float ship_row_sprites = 1;
	float ship_column_sprites = 24;
	float ship_width = 0;	//calculated after ship selection
	float ship_height = 0;	//calculated after ship selection

	ship_selection_text.SetText("Ship Selection");
	ship_selection_text.SetFont( font );
	ship_selection_text.SetSize( 55 );
	ship_selection_text.SetPosition( 5, SCREEN_H / 10);

	if( !red_ship_image.LoadFromFile("images\\ufo_red.png" ) )
	{
		cout << "Failed to load the red space ship." << endl;
		App.Close();
	}

	red_ship_image.CreateMaskFromColor( sf::Color(255, 0, 255) );
	ship_sprite.SetImage( red_ship_image );
	red_ship_animation.initializeCoordinates( ship_row_sprites, ship_column_sprites, ship_animation_limit, sf::Vector2f( red_ship_image.GetWidth(), red_ship_image.GetHeight() ), 0, ship_sprite, red_ship_position );

	
	if( !yellow_ship_image.LoadFromFile("images\\ufo_yellow.png") )
	{
		cout << "Failed to load the yellow space ship." << endl;
		App.Close();
	}
	

	yellow_ship_image.CreateMaskFromColor( sf::Color(255, 0, 255) );
	ship_sprite.SetImage( yellow_ship_image );
	yellow_ship_animation.initializeCoordinates( ship_row_sprites, ship_column_sprites, ship_animation_limit, sf::Vector2f( yellow_ship_image.GetWidth(), yellow_ship_image.GetHeight() ), 0, ship_sprite, yellow_ship_position );


	if( !blue_ship_image.LoadFromFile("images\\ufo_blue.png") )
	{
		cout << "Failed to load the blue space ship." << endl;
		App.Close();
	}

	blue_ship_image.CreateMaskFromColor( sf::Color(255, 0, 255) );
	ship_sprite.SetImage( blue_ship_image );
	blue_ship_animation.initializeCoordinates( ship_row_sprites, ship_column_sprites, ship_animation_limit, sf::Vector2f( blue_ship_image.GetWidth(), blue_ship_image.GetHeight() ), 0, ship_sprite, blue_ship_position );




	for(int i = 0; i < startscreen_number_of_enemies; i++)	//creates enemies for the background menu
	{
		//ALSO PUT WARP IN ANIMATION HERE.
		//creates the animation for the current enemy, along with it's warp in position and speed.
		enemy_startscreen_animation.initializeStandard( enemy_startscreen_row_sprites, enemy_startscreen_column_sprites, enemy_startscreen_animation_limit, sf::Vector2f( enemy_startscreen_image.GetWidth(), enemy_startscreen_image.GetHeight() ), 0, enemy_startscreen_sprite );
		enemy_startscreen_position.push_back( sf::Vector2f( rand() % static_cast<int>(SCREEN_W - enemy_startscreen_width - 5), rand() % static_cast<int>(SCREEN_H - enemy_startscreen_height - 5) ) );
		enemy_startscreen_speed.push_back( sf::Vector2f( rand() % static_cast<int>(SCREEN_W / 8) + 100, rand() % static_cast<int>(SCREEN_H / 8) + 100 ) );

		enemy_startscreen_warp_animation.initializeCoordinates( enemy_startscreen_warp_row_sprites, enemy_startscreen_warp_column_sprites, enemy_startscreen_warp_animation_limit, sf::Vector2f( enemy_startscreen_warp_image.GetWidth(), enemy_startscreen_warp_image.GetHeight() ), 0, enemy_startscreen_warp_sprite, sf::Vector2f(enemy_startscreen_position.back().x - enemy_startscreen_width, enemy_startscreen_position.back().y - enemy_startscreen_height) );
		enemy_startscreen_warp_animation.setCurrentlyAnimating(true);

		if( i == (startscreen_number_of_enemies - 1) )	//last iteration
		{
			enemy_spawn_sound.Play();
		}
	}


	sf::Event e;
	ship_select_clock.Reset();
	ship_selection_sound.Play();
	//loops until the player chooses a ship
	while( ship_selected == false && App.IsOpened() )
	{

		while( App.GetEvent( e ) )
		{
			if( e.Type == sf::Event::Closed || ( e.Type == sf::Event::KeyPressed && e.Key.Code == sf::Key::Escape ) )
			{
				App.Close();
			}
			
		}

		//updates the mouse position
		mouse_position.x = App.GetInput().GetMouseX();
		mouse_position.y = App.GetInput().GetMouseY();


		//used to determine what ship is selected
		if( App.GetInput().IsMouseButtonDown( sf::Mouse::Left ) && ship_select_clock.GetElapsedTime() >= 1.0 )	//if the player has clicked
		{
			//yellow ship
			if( mouse_position.x >= 0 && mouse_position.x <= 55 && mouse_position.y >= (SCREEN_H / 10) + 80 && mouse_position.y <= (SCREEN_H / 10) + 130)
			{
				ship_width = yellow_ship_image.GetWidth() / ship_column_sprites;
				ship_height = yellow_ship_image.GetHeight() / ship_row_sprites;
				ship_sprite.SetImage( yellow_ship_image );
				ship_sprite.SetPosition(0.0, 0.0);

				player_animation.initializeStandard( ship_row_sprites, ship_column_sprites, ship_animation_limit, sf::Vector2f( yellow_ship_image.GetWidth(), yellow_ship_image.GetHeight() ), 0, ship_sprite );

				click_sound.Play();
				ship_selected = true;	//continue to the game
			}

			//red ship
			else if( mouse_position.x >= 160 && mouse_position.x <= 215 && mouse_position.y >= (SCREEN_H / 10) + 80 &&  mouse_position.y <= (SCREEN_H / 10) + 130)
			{
				ship_width = red_ship_image.GetWidth() / ship_column_sprites;
				ship_height = yellow_ship_image.GetHeight() / ship_row_sprites;
				ship_sprite.SetImage( red_ship_image );
				ship_sprite.SetPosition(0.0, 0.0);

				player_animation.initializeStandard( ship_row_sprites, ship_column_sprites, ship_animation_limit, sf::Vector2f( red_ship_image.GetWidth(), red_ship_image.GetHeight() ), 0, ship_sprite );

				click_sound.Play();
				ship_selected = true;	//continue to the game
			}

			//blue ship
			else if( mouse_position.x >= 330 && mouse_position.x <= 385 &&  mouse_position.y >= (SCREEN_H / 10) + 80 &&  mouse_position.y <= (SCREEN_H / 10) + 130)
			{
				ship_width = blue_ship_image.GetWidth() / ship_column_sprites;
				ship_height = blue_ship_image.GetHeight() / ship_row_sprites;
				ship_sprite.SetImage( blue_ship_image );
				ship_sprite.SetPosition(0.0, 0.0);

				player_animation.initializeStandard( ship_row_sprites, ship_column_sprites, ship_animation_limit, sf::Vector2f( blue_ship_image.GetWidth(), blue_ship_image.GetHeight() ), 0, ship_sprite );

				click_sound.Play();
				ship_selected = true;	//continue to the game

			}

		}

		//updates the enemies
		for(int i = 0; i < enemy_startscreen_animation.size(); i++)	//updates the position of the current enemy and also implements screen boundaries
			{
				enemy_startscreen_position[i].x += ( enemy_startscreen_speed[i].x * enemy_startscreen_clock.GetElapsedTime() );
				enemy_startscreen_position[i].y += ( enemy_startscreen_speed[i].y * enemy_startscreen_clock.GetElapsedTime() );

				if( enemy_startscreen_position[i].x < 0.0 || ( enemy_startscreen_position[i].x + enemy_startscreen_width ) > SCREEN_W )	//if the enemy has hit a side of the screen on the x axis
				{
					enemy_startscreen_speed[i].x *= -1.0;	//changes the direction of the enemy since it's hit the side of the screen

					if( enemy_startscreen_position[i].x < 0.0 )
					{
						enemy_startscreen_position[i].x = 1.0;
					}

					else
					{
						enemy_startscreen_position[i].x = SCREEN_W - enemy_startscreen_width - 1.0;
					}
				}

				if( enemy_startscreen_position[i].y < 0.0 || ( enemy_startscreen_position[i].y + enemy_startscreen_height ) > SCREEN_H )	//if the enemy has hit a side of the screen on the y axis
				{
					enemy_startscreen_speed[i].y *= -1;	//changes the direction of the enemy since it's hit the side of the screen

					if( enemy_startscreen_position[i].y < 0.0 )
					{
						enemy_startscreen_position[i].y = 1.0;
					}

					else
					{
						enemy_startscreen_position[i].y = SCREEN_H - enemy_startscreen_height - 1.0;
					}

				}

				if( i == enemy_startscreen_animation.size() - 1 )	//if 'i' is on it's last iteration before the loop breaks
				{
					enemy_startscreen_clock.Reset();
				}
			
			}

			for(int i = 0; i < enemy_startscreen_warp_animation.size(); i++)	//updates the warp in animation
			{
				if( enemy_startscreen_warp_animation.update_runthrough_stationary_new(i, enemy_startscreen_warp_animation_limit) == false ) //if the current animation has finished
				{
					enemy_startscreen_warp_animation.erase(i);
				}
			}

			for(int i = 0; i < enemy_startscreen_animation.size(); i++)	//updates the enemy animation
			{
				enemy_startscreen_animation.update_loop_moving( i, enemy_startscreen_position[i], enemy_startscreen_animation_limit );
			}

		App.Clear();

		App.Draw( background_sprite );

		for(int i = 0; i < enemy_startscreen_warp_animation.size(); i++)	//draws all the enemy warp animations to the screen
		{
			enemy_startscreen_warp_animation.draw(i, App);
		}

		for(int i = 0; i < enemy_startscreen_animation.size(); i++)	//draws all the enemy animations to the screen
		{
			enemy_startscreen_animation.draw(i, App);
		}

		App.Draw( ship_selection_text );
		App.Draw( game_tip1_string );
		App.Draw( game_tip2_string );
		App.Draw( game_tip3_string );

		red_ship_animation.update_loop_stationary(0, ship_animation_limit);
		yellow_ship_animation.update_loop_stationary(0, ship_animation_limit);
		blue_ship_animation.update_loop_stationary(0, ship_animation_limit);

		red_ship_animation.draw(0, App);
		yellow_ship_animation.draw(0, App);
		blue_ship_animation.draw(0, App);
		
	
		App.Display();

	}


	//deletes all the enemies created for the start screen
	for(int i = enemy_startscreen_animation.size() - 1; i >= 0; i--)
	{
		enemy_startscreen_animation.erase(i);
		enemy_startscreen_position.erase( enemy_startscreen_position.begin() + i );
		enemy_startscreen_speed.erase( enemy_startscreen_speed.begin() + i );
	}

	//end ship selection setup
	///////////////////////////////////////////


	///////////////////////////////////////////
	//level completed setup
	sf::String level_complete_text;
	sf::String level_complete_continue_text;
	sf::String level_complete_quit_text;
	sf::String level_restart_text;
	sf::String level_failed_text;
	sf::String level_failed_text2;


	level_complete_text.SetText("Level Completed!");
	level_complete_text.SetFont( font );
	level_complete_text.SetSize( 60.0 );
	level_complete_text.SetPosition( SCREEN_W / 3.7, SCREEN_H / 4 );

	level_failed_text.SetText("Level Failed");
	level_failed_text.SetFont( font );
	level_failed_text.SetSize( 55.0 );
	level_failed_text.SetPosition( (SCREEN_W / 2.0) - 123, SCREEN_H / 6 );

	level_failed_text2.SetText("Probably isn't the first time this has happened.");
	level_failed_text2.SetFont( font );
	level_failed_text2.SetSize( 35.0 );
	level_failed_text2.SetPosition( (SCREEN_W / 2.0) - 315, SCREEN_H / 3 );


	level_complete_continue_text.SetText("Continue");
	level_complete_continue_text.SetFont( font );
	level_complete_continue_text.SetSize( 40 );
	level_complete_continue_text.SetPosition( SCREEN_W / 4.6, SCREEN_H / 1.8 );


	level_restart_text.SetText("Restart");
	level_restart_text.SetFont( font );
	level_restart_text.SetSize( 40 );
	level_restart_text.SetPosition( SCREEN_W / 4.6, SCREEN_H / 1.8 );

	level_complete_quit_text.SetText("Quit");
	level_complete_quit_text.SetFont( font );
	level_complete_quit_text.SetSize( 40 );
	level_complete_quit_text.SetPosition( SCREEN_W / 1.5, SCREEN_H / 1.8 );
	
	//end level completed setup
	//////////////////////////////////////////

	////////////////////////////////////////////
	//player setup
	Health player_health;
	//Animation player_animation;
	sf::Image player_image;
	sf::Sprite player_sprite;
	sf::Vector2f player_position(SCREEN_W / 2, SCREEN_H / 2);	//starting position
	sf::Vector2f player_speed;
	const float player_speed_increase = 2.7;	//makes the player move x times faster when holding shift.
	sf::Clock manual_control_toggle_clock;
	bool manual_control_toggle = true;	//manual control from the start
	const float player_row_sprites = 1;
	const float player_column_sprites = 24;
	float player_animation_limit = 0.06;
	
	player_speed.x = SCREEN_W / 3;
	player_speed.y = SCREEN_H / 3;


	if( !player_image.LoadFromFile("images\\ufo_red.png") )
	{
		cout << "Failed to load player image." << endl;
		App.Close();
	}

	const float player_width = player_image.GetWidth()   / player_column_sprites;
	const float player_height = player_image.GetHeight() / player_row_sprites;

	player_image.CreateMaskFromColor( sf::Color(255, 0, 255) );

	player_sprite.SetImage( player_image );
	player_sprite.SetPosition(player_position);

	//player_animation.initializeStandard( player_row_sprites, player_column_sprites, player_animation_limit, sf::Vector2f( player_image.GetWidth(), player_image.GetHeight() ), 0, player_sprite );

	player_health.initialize();

	player_health.setCurrentDamage(true);	//does this so the bar is rendered the right color the first time.
	player_health.render( player_position );

	//update life text
	itoa( (player_health.getMaxHitCount() - player_health.getHitCount() ) * 10, temp_storage, 10 );
	current_life_text = temp_storage;
	life_string.SetText( current_life_text + base_life_text );

	//end player setup
	//////////////////////////////////////////////////////////



	/////////////////////////////////////////////////////////
	//enemy setup
	Animation enemy_animation;		//used for the general enemy animation
	Animation enemy_warp_animation;	//used for the enemy warp in animation
	sf::Clock enemy_clock;	//used to update the position of the enemies
	//sf::Clock enemy_spawn_clock;	//used to update the number of enemies on the screen.
	Time enemy_spawn_clock;
	sf::Image enemy_image;
	sf::Sprite enemy_sprite;
	vector<sf::Vector2f> enemy_position;	//stores all the enemy positions.
	vector<sf::Vector2f> enemy_speed;		//stores all the enemy speeds.
	const float enemy_row_sprites = 1;
	const float enemy_column_sprites = 6;
	float enemy_animation_limit = 0.1;
	int NUMBER_OF_ENEMIES = 1;
	const float ENEMY_SPAWN_TIME = 5.0;
	const float ENEMY_SPAWN_DISTANCE = 75.0;	//minimum distance enemies spawn from the player
	float spawn_distance = 0;	//current enemy spawn distance from the player
	sf::Image enemy_warp_image;
	sf::Sprite enemy_warp_sprite;
	const float enemy_warp_row_sprites = 1;
	const float enemy_warp_column_sprites = 15;
	float enemy_warp_animation_limit = 0.025;

	Animation enemy_follow_animation;	//used for the follower enemy - prevents hiding in the corner
	vector<sf::Vector2f> previous_player_position;
	float previous_player_proximity = SCREEN_W / 20.0;	//if the current position is within this amount of pixels from a previous position, the follow enemy spawns
	sf::Clock previous_player_position_clock;	//used to record the players position every 0.5 seconds
	sf::Clock enemy_follow_clock;		//used to update the following enemy
	sf::Clock enemy_follow_spawn_clock;	//used to determine if it's been long enough to check if the player has moved, if not the follow enemy spawns.
	sf::Vector2f enemy_follow_position;	//stores the position of the follow enemy
	sf::Vector2f enemy_follow_speed;	//stores the speed of the follow enemy
	sf::Image enemy_follow_image;
	sf::Sprite enemy_follow_sprite;


	if( !enemy_image.LoadFromFile("images\\power_ball.png") )
	{
		cout << "Failed to load enemy image." << endl;
		App.Close();
	}

	enemy_image.CreateMaskFromColor( sf::Color(255, 0, 255) );

	enemy_sprite.SetImage( enemy_image );

	if( !enemy_follow_image.LoadFromFile("images\\power_ball5.png") )
	{
		cout << "Failed to load the follower enemy image." << endl;
		App.Close();
	}

	enemy_follow_image.CreateMaskFromColor( sf::Color(255, 0, 255) );
	enemy_follow_sprite.SetImage( enemy_follow_image );
	enemy_follow_speed = sf::Vector2f( SCREEN_W / 4, SCREEN_H / 4 );
	enemy_follow_sprite.SetPosition( SCREEN_W / 2, SCREEN_H / 2 );
	
	const float enemy_width = enemy_image.GetWidth() / enemy_column_sprites;
	const float enemy_height = enemy_image.GetHeight() / enemy_row_sprites;

	if( !enemy_warp_image.LoadFromFile("images\\warp_inverted.png") )
	{
		cout << "Failed to load enemy warp image." << endl;
		App.Close();
	}

	enemy_warp_image.CreateMaskFromColor( sf::Color(255, 0, 255) );

	const float enemy_warp_width = enemy_warp_image.GetWidth() / enemy_warp_column_sprites;
	const float enemy_warp_height = enemy_warp_image.GetHeight() / enemy_warp_row_sprites;

	enemy_warp_sprite.SetImage( enemy_warp_image );

	
	
	//number of enemies text update
	itoa(enemy_animation.size(), temp_storage, 10);
	current_number_of_enemies_text = temp_storage;
	number_of_enemies_string.SetText( number_of_enemies_base_text + current_number_of_enemies_text );

	//end enemy setup
	/////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////
	//space tear setup
	Animation space_tear_animation;
	sf::Image space_tear_image;
	sf::Sprite space_tear_sprite;
	sf::Clock space_tear_clock;
	const int space_tear_row_sprites = 1;
	const int space_tear_column_sprites = 11;
	const float SPACE_TEAR_TIME = 0.25;	//how often collisions can happen
	float space_tear_animation_limit = 0.025;

	if( !space_tear_image.LoadFromFile("images\\bgreen_explosion.png") )
	{
		cout << "Failed to load space tear image." << endl;
		App.Close();
	}

	space_tear_image.CreateMaskFromColor( sf::Color(255, 0, 255) );

	float space_tear_width  = space_tear_image.GetWidth();
	float space_tear_height = space_tear_image.GetHeight();

	space_tear_sprite.SetImage( space_tear_image );
	//space tear setup
	////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////
	//wormhole setup
	sf::Image wormhole_image2;
	sf::Sprite wormhole_sprite2;

	if( !wormhole_image2.LoadFromFile("images\\blackhole.png") )
	{
		cout << "Failed to load wormhole image." << endl;
		App.Close();
	}

	wormhole_image2.CreateMaskFromColor( sf::Color(255, 0, 255) );
	wormhole_sprite2.SetImage( wormhole_image2 );

	wormhole_width = wormhole_image2.GetWidth() / wormhole_column_sprites;
	wormhole_height = wormhole_image2.GetHeight() / wormhole_row_sprites;

	//wormhole_animation.initializeCoordinates(wormhole_row_sprites, wormhole_column_sprites, wormhole_animation_limit, sf::Vector2f( wormhole_image2.GetWidth(), wormhole_image2.GetHeight() ), 0, wormhole_sprite2, sf::Vector2f( SCREEN_W / 2, SCREEN_H / 2 ) );

	//end wormhole setup
	/////////////////////////////////////////////////////////


	//sf::Event e;
	
	while( App.IsOpened() )
	{
		level_complete = false;	//resets level

		if( wormhole_animation.size() > 0 )	//erases the wormhole animation from the last level
		{
			wormhole_animation.erase(0);
		}

		while( App.IsOpened() && player_health.getHitCount() != player_health.getMaxHitCount() && level_complete == false )	//loops until the application is closed or the player dies.
		{
			enemy_spawn_clock.Update();
		
			while( App.GetEvent( e ) )
			{
				if( e.Type == sf::Event::Closed )
				{
					ofstream config_file2("config2.txt");	//used for the high scores

					if( config_file2.fail() )	//the file failed to open
					{
						cout << "Failed to open config file 2" << endl;
						App.Close();
					}

					//sends the high scores to the text file for record
					config_file2 << highest_level_normal_mode << endl;
					config_file2 << most_enemies_normal_mode << endl;
					config_file2 << highest_level_survival_mode << endl;
					config_file2 << most_enemies_survival_mode << endl;
					config_file2.close();
					App.Close();
				}
			
			}



			if( App.GetInput().IsKeyDown( sf::Key::T ) && manual_control_toggle_clock.GetElapsedTime() >= 1.0 )
			{
				if( manual_control_toggle == true )
				{
					manual_control_toggle = false;
				}

				else
				{
					manual_control_toggle = true;
				}

				manual_control_toggle_clock.Reset();
			}


			if( App.GetInput().IsKeyDown( sf::Key::Escape ) && pause_clock.GetElapsedTime() >= 1.0)
			{
				pause_clock.Reset();

				if( game_paused == false )
				{
					App.Draw( game_paused_string );
					App.Display();
					game_paused = true;
					enemy_spawn_clock.Pause();
				}

				else
				{
					game_paused = false;
				}

				while( game_paused == true && App.IsOpened() )
				{

					while( App.GetEvent( e ) )
					{
						if( e.Type == sf::Event::Closed )
						{
							App.Close();
						}

					}
				
					if( App.GetInput().IsKeyDown( sf::Key::Escape ) && pause_clock.GetElapsedTime() >= 1.0)
					{
						pause_clock.Reset();

						if( game_paused == false )
						{
							game_paused = true;
						}

						else
						{
							game_paused = false;
							
							countdown_clock.Reset();
							enemy_clock.Reset();
							enemy_follow_clock.Reset();
							enemy_spawn_clock.Resume();
						}

					}

				}

			}


			if( App.GetInput().IsKeyDown( sf::Key::M ) && music_clock.GetElapsedTime() >= 0.5)	//toggling on and off music control which allows you to change the volume of the music
			{
				music_clock.Reset();

				sound_fx_control = false;	//NEW - can't control both at the same time

				if( music_control == false )
				{
					music_control = true;
					music_control_string.SetText("Music Control: ON");
				}

				else
				{
					music_control = false;
					music_control_string.SetText("Music Control: OFF");
				}
			}

			if( App.GetInput().IsKeyDown( sf::Key::F ) && sound_fx_clock.GetElapsedTime() >= 0.5 )	//toggling on and off sound fx control allows you to change the volume of the sound fx
			{
				sound_fx_clock.Reset();

				music_control = false;	//NEW - can't control both at the same time

				if( sound_fx_control == false )
				{
					sound_fx_control = true;
					sound_fx_control_string.SetText("Sound FX Control: ON");
				}

				else
				{
					sound_fx_control = false;
					sound_fx_control_string.SetText("Sound FX Control: OFF");
				}

			}

			if( App.GetInput().IsKeyDown( sf::Key::Up ) && music_clock.GetElapsedTime() >= 0.05 && music_control == true )	//increases the volume of the music
			{
				music_clock.Reset();
				music_display_clock.Reset();

				if( music_volume < 100 )
				{
					music_volume += 1;
					itoa(music_volume, temp_storage, 10);
					string_temp = temp_storage;

					background_music.SetVolume( music_volume );
					music_volume_string.SetText( "Music volume: " + string_temp );

				}

			}

			else if( App.GetInput().IsKeyDown( sf::Key::Down ) && music_clock.GetElapsedTime() >= 0.05 && music_control == true ) //decreases the volume of the music
			{
				music_clock.Reset();
				music_display_clock.Reset();

				if( music_volume > 0 )
				{
					music_volume -= 1;
					itoa(music_volume, temp_storage, 10);
					string_temp = temp_storage;

					background_music.SetVolume( music_volume );
					music_volume_string.SetText( "Music volume: " + string_temp );
				}
			}

			if( App.GetInput().IsKeyDown( sf::Key::Up ) && sound_fx_clock.GetElapsedTime() >= 0.05 && sound_fx_control == true )	//increases the volume of the music
			{
				sound_fx_clock.Reset();
				music_display_clock.Reset();	//use for both by checking if sound_fx_control or music_control are true.

				if( sound_fx_volume < 100 )
				{
					sound_fx_volume += 1;
					itoa(sound_fx_volume, temp_storage, 10);
					string_temp = temp_storage;

					explosion_sound.SetVolume( sound_fx_volume );
					enemy_spawn_sound.SetVolume( sound_fx_volume + 10 );
					sound_fx_volume_string.SetText("Sound FX Volume: " + string_temp );

				}

			}

			else if( App.GetInput().IsKeyDown( sf::Key::Down ) && sound_fx_clock.GetElapsedTime() >= 0.05 && sound_fx_control == true ) //decreases the volume of the music
			{
				sound_fx_clock.Reset();
				music_display_clock.Reset();	//use for both by checking if sound_fx_control or music_control are true.

				if( sound_fx_volume > 0 )
				{
					sound_fx_volume -= 1;
					itoa(sound_fx_volume, temp_storage, 10);
					string_temp = temp_storage;

					explosion_sound.SetVolume( sound_fx_volume );
					enemy_spawn_sound.SetVolume( sound_fx_volume + 10 );
					sound_fx_volume_string.SetText("Sound FX Volume: " + string_temp );
				}
			}

			if( countdown_clock.GetElapsedTime() >= 1.0 && countdown > 0 )	//used to modify the countdown clock and update it's text
			{
				countdown--;

				itoa(countdown, temp_storage, 10);
				current_countdown_text = temp_storage;

				countdown_string.SetText( countdown_base_text + current_countdown_text );

				countdown_clock.Reset();

				if( countdown == 0 )
				{
					if( wormhole_animation.size() == 0 )	//if a wormhole hasn't been created yet
					{
						//wormhole_animation.initializeCoordinates(wormhole_row_sprites, wormhole_column_sprites, wormhole_animation_limit, sf::Vector2f( wormhole_image.GetWidth(), wormhole_image.GetHeight() ), 0, wormhole_sprite, wormhole_temp_position );
						wormhole_animation.initializeCoordinates(wormhole_row_sprites, wormhole_column_sprites, wormhole_animation_limit, sf::Vector2f( wormhole_image2.GetWidth(), wormhole_image2.GetHeight() ), 0, wormhole_sprite2, sf::Vector2f( (SCREEN_W / 2) - (wormhole_width / 2), (SCREEN_H / 2 ) - (wormhole_height / 2) ) );
					}
				}
			}
		
			if( wormhole_animation.size() > 0 )	//checks to see if the player has collided with the wormhole
			{
				wormhole_animation.update_loop_stationary(0, wormhole_animation_limit);

				if( collisions.collisionDetection( player_position, sf::Vector2f( player_width, player_height ), sf::Vector2f( (SCREEN_W / 2) - (wormhole_width / 2), (SCREEN_H / 2 ) - (wormhole_height / 2) ), sf::Vector2f( wormhole_width, wormhole_height ) ) == true )
				{
					level_complete = true;	//the player has reached the wormhole
				}

			}

			if( enemy_spawn_clock.GetElapsedTime() >= ENEMY_SPAWN_TIME )	//spawns a new enemy
			 {

				for(int i = 0; i < level; i++)	//PUT LEVEL CODE HERE. the level will control how many objects are spawned
				{
					enemy_position.push_back( sf::Vector2f( rand() % static_cast<int>(SCREEN_W - enemy_width - 5), rand() % static_cast<int>(SCREEN_H - enemy_height - 5) ) );
					enemy_speed.push_back( sf::Vector2f( rand() % static_cast<int>(SCREEN_W / 8) + 100, rand() % static_cast<int>(SCREEN_H / 8) + 100 ) );

					enemy_animation.initializeCoordinates( enemy_row_sprites, enemy_column_sprites, enemy_animation_limit, sf::Vector2f( enemy_image.GetWidth(), enemy_image.GetHeight() ), 0, enemy_sprite, enemy_position.back() );

					spawn_distance = sqrt( pow(player_position.x - enemy_position.back().x, 2) - pow(player_position.y - enemy_position.back().y, 2) );

					while( spawn_distance < ENEMY_SPAWN_DISTANCE )	//if the enemy spawned too close to the player, it finds a new location.
					{
						enemy_position.back().x = rand() % static_cast<int>(SCREEN_W - enemy_width - 5.0);
						enemy_position.back().y = rand() % static_cast<int>(SCREEN_H - enemy_height - 5.0);

						spawn_distance = sqrt( pow(player_position.x - enemy_position.back().x, 2) - pow(player_position.y - enemy_position.back().y, 2) );
					}

					enemy_spawn_clock.Reset();

					if( enemy_animation.size() % (level * 2) == 0 )	//if two new enemies have spawned, restore some of the players health
					{
						player_health.setHitCount( player_health.getHitCount() - 1 );	//removes one hit from the players health bar, restoring health.
						player_health.setCurrentDamage(true);

						//update life text
						itoa( (player_health.getMaxHitCount() - player_health.getHitCount() ) * 10, temp_storage, 10 );
						current_life_text = temp_storage;
						life_string.SetText( current_life_text + base_life_text );
					}

					enemy_warp_animation.initializeCoordinates( enemy_warp_row_sprites, enemy_warp_column_sprites, enemy_warp_animation_limit, sf::Vector2f( enemy_warp_image.GetWidth(), enemy_warp_image.GetHeight() ), 0, enemy_warp_sprite, sf::Vector2f(enemy_position.back().x, enemy_position.back().y) );
					enemy_warp_animation.setCurrentlyAnimating(true);


					if( i == level - 1) //last iteration
					{
						enemy_spawn_sound.Play();
					}
				}

				

				//number of enemies text update
				itoa(enemy_animation.size(), temp_storage, 10);
				current_number_of_enemies_text = temp_storage;
				number_of_enemies_string.SetText( number_of_enemies_base_text + current_number_of_enemies_text );
			}

			if( previous_player_position_clock.GetElapsedTime() >= 0.5 )	//if it's been long enough to record the player's position
			{
				previous_player_position.push_back( player_position );
				previous_player_position_clock.Reset();
			}

			if( enemy_follow_spawn_clock.GetElapsedTime() >= 2.0 )
			{
				enemy_follow_spawn_clock.Reset();

				if( enemy_follow_animation.size() == 0 && enemy_animation.size() > (level * 1) )
				{
					int count = 0;	//keeps track of how often the player has been in a certain area, if it's too many times, the follow enemy is spawned

					for(int i = 0; i < previous_player_position.size(); i++)	//loops through all the recorded positions
					{
						if( sqrt( pow(player_position.x - previous_player_position[i].x, 2) - pow(player_position.y - previous_player_position[i].y, 2) ) <= previous_player_proximity )
						{
							count++;	//the number of positions the player has been at recently is increased
						}
					}


					if( count >= 3 )
					{
						enemy_follow_position = sf::Vector2f( SCREEN_W / 2, SCREEN_H / 2 );
						enemy_follow_sprite.SetPosition( enemy_follow_position );
						enemy_follow_animation.initializeCoordinates( enemy_row_sprites, enemy_column_sprites, enemy_animation_limit, sf::Vector2f( enemy_follow_image.GetWidth(), enemy_follow_image.GetHeight() ), 0, enemy_follow_sprite, enemy_follow_position );

						spawn_distance = sqrt( pow(player_position.x - enemy_follow_position.x, 2) - pow(player_position.y - enemy_follow_position.y, 2) );

						while( spawn_distance < ENEMY_SPAWN_DISTANCE )	//if the enemy spawned too close to the player, it finds a new location.
						{
							enemy_follow_position.x = rand() % static_cast<int>(SCREEN_W - enemy_width - 5.0);
							enemy_follow_position.y = rand() % static_cast<int>(SCREEN_H - enemy_height - 5.0);

							spawn_distance = sqrt( pow(player_position.x - enemy_follow_position.x, 2) - pow(player_position.y - enemy_follow_position.y, 2) );
						}

						enemy_follow_animation.setPosition( enemy_follow_position );

						time_to_die_sound.Play();
					}
					/*
					//spawns a follow enemy if one doesn't exist and the player hasn't moved much
					if( sqrt( pow(player_position.x - previous_player_position.x, 2) - pow(player_position.y - previous_player_position.y, 2) ) <= 30 )
					{
							enemy_follow_position = sf::Vector2f( SCREEN_W / 2, SCREEN_H / 2 );
							enemy_follow_sprite.SetPosition( enemy_follow_position );
							enemy_follow_animation.initializeCoordinates( enemy_row_sprites, enemy_column_sprites, enemy_animation_limit, sf::Vector2f( enemy_follow_image.GetWidth(), enemy_follow_image.GetHeight() ), 0, enemy_follow_sprite, enemy_follow_position );

							spawn_distance = sqrt( pow(player_position.x - enemy_follow_position.x, 2) - pow(player_position.y - enemy_follow_position.y, 2) );

							while( spawn_distance < ENEMY_SPAWN_DISTANCE )	//if the enemy spawned too close to the player, it finds a new location.
							{
								enemy_follow_position.x = rand() % static_cast<int>(SCREEN_W - enemy_width - 5.0);
								enemy_follow_position.y = rand() % static_cast<int>(SCREEN_H - enemy_height - 5.0);

								spawn_distance = sqrt( pow(player_position.x - enemy_follow_position.x, 2) - pow(player_position.y - enemy_follow_position.y, 2) );
							}

							enemy_follow_animation.setPosition( enemy_follow_position );

							time_to_die_sound.Play();
					}
					*/
					count = 0;	//reset
					previous_player_position.clear();	//clears the contents of the vector
				}

				//previous_player_position = player_position;	//sets the current player position as the previous player position for the next iteration
			}

			//move the player if manual control is on
			if( manual_control_toggle == true )
			{
				if( player_speed.x < 0.0 )	//if the x axis keys are switched
				{
					player_speed.x *= -1;
				}

				if( player_speed.y < 0.0 )	//if the y axis keys are switched
				{
					player_speed.y *= -1;
				}

				if( App.GetInput().IsKeyDown( sf::Key::LShift ) || App.GetInput().IsKeyDown( sf::Key::RShift ) )
				{
					if( App.GetInput().IsKeyDown( sf::Key::W ) )
					{
						player_position.y -= ( player_speed.y * clock.GetElapsedTime() * player_speed_increase );
					}

					else if( App.GetInput().IsKeyDown( sf::Key::S ) )
					{
						player_position.y +=  ( player_speed.y * clock.GetElapsedTime() * player_speed_increase );
					}

					if( App.GetInput().IsKeyDown( sf::Key::D ) )
					{
						player_position.x += ( player_speed.x * clock.GetElapsedTime() * player_speed_increase );
					}

					else if( App.GetInput().IsKeyDown( sf::Key::A ) )
					{
						player_position.x -= ( player_speed.x * clock.GetElapsedTime() * player_speed_increase );
					}
				}

				else
				{
					if( App.GetInput().IsKeyDown( sf::Key::W ) )
					{
						player_position.y -= ( player_speed.y * clock.GetElapsedTime() );
					}

					else if( App.GetInput().IsKeyDown( sf::Key::S ) )
					{
						player_position.y +=  ( player_speed.y * clock.GetElapsedTime() );
					}

					if( App.GetInput().IsKeyDown( sf::Key::D ) )
					{
						player_position.x += ( player_speed.x * clock.GetElapsedTime() );
					}

					else if( App.GetInput().IsKeyDown( sf::Key::A ) )
					{
						player_position.x -= ( player_speed.x * clock.GetElapsedTime() );
					}
				}

				clock.Reset();
			}

			else
			{
				player_position.x += ( player_speed.x * clock.GetElapsedTime() );
				player_position.y += ( player_speed.y * clock.GetElapsedTime() );

				clock.Reset();
			}


			if( enemy_follow_animation.size() > 0 )	//if there is a follow enemy, update it's position
			{
				//update so that the enemy moves towards the player
				if( player_position.y > enemy_follow_position.y )	//if the player is below the enemy
				{
					enemy_follow_position.y += ( enemy_follow_clock.GetElapsedTime() * enemy_follow_speed.y );
				}

				else if( player_position.y < enemy_follow_position.y )	//if the player is above the enemy
				{
					enemy_follow_position.y -= ( enemy_follow_clock.GetElapsedTime() * enemy_follow_speed.y );
				}


				if( player_position.x > enemy_follow_position.x )	//if the player is to the right of the enemy
				{
					enemy_follow_position.x += ( enemy_follow_clock.GetElapsedTime() * enemy_follow_speed.x );
				}

				else if( player_position.x < enemy_follow_position.x )	//if the player position is to the left of the enemy
				{
					enemy_follow_position.x -= ( enemy_follow_clock.GetElapsedTime() * enemy_follow_speed.x );
				}


				//boundary control
				if( enemy_follow_position.x < 0.0 || ( enemy_follow_position.x + enemy_width ) > SCREEN_W )	//if the enemy has hit a side of the screen on the x axis
				{

					if( enemy_follow_position.x < 0.0 )
					{
						enemy_follow_position.x = 1.0;
					}

					else
					{
						enemy_follow_position.x = SCREEN_W - enemy_width - 1.0;
					}
				}

				if( enemy_follow_position.y < 0.0 || ( enemy_follow_position.y + enemy_height ) > SCREEN_H )	//if the enemy has hit a side of the screen on the y axis
				{

					if( enemy_follow_position.y < 0.0 )
					{
						enemy_follow_position.y = 1.0;
					}

					else
					{
						enemy_follow_position.y = SCREEN_H - enemy_height - 1.0;
					}

				}

				enemy_follow_clock.Reset();
			}


			for(int i = 0; i < enemy_animation.size(); i++)	//updates the position of the current enemy and also implements screen boundaries
			{
				enemy_position[i].x += ( enemy_speed[i].x * enemy_clock.GetElapsedTime() );
				enemy_position[i].y += ( enemy_speed[i].y * enemy_clock.GetElapsedTime() );

				if( enemy_position[i].x < 0.0 || ( enemy_position[i].x + enemy_width ) > SCREEN_W )	//if the enemy has hit a side of the screen on the x axis
				{
					enemy_speed[i].x *= -1.0;	//changes the direction of the enemy since it's hit the side of the screen

					if( enemy_position[i].x < 0.0 )
					{
						enemy_position[i].x = 1.0;
					}

					else
					{
						enemy_position[i].x = SCREEN_W - enemy_width - 1.0;
					}
				}

				if( enemy_position[i].y < 0.0 || ( enemy_position[i].y + enemy_height ) > SCREEN_H )	//if the enemy has hit a side of the screen on the y axis
				{
					enemy_speed[i].y *= -1;	//changes the direction of the enemy since it's hit the side of the screen

					if( enemy_position[i].y < 0.0 )
					{
						enemy_position[i].y = 1.0;
					}

					else
					{
						enemy_position[i].y = SCREEN_H - enemy_height - 1.0;
					}

				}

				if( i == enemy_animation.size() - 1 )	//if 'i' is on it's last iteration before the loop breaks
				{
					enemy_clock.Reset();
				}
			
			}

			//screen boundaries
			if( player_position.x < 0.0 || ( player_position.x + player_width ) > SCREEN_W )
			{
				if( manual_control_toggle == false )
				{
					player_speed.x *= -1;	//switches the direction on the x axis
				}
			
				if( player_position.x < 0.0 )
				{
					player_position.x = 1.0;
				}

				else
				{
					player_position.x = SCREEN_W - player_width - 1.0;
				}

			}

			if( player_position.y < 0.0 || ( player_position.y + ( player_height / player_row_sprites ) ) > SCREEN_H )
			{
				if( manual_control_toggle == false )
				{
					player_speed.y *= -1;	//switches the direction on the y axis
				}

				if( player_position.y < 0.0 )
				{
					player_position.y = 1.0;
				}

				else
				{
					player_position.y = SCREEN_H - player_height - 1.0;
				}

			}

		
			for(int i = 0; i < space_tear_animation.size(); i++)
			{
				if( space_tear_animation.update_runthrough_stationary_new(i, space_tear_animation_limit) == false )	//if the current animation has finished
				{
					space_tear_animation.erase(i);
				}
			}


			for(int i = 0; i < enemy_warp_animation.size(); i++)	//updates the warp in animation
			{
				if( enemy_warp_animation.update_runthrough_stationary_new(i, enemy_warp_animation_limit) == false ) //if the current animation has finished
				{
					enemy_warp_animation.erase(i);
				}
			}

			for(int i = 0; i < enemy_animation.size(); i++)	//updates the enemy animation
			{
				enemy_animation.update_loop_moving( i, enemy_position[i], enemy_animation_limit );
			}

			if( enemy_follow_animation.size() > 0 )	//updates the follow enemy
			{
				enemy_follow_animation.update_loop_moving(0, enemy_follow_position, enemy_animation_limit );
			}

			player_animation.update_loop_moving( 0, player_position, player_animation_limit );

			/*
			if( wormhole_animation.size() > 0 )	//update wormhole animation if it exists
			{
				wormhole_animation.update_loop_stationary(0, wormhole_animation_limit);
			}
			*/
			//checks if the follow enemy has collided with the character
			if( enemy_follow_animation.size() > 0 && collisions.collisionDetection(player_position, sf::Vector2f( player_width, player_height ), enemy_follow_position, sf::Vector2f( enemy_width, enemy_height ) ) == true && space_tear_clock.GetElapsedTime() > SPACE_TEAR_TIME )	//collisions occurred
			{
				space_tear_animation.initializeCoordinates( space_tear_row_sprites, space_tear_column_sprites, space_tear_animation_limit, sf::Vector2f( space_tear_width, space_tear_height ), 0, space_tear_sprite, sf::Vector2f(player_position.x - player_width, player_position.y - player_height) );
				space_tear_animation.setCurrentlyAnimating( true );

				player_health.damage(2);

				/*sf::Clock enemy_follow_sound_clock;		//checks to see if it's been long enough for the follow enemy to say something
	float enemy_follow_sound_limit = 5.0;	//allows the follow enemy to say something no more often than every 5 seconds.
	int enemy_follow_sound_count = 3;		//number of sounds the cycle through
	vector<sf::Sound> enemy_follow_sounds;	//stores all the sounds for the enemy to cycle through
	*/

				if( enemy_follow_sound_clock.GetElapsedTime() >= enemy_follow_sound_limit )	//if it's been long enough for the follow enemy to say something
				{
					enemy_follow_sounds[ rand() % enemy_follow_sound_count ].Play();	//chooses a sound from the selection to play
					enemy_follow_sound_clock.Reset();
				}

				//update life text
				itoa( (player_health.getMaxHitCount() - player_health.getHitCount() ) * 10, temp_storage, 10 );
				current_life_text = temp_storage;
				life_string.SetText( current_life_text + base_life_text );

				explosion_sound.Play();

				space_tear_clock.Reset();

			}

			for(int i = 0; i < enemy_animation.size(); i++)	//checks if any collisions have occurred between the player and enemies
			{
				if( collisions.collisionDetection(player_position, sf::Vector2f( player_width, player_height ), enemy_position[i], sf::Vector2f( enemy_width, enemy_height ) ) == true && space_tear_clock.GetElapsedTime() > SPACE_TEAR_TIME )	//collisions occurred
				{
					space_tear_animation.initializeCoordinates( space_tear_row_sprites, space_tear_column_sprites, space_tear_animation_limit, sf::Vector2f( space_tear_width, space_tear_height ), 0, space_tear_sprite, sf::Vector2f(player_position.x - player_width, player_position.y - player_height) );
					space_tear_animation.setCurrentlyAnimating( true );

					player_health.damage(1);

					//update life text
					itoa( (player_health.getMaxHitCount() - player_health.getHitCount() ) * 10, temp_storage, 10 );
					current_life_text = temp_storage;
					life_string.SetText( current_life_text + base_life_text );

					explosion_sound.Play();

					space_tear_clock.Reset();

				}
			}

			//player_health.render(true, sf::Vector2f( player_position.x + 2.0, player_position.y - 7.0) );	//updates the health bar position
			player_health.render( sf::Vector2f( player_position.x + 2.0, player_position.y - 7.0 ) );	//updates the health bar position and possibly changes its animation

		

			App.Clear();


			App.Draw( background_sprite );

			for(int i = 0; i < space_tear_animation.size(); i++)
			{
				space_tear_animation.draw(i, App);
			}

			for(int i = 0; i < enemy_animation.size(); i++)	//draws all the enemy animations to the screen
			{
				enemy_animation.draw(i, App);
			}

			if( enemy_follow_animation.size() > 0 )	//if the follow enemy exists
			{
				enemy_follow_animation.draw(0, App);
			}

			for(int i = 0; i < enemy_warp_animation.size(); i++)
			{
				enemy_warp_animation.draw(i, App);
			}


			if( wormhole_animation.size() > 0 )
			{
				wormhole_animation.draw(0, App);
				//App.Draw( wormhole_sprite );
			}

			player_health.draw(App);	//draws the health bar to the screen
			player_animation.draw(0, App);
			App.Draw( level_string );
			App.Draw( countdown_string );
			App.Draw( number_of_enemies_string );
			App.Draw( life_string );

			if( music_display_clock.GetElapsedTime() <= 2.0 )	//display music volume
			{
				if( music_control == true )
				{
					App.Draw( music_volume_string );
				}

				else
				{
					App.Draw( sound_fx_volume_string );
				}
			}

			else if( music_clock.GetElapsedTime() <= 2.0 )	//display music control
			{
				App.Draw( music_control_string );
			}

			else if( sound_fx_clock.GetElapsedTime() <= 2.0 )	//display sound fx control
			{
				App.Draw( sound_fx_control_string );
			}

			if( countdown > 30 )
			{
				itoa(countdown - 30, temp_storage, 10);
				start_game_countdown_text = temp_storage;
				start_game_countdown_string.SetText( start_game_countdown_text );
				App.Draw( start_game_countdown_string );
			}

			App.Display();

		}


		if( countdown == 0 && level_complete == true)	//wormhole should now be created
		{
			
			if( survival_mode == false )
			{
				if( level > highest_level_normal_mode )
				{
					highest_level_normal_mode = level;
				}

				if( enemy_animation.size() > most_enemies_normal_mode )
				{
					most_enemies_normal_mode = enemy_animation.size();
				}
			}

			else
			{
				if( level > highest_level_survival_mode )
				{
					highest_level_survival_mode = level;
				}

				if( enemy_animation.size() > most_enemies_survival_mode )
				{
					most_enemies_survival_mode = enemy_animation.size();
				}

			}
				level++;	//the player has reached a new level
				itoa(level, temp_storage, 10);
				current_level_text = temp_storage;	
				level_string.SetText( level_base_text + current_level_text );


				countdown = COUNTDOWN_TIME;	//reset timer
				countdown_clock.Reset();	//reset

				if( survival_mode == false )	//if the player isn't playing survival mode
				{
					player_health.setHitCount(0);	//reset player health to full
					player_health.setCurrentDamage(true);

					//update life text
					itoa( (player_health.getMaxHitCount() - player_health.getHitCount() ) * 10, temp_storage, 10 );
					current_life_text = temp_storage;
					life_string.SetText( current_life_text + base_life_text );
				}

				for(int i = enemy_animation.size() - 1; i >= 0; i--)
				{
					enemy_animation.erase(i);
					enemy_position.erase( enemy_position.begin() + i );
					enemy_speed.erase( enemy_speed.begin() + i );

				}

				if( enemy_follow_animation.size() > 0 )
				{
					enemy_follow_animation.erase(0);
				}

				bool level_continue = false;
				bool level_continue_mouse_left = false;	//if the mouse is on the left side, true, else false.
			
				App.Draw( level_complete_text );
				App.Draw( level_complete_continue_text );

				level_complete_quit_text.SetColor( sf::Color(255, 0, 0) );
				App.Draw( level_complete_quit_text );
				App.Display();

				while( level_continue == false && App.IsOpened() )	//loops until the player wants to continue or quit
				{

					if( level_continue_mouse_left == false && ( App.GetInput().GetMouseX() <= (SCREEN_W / 2) ) )	//if the mouse cursor is on the left side of the screen and it's set to false
					{
						level_continue_mouse_left = true;	//the mouse cursor is on the left side of the screen
						level_complete_continue_text.SetColor( sf::Color(255, 0, 0) );	//continue turns red
						level_complete_quit_text.SetColor( sf::Color(255, 255, 255) );	//quit turns white

						//resets the display since it's changed
						//App.Clear();
						App.Draw( level_complete_text );
						App.Draw( level_complete_continue_text );
						App.Draw( level_complete_quit_text );
						App.Display();

					}

					else if( level_continue_mouse_left == true && ( App.GetInput().GetMouseX() > (SCREEN_W / 2) ) )
					{
						level_continue_mouse_left = false;	//the mouse cursor is on the right side of the screen
						level_complete_continue_text.SetColor( sf::Color(255, 255, 255) );	//continue turns white
						level_complete_quit_text.SetColor( sf::Color(255, 0, 0) );	//quit turns red

						//resets the display since it's changed
						//App.Clear();
						App.Draw( level_complete_text );
						App.Draw( level_complete_continue_text );
						App.Draw( level_complete_quit_text );
						App.Display();
					}
				
					if( App.GetInput().IsMouseButtonDown( sf::Mouse::Left ) )
					{

						if( level_continue_mouse_left == true )	//if the cursor is on the left side of the screen
						{
							level_continue = true;	//the player wants to continue to the next level

							//number of enemies text update
							itoa(enemy_animation.size(), temp_storage, 10);
							current_number_of_enemies_text = temp_storage;
							number_of_enemies_string.SetText( number_of_enemies_base_text + current_number_of_enemies_text );
							player_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//starting position
							enemy_spawn_clock.Reset();
						}

						else
						{
							ofstream config_file2("config2.txt");	//used for the high scores

							if( config_file2.fail() )	//the file failed to open
							{
								cout << "Failed to open config file 2" << endl;
								App.Close();
							}

							//sends the high scores to the text file for record
							config_file2 << highest_level_normal_mode << endl;
							config_file2 << most_enemies_normal_mode << endl;
							config_file2 << highest_level_survival_mode << endl;
							config_file2 << most_enemies_survival_mode << endl;
							config_file2.close();

							App.Close();	//the player doesn't want to play anymore
						}

					}
				

					while( App.GetEvent( e ) )
					{
						if( e.Type == sf::Event::Closed || ( e.Type == sf::Event::KeyPressed && e.Key.Code == sf::Key::Escape ) )
						{

							ofstream config_file2("config2.txt");	//used for the high scores

							if( config_file2.fail() )	//the file failed to open
							{
								cout << "Failed to open config file 2" << endl;
								App.Close();
							}

							//sends the high scores to the text file for record
							config_file2 << highest_level_normal_mode << endl;
							config_file2 << most_enemies_normal_mode << endl;
							config_file2 << highest_level_survival_mode << endl;
							config_file2 << most_enemies_survival_mode << endl;
							config_file2.close();

							App.Close();
						}
					}
			
				}


			//}
		}

	

		else if( player_health.getHitCount() == player_health.getMaxHitCount() )	//the player died
		{

			if( survival_mode == false )
			{
				if( level > highest_level_normal_mode )
				{
					highest_level_normal_mode = level;
				}

				if( enemy_animation.size() > most_enemies_normal_mode )
				{
					most_enemies_normal_mode = enemy_animation.size();
				}
			}

			else
			{
				if( level > highest_level_survival_mode )
				{
					highest_level_survival_mode = level;
				}

				if( enemy_animation.size() > most_enemies_survival_mode )
				{
					most_enemies_survival_mode = enemy_animation.size();
				}

			}

			//reset only the necessary variables
			level = 1;	//resets the game
			itoa(level, temp_storage, 10);
			current_level_text = temp_storage;	
			level_string.SetText( level_base_text + current_level_text );


			countdown = COUNTDOWN_TIME;	//reset timer
			countdown_clock.Reset();	//reset
			player_health.setHitCount(0);	//reset player health to full
			player_health.setCurrentDamage(true);

			//update life text
			itoa( (player_health.getMaxHitCount() - player_health.getHitCount() ) * 10, temp_storage, 10 );
			current_life_text = temp_storage;
			life_string.SetText( current_life_text + base_life_text );
			

			//delete all the current objects
			for(int i = enemy_animation.size() - 1; i >= 0; i--)
			{
				enemy_animation.erase(i);
				enemy_position.erase( enemy_position.begin() + i );
				enemy_speed.erase( enemy_speed.begin() + i );

			}

			if( enemy_follow_animation.size() > 0 )
			{
				enemy_follow_animation.erase(0);
			}

			bool level_restart = false;
			bool level_restart_mouse_left = false;	//if the mouse is on the left side, true, else false.
			
			App.Draw( level_failed_text );
			App.Draw( level_failed_text2 );
			App.Draw( level_restart_text );

			level_complete_quit_text.SetColor( sf::Color(255, 0, 0) );
			App.Draw( level_complete_quit_text );
			App.Display();

			while( level_restart == false && App.IsOpened() )	//loops until the player wants to continue or quit
			{

				if( level_restart_mouse_left == false && ( App.GetInput().GetMouseX() <= (SCREEN_W / 2) ) )	//if the mouse cursor is on the left side of the screen and it's set to false
				{
					level_restart_mouse_left = true;	//the mouse cursor is on the left side of the screen
					level_restart_text.SetColor( sf::Color(255, 0, 0) );	//continue turns red
					level_complete_quit_text.SetColor( sf::Color(255, 255, 255) );	//quit turns white

					//resets the display since it's changed
					//App.Clear();
					App.Draw( level_failed_text );
					App.Draw( level_failed_text2 );
					App.Draw( level_restart_text );
					App.Draw( level_complete_quit_text );
					App.Display();

				}

				else if( level_restart_mouse_left == true && ( App.GetInput().GetMouseX() > (SCREEN_W / 2) ) )
				{
					level_restart_mouse_left = false;	//the mouse cursor is on the right side of the screen
					level_restart_text.SetColor( sf::Color(255, 255, 255) );	//continue turns white
					level_complete_quit_text.SetColor( sf::Color(255, 0, 0) );	//quit turns red

					//resets the display since it's changed
					//App.Clear();
					App.Draw( level_failed_text );
					App.Draw( level_failed_text2 );
					App.Draw( level_restart_text );
					App.Draw( level_complete_quit_text );
					App.Display();
				}
				
				if( App.GetInput().IsMouseButtonDown( sf::Mouse::Left ) )
				{

					if( level_restart_mouse_left == true )	//if the cursor is on the left side of the screen
					{
						level_restart = true;	//the player wants to continue to the next level

						//number of enemies text update
						itoa(enemy_animation.size(), temp_storage, 10);
						current_number_of_enemies_text = temp_storage;
						number_of_enemies_string.SetText( number_of_enemies_base_text + current_number_of_enemies_text );
						player_position = sf::Vector2f(SCREEN_W / 2, SCREEN_H / 2);	//starting position
						enemy_spawn_clock.Reset();
					}

					else
					{
						ofstream config_file2("config2.txt");	//used for the high scores

						if( config_file2.fail() )	//the file failed to open
						{
							cout << "Failed to open config file 2" << endl;
							App.Close();
						}

						//sends the high scores to the text file for record
						config_file2 << highest_level_normal_mode << endl;
						config_file2 << most_enemies_normal_mode << endl;
						config_file2 << highest_level_survival_mode << endl;
						config_file2 << most_enemies_survival_mode << endl;
						config_file2.close();

						App.Close();	//the player doesn't want to play anymore
					}

				}


				while( App.GetEvent( e ) )
				{
					if( e.Type == sf::Event::Closed || ( e.Type == sf::Event::KeyPressed && e.Key.Code == sf::Key::Escape ) )
					{
						ofstream config_file2("config2.txt");	//used for the high scores

						if( config_file2.fail() )	//the file failed to open
						{
							cout << "Failed to open config file 2" << endl;
							App.Close();
						} 

						//sends the high scores to the text file for record
						config_file2 << highest_level_normal_mode << endl;
						config_file2 << most_enemies_normal_mode << endl;
						config_file2 << highest_level_survival_mode << endl;
						config_file2 << most_enemies_survival_mode << endl;
						config_file2.close();

						App.Close();
					}
				}
				
			}

		}	

	}

	return 0;
}