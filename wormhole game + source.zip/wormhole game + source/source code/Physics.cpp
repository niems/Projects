#include "Physics.h"
#include <iostream>
#include <cmath>
using namespace std;


bool Physics::collisionDetection(sf::Vector2f &position1, sf::Vector2f &position1_dimensions, sf::Vector2f &position2, sf::Vector2f &position2_dimensions)
{

	if( ( (position1.x + position1_dimensions.x) < position2.x ) || ( position1.x > ( position2.x + position2_dimensions.x ) ) )
	{
		return false;
	}

	if( ( (position1.y + position1_dimensions.y) < position2.y ) || ( position1.y > ( position2.y + position2_dimensions.y ) ) )
	{
		return false;
	}

	return true;	//no collision occurred
}



bool Physics::offScreen(sf::Vector2f &object_position, sf::Vector2f &object_image_dimensions, sf::Vector2f &camera_view, sf::RenderWindow &App)
{
	if( object_position.x < (camera_view.x - object_image_dimensions.x) || object_position.x > ( App.GetWidth() + camera_view.x ) )	//if the object is off the left or right side of the screen
	{
		return true;
	}

	else if( object_position.y < (camera_view.y - object_image_dimensions.y) || object_position.y > ( App.GetHeight() + camera_view.y ) )
	{
		return true;
	}


	return false;	//the object isn't off the screen
	/*
	if( (cloud_position[i].x >= App.GetWidth() + camera_view.x) || (cloud_position[i].y <= camera_view.y ) )	//if the cloud went off the screen, delete it.
		{
			cloud_position.erase( cloud_position.begin() + i );	
			cloud_move_speed.erase( cloud_move_speed.begin() + i );
			cloud_type.erase( cloud_type.begin() + i );
		}
		*/
}