#include <iostream>
#include <vector>
#include <SFML/graphics.hpp>
#include "Animation.h"
using namespace std;



void Animation::initializeStandard(const int &r_sprites, const int &c_sprites, const int &anim_limit, const sf::Vector2f &image_size, const int &entity_type, sf::Sprite &entity_sprite)
{
	sf::Clock temp_clock;	//used for initialization

	row_sprites.push_back( r_sprites );
	column_sprites.push_back( c_sprites );
	animation_limit.push_back( anim_limit );
	image_dimension.push_back( image_size );

	//sets up the current entity for use
	type.push_back( entity_type );
	sprite.push_back( entity_sprite );
	clock.push_back( temp_clock );
	source.push_back( sf::Vector2f(0.0, 0.0) );
	last_direction_source.push_back( source.back().y );
	first_pass.push_back(1);
	currently_animating.push_back(false);


	sprite.back().SetSubRect( sf::IntRect( source.back().x, source.back().y, source.back().x + ( image_dimension.back().x / column_sprites.back() ), source.back().y + ( image_dimension.back().y / row_sprites.back() ) ) );
}

//SECOND
void Animation::initializeCoordinates(const int &r_sprites, const int &c_sprites, const int &anim_limit, const sf::Vector2f &image_size, const int &entity_type, sf::Sprite &entity_sprite, sf::Vector2f &entity_coordinates)
{
	sf::Clock temp_clock;	//used for initialization

	row_sprites.push_back( r_sprites );
	column_sprites.push_back( c_sprites );
	animation_limit.push_back( anim_limit );
	image_dimension.push_back( image_size );

	//sets up the current entity for use
	type.push_back( entity_type );
	sprite.push_back( entity_sprite );
	clock.push_back( temp_clock );
	source.push_back( sf::Vector2f(0.0, 0.0) );
	last_direction_source.push_back( source.back().y );
	first_pass.push_back(1);
	currently_animating.push_back(false);
	coordinates.push_back( entity_coordinates );


	sprite.back().SetSubRect( sf::IntRect( source.back().x, source.back().y, source.back().x + ( image_dimension.back().x / column_sprites.back() ), source.back().y +( image_dimension.back().y / row_sprites.back() ) ) );
	sprite.back().SetPosition( coordinates.back() );
}



void Animation::update_loop_stationary(int i)
{

	if( clock[i].GetElapsedTime() >= animation_limit[i] )	//if it's been long enough
	{
		clock[i].Reset();

		source[i].x += ( image_dimension[i].x / column_sprites[i] );	//gets the next sprite in the column


		if( source[i].x >= image_dimension[i].x )	//if source[i].x has reached the end of the animation, reset.
		{
			source[i].x = 0.0;	//reset
		}

		//crops out the new animation for the next iteration
		sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y +( image_dimension[i].y / row_sprites[i] ) ) );

		//SHOULDN'T HAVE TO SET THE POSITION ON THIS ONE BECAUSE IF YOU USE THIS FUNCTION YOU SHOULD ALSO USE
		//THE 'INTIALIZE_COORDINATES' FUNCTION AND HAVE SET THE POSITION THEN. SINCE IT'S STATIONARY THE POSITION WON'T CHANGE.
	}
}


void Animation::update_loop_stationary(int i, float &animation_limit)
{

	if( clock[i].GetElapsedTime() >= animation_limit )	//if it's been long enough
	{
		clock[i].Reset();

		source[i].x += ( image_dimension[i].x / column_sprites[i] );	//gets the next sprite in the column


		if( source[i].x >= image_dimension[i].x )	//if source[i].x has reached the end of the animation, reset.
		{
			source[i].x = 0.0;	//reset
		}

		//crops out the new animation for the next iteration
		sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y +( image_dimension[i].y / row_sprites[i] ) ) );

		//SHOULDN'T HAVE TO SET THE POSITION ON THIS ONE BECAUSE IF YOU USE THIS FUNCTION YOU SHOULD ALSO USE
		//THE 'INTIALIZE_COORDINATES' FUNCTION AND HAVE SET THE POSITION THEN. SINCE IT'S STATIONARY THE POSITION WON'T CHANGE.
	}
}

void Animation::update_loop_moving(int i, sf::Vector2f &position)	//could use for projectiles
{
	/*
	if( clock[i].GetElapsedTime() >= animation_limit[i] )	//if it's been long enough
	{
		clock[i].Reset();

		//source[i].x += ( image_dimension[i].x / column_sprites[i] );	//gets the next sprite in the column


		if( source[i].x >= image_dimension[i].x && currently_animating[i] == true )	//if the current animation has finished
		{
			//currently_animating[i] = false;	//doesn't need to be set to false because it loops until something external occurs.
			//first_pass[i] = 1;	//reset

			source[i].x = 0.0;	//resets animation since it's a loop
		}

		else if( first_pass[i] == 0 )	//REPLACE WITH 'FIRST_PASS == FALSE'.  When the element is created, it will be set to true. USED TO BE SOURCE[I].X > 0.0
		{
			source[i].x += image_dimension[i].x / column_sprites[i];	//gets the next animation

			//assigns the new animation to the sprite
			sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y + ( image_dimension[i].y / row_sprites[i] ) ) );
		}

		//crops out the new animation for the next iteration
		//sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y + ( image_dimension[i].y / row_sprites[i] ) ) );
	}
	*/

	if( clock[i].GetElapsedTime() >= animation_limit[i] )	//if it's been long enough
	{
		clock[i].Reset();

		if( source[i].x >= image_dimension[i].x )	//if source[i].x has reached the end of the animation, reset.
		{
			source[i].x = 0.0;	//reset
		}

		//crops out the new animation for the next iteration
		sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y +( image_dimension[i].y / row_sprites[i] ) ) );

		source[i].x += ( image_dimension[i].x / column_sprites[i] );	//gets the next sprite in the column
		//SHOULDN'T HAVE TO SET THE POSITION ON THIS ONE BECAUSE IF YOU USE THIS FUNCTION YOU SHOULD ALSO USE
		//THE 'INTIALIZE_COORDINATES' FUNCTION AND HAVE SET THE POSITION THEN. SINCE IT'S STATIONARY THE POSITION WON'T CHANGE.
	}

	sprite[i].SetPosition( position );	//sets the new position of the sprite regardless if the animation updates.

}


void Animation::update_loop_moving(int i, sf::Vector2f &position, float &animation_limit)
{
	if( clock[i].GetElapsedTime() >= animation_limit )	//if it's been long enough
	{
		clock[i].Reset();

		if( source[i].x >= image_dimension[i].x )	//if source[i].x has reached the end of the animation, reset.
		{
			source[i].x = 0.0;	//reset
		}

		//crops out the new animation for the next iteration
		sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y +( image_dimension[i].y / row_sprites[i] ) ) );

		source[i].x += ( image_dimension[i].x / column_sprites[i] );	//gets the next sprite in the column
		//SHOULDN'T HAVE TO SET THE POSITION ON THIS ONE BECAUSE IF YOU USE THIS FUNCTION YOU SHOULD ALSO USE
		//THE 'INTIALIZE_COORDINATES' FUNCTION AND HAVE SET THE POSITION THEN. SINCE IT'S STATIONARY THE POSITION WON'T CHANGE.
	}

	sprite[i].SetPosition( position );	//sets the new position of the sprite regardless if the animation updates.

}


bool Animation::update_runthrough_stationary_new(int i, float animation_limit)
{
	if( clock[i].GetElapsedTime() >= animation_limit )	//if it's been long enough
	{
		clock[i].Reset();

		if( source[i].x >= image_dimension[i].x )	//if source[i].x has reached the end of the animation, reset.
		{
			return false;	//returns false if it's done animating
		}

		//crops out the new animation for the next iteration
		sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y +( image_dimension[i].y / row_sprites[i] ) ) );

		source[i].x += ( image_dimension[i].x / column_sprites[i] );	//gets the next sprite in the column
		//SHOULDN'T HAVE TO SET THE POSITION ON THIS ONE BECAUSE IF YOU USE THIS FUNCTION YOU SHOULD ALSO USE
		//THE 'INTIALIZE_COORDINATES' FUNCTION AND HAVE SET THE POSITION THEN. SINCE IT'S STATIONARY THE POSITION WON'T CHANGE.
	}

	return true;	//means it's still animating
}


void Animation::update_characterMove_stationary(int i)
{
	/*
	if(clock[i].GetElapsedTime() >= animation_limit)
	{
		//toggle_clock.Reset();
		clock[i].Reset();

		if(source[i].y != c_source.y)	//if the character has changed directions
		{
			source[i].x = 0;	//resets animation to the standing position
			source[i].y = c_source.y;	//updates the directional animation
		}

		else if( velocity.x != 0 || velocity.y != 0)	//the character is moving
		{
			source[i].x += Image1.GetWidth() / column_sprites;	//changes to the next animation
		}

		else	//the character is standing still
		{
			source[i].x = 0;	//sets the character to the standing position
		}

			////////////////////////

		if( source[i].x >= Image1.GetWidth() )	//if source[i].x has reached the end of the row
		{
			source[i].x = 0;	//resets animation
		}

		//updates the animation of sprite 'object'.
		Object[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + (Image1.GetWidth() / column_sprites), source[i].y + (Image1.GetHeight() / row_sprites) ) );
		//clock[i].Reset();	//resets the clock since animation occurred.
	}
	*/

	if( clock[i].GetElapsedTime() >= animation_limit[i] )	//if it's been long enough the animation updates
	{
		clock[i].Reset();

		if( source[i].y != last_direction_source[i] )	//if the character has changed directions
		{
			source[i].x = 0;	//resets the animation to the first position since the character changed directions
			last_direction_source[i] = source[i].y;	//updates the new direction
		}

		//NEED TO MAKE VELOCITY VECTORS OR SOME WAY TO KNOW IF THE CHARACTER'S MOVED SINCE THE LAST ITERATION.

	}

}


void Animation::update_runthrough_stationary(int i, float angle)
{

	if( clock[i].GetElapsedTime() >= animation_limit[i] )	//if it's been long enough, a new animation is set
	{
		clock[i].Reset();

		//SHOULDN'T HAVE TO DO A CASE FOR SOURCE[I].X = 0.0 BECAUSE THE POSITION AND CROP SHOULD BE SET FROM EITHER INITIALIZATION FUNCTION.

		if( source[i].x >= image_dimension[i].x && currently_animating[i] == true )	//if the animation has finished
		{
			currently_animating[i] = false;	//the animation isn't being animated any longer
			first_pass[i] = 1;	//reset
		}

		else if( first_pass[i] == 0 )	//REPLACE WITH 'FIRST_PASS == FALSE'.  When the element is created, it will be set to true. USED TO BE SOURCE[I].X > 0.0
		{
			source[i].x += image_dimension[i].x / column_sprites[i];	//gets the next animation

			//assigns the new animation to the sprite

			sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y + ( image_dimension[i].y / row_sprites[i] ) ) );
			sprite[i].SetRotation( angle );
		}

		
		else if( first_pass[i] == 1 )	//the first pass has occurred, so it's set to false so the next time the source[i].x will update.
		{
			first_pass[i] = 0;
			sprite[i].SetRotation( angle );
		}
		
	}
	
}


void Animation::update_runthrough_moving(int i, float angle, bool change_animation, sf::Vector2f &position)	//if the sprite is connected to a body, probably should pass box2d body converted
{
	//used outisde of the animation check because 'change_animation' will only be true for one iteration and if it's not the iteration that animates it wouldn't get changed.
	if( change_animation == true )	//switch to the next animation on source[i].y
	{

			if( ( source[i].y + (image_dimension[i].y / row_sprites[i]) ) < image_dimension[i].y )	//progresses to the next animation in the series
			{
				source[i].y += image_dimension[i].y / row_sprites[i];
			}

			else
			{
				source[i].y = 0.0;	//resets because the animation series has finished.
			}

	}

	if( clock[i].GetElapsedTime() >= animation_limit[i] )	//if it's been long enough, a new animation is set
	{

		clock[i].Reset();

		//SHOULDN'T HAVE TO DO A CASE FOR SOURCE[I].X = 0.0 BECAUSE THE POSITION AND CROP SHOULD BE SET FROM EITHER INITIALIZATION FUNCTION.
		if( source[i].x >= image_dimension[i].x && currently_animating[i] == true )	//if the animation has finished
		{
			currently_animating[i] = false;	//no longer attacking because the animation finished.
			first_pass[i] = 1;	//reset for the next attack
			//erase(i);	//erases the information for the current object
		}

		else if( first_pass[i] == 0 )	//When the element is created, it will be set to true.
		{
			source[i].x += image_dimension[i].x / column_sprites[i];	//gets the next animation

			//assigns the new animation to the sprite
			sprite[i].SetPosition( position );	//sets the new position for the sprite
			sprite[i].SetRotation( angle );
			sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + ( image_dimension[i].x / column_sprites[i] ), source[i].y +( image_dimension[i].y / row_sprites[i] ) ) );
		}

		
		else if( first_pass[i] == 1 )	//the first pass has occurred, so it's set to false so the next time the source[i].x will update.
		{
			first_pass[i] = 0;
			sprite[i].SetPosition( position );	//sets the new position for the sprite
			sprite[i].SetRotation( angle );
		}
		
	}

	else	//only update the sprite position
	{
		sprite[i].SetPosition( position );
		sprite[i].SetRotation( angle );
	}

	//can't set the sprite position out here because of the erase function, at the end there will be an out of range error.
}


//draws the current entity to the screen
void Animation::draw(int i, sf::RenderWindow &App)
{
	App.Draw( sprite[i] );
}

//erases all the data for the current entity
void Animation::erase(int i)
{
	//goes through each vector and checks if it's being used. If it is, it deletes the ith element of it.
	if( type.size() > 0 )
	{
		type.erase( type.begin() + i );
	}

	if( clock.size() > 0 )
	{
		clock.erase( clock.begin() + i );
	}

	if( source.size() > 0 )
	{
		source.erase( source.begin() + i );
	}

	if( sprite.size() > 0 )
	{
		sprite.erase( sprite.begin() + i );
	}

	if( coordinates.size() > 0 )
	{
		coordinates.erase( coordinates.begin() + i );
	}

	if( row_sprites.size() > 0 )
	{
		row_sprites.erase( row_sprites.begin() + i );
	}

	if( column_sprites.size() > 0 )
	{
		column_sprites.erase( column_sprites.begin() + i );
	}

	if( animation_limit.size() > 0 )
	{
		animation_limit.erase( animation_limit.begin() + i );
	}

	if( image_dimension.size() > 0 )
	{
		image_dimension.erase( image_dimension.begin() + i );
	}

	if( last_direction_source.size() > 0 )
	{
		last_direction_source.erase( last_direction_source.begin() + i );
	}

	if( first_pass.size() > 0 )
	{
		first_pass.erase( first_pass.begin() + i );
	}

	if( currently_animating.size() > 0 )
	{
		currently_animating.erase( currently_animating.begin() + i );
	}

}




//OPTIONAL FUNCTIONS:

//to use this you must use one of the initialization functions first
void Animation::resetSprite(int i, sf::Sprite &temp_sprite)
{
	sprite[i] = temp_sprite;

	sprite[i].SetSubRect( sf::IntRect( source[i].x, source[i].y, source[i].x + (image_dimension[i].x / column_sprites[i]), source[i].y + (image_dimension[i].y / row_sprites[i]) ) );
}


void Animation::resetSprite(sf::Sprite &temp_sprite)
{
	sprite.back() = temp_sprite;

	sprite.back().SetSubRect( sf::IntRect( source.back().x, source.back().y, source.back().x + ( image_dimension.back().x / column_sprites.back() ), source.back().y + ( image_dimension.back().y / row_sprites.back() ) ) );
}