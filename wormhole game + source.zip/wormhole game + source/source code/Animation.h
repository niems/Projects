#ifndef ANIMATION_H
#define ANIMATION_H


#include <iostream>
#include <vector>
#include <SFML/Graphics.hpp>
using namespace std;


class Animation
{
private:

	//the enemy type will effect which of the variables that aren't being destroyed it uses.
	vector<sf::Vector2f> image_dimension;
	vector<const int> row_sprites;
	vector<const int> column_sprites;
	vector<const int> animation_limit;
	vector<bool> currently_animating;	//'true' if the character is currently attacking, false otherwise.

	//MAKE A VECTOR THAT HOLDS THE LAST DIRECTION OF THE PLAYER, ONLY UPDATING IF THE DIRECTION IS DIFFERENT.
	//THIS WILL BE USED FOR ANIMATED ENEMIES SO THAT IT KNOWS WHEN THEY SWITCH DIRECTIONS SO THAT SOURCE.X CAN RESET TO 0.

	vector<const int> type;					//ONE PER ENEMY. Used with character image to store the image for the specific type of enemy. Use enum with this from the main function.
	vector<sf::Clock> clock;				//ONE PER ENEMY. Used to keep track of how much time has elapsed for the current character. 
	vector<sf::Vector2f> source;			//ONE PER ENEMY. 
	vector<sf::Sprite>	sprite;				//ONE PER ENEMY. If possible, use one sprite to draw all the same sprites to the screen. This could be the case with circular projectiles
											//which look the same when fired from any direction.  Have two types of functions for drawing, one specific for using one sprite to draw
											//all of the same sprite to the screen using the 'type', and another to draw all the sprites to the screen using their individual sprites.

	vector<sf::Vector2f> coordinates;	//coordinates of the entity. not used for everything. In old class it was used for animations that didn't move
	vector<float> last_direction_source;	//used to store the last direction the character was traveling.  It does this by checking this against the current source[i].y; if it's different that means the character is moving in a different direction.  Only updates if it isn't equal to source[i].y
	vector<int> first_pass;	//used to determine if the current 'source' has been updated once or not.  'first_pass' always starts as false and becomes true after the first update.
	sf::Sprite temp_sprite;		//used to store the current sprite and initialize 'sprite'
	

public:
	//*********************************************************************************************************************
	//USE FUNCTIONS IN THIS ORDER.
	
	//ONLY USE ONE INITIALIZATION FUNCTION PER CHARACTER! CREATING ONE PER ANIMATION INSTEAD IS INEFFICIENT AND UNNECESSARY.
	void initializeStandard(const int &r_sprites, const int &c_sprites, const int &anim_limit, const sf::Vector2f &image_size, const int &entity_type, sf::Sprite &entity_sprite);

	//this one uses coordinates to keep the animation in one place(used for explosions or anything that has a stationary animation)
	void initializeCoordinates(const int &r_sprites, const int &c_sprites, const int &anim_limit, const sf::Vector2f &image_size, const int &entity_type, sf::Sprite &entity_sprite, sf::Vector2f &entity_coordinates);



	//different animation types for updating: loop, explosion(run through the animation and then delete the information), and the character animation(this animation doesn't delete unless the player dies).
	//maybe make less abstract to make use easier, ex.  meleeFrontAttack as a function

	//UPDATES: LOOP TYPE
	void update_loop_stationary(int i);	//updates a stationary loop animation(uses the coordinates vector from the class)
	void update_loop_stationary(int i, float &animation_limit);
	void update_loop_moving(int i, sf::Vector2f &position);	//updates a moving loop animation(uses coordinates passed to the function)
	void update_loop_moving(int i, sf::Vector2f &position, float &animation_limit);

	void update_characterMove_stationary(int i);	//updates the type of animation that would be used for a character walking(an animation that only animates in certain cases, ie when you press buttons or something else), but in this case using the coordinates supplied by the 'initializeCoordinates' function; could be used for turrets since they only update based on the characters position and are stationary.
	void update_characterMove_moving(int i, sf::Vector2f &position);	//updates the type of animation that would be used for a character walking(an animation that only animates in certain cases).

	void update_runthrough_stationary(int i, float angle);	//updates an animation that runs through the whole animation in a stationary position using the coordinates from the 'initializeCoordinates' function, then deletes itself.
	void update_runthrough_moving(int i, float angle, bool change_animation, sf::Vector2f &position);	//updates an animation that runs through the whole animation while moving, then deletes itself.  'change_animation' is optional; if true, it will automatically switch to the next source[i].y down unless that takes it off of the image, in which case it resets.  This can be used for melee combo attacks.
	bool update_runthrough_stationary_new(int i, float animation_limit);	//similar to update_runthrough_stationary

	//HAVE ALL THE SLASH MELEE ATTACKS ON THE SAME SPRITE SHEET.

	void draw(int i, sf::RenderWindow &App);	//draws the current sprite to the screen


	//ONLY DELETE THE INFORMATION IF THE ENEMY HAS DIED. THIS WILL ALLOW FOR UPDATING SOURCE[I].Y
	void erase(int i);	//erases everything for the current object


	//optional
	int size()	{ return( type.size() ); }	//returns the current size of the instance of the Animation class 

	sf::Sprite getSprite(int i) { return( sprite[i] ); }	//returns the current sprite

	sf::Vector2f getSource(int i) { return( source[i] ); }	    //returns the current source
	sf::Vector2f getSource()      { return( source.back() ); }	//returns the last source
	
	sf::Vector2f getSpritePosition(int i) { return( sprite[i].GetPosition() ); }		//returns the position of the current sprite
	sf::Vector2f getSpritePosition()	  { return( sprite.back().GetPosition() ); }	//returns the last sprite's position

	sf::Vector2f getImageDimension(int i) { return( image_dimension[i] ); }	    //returns the current image dimension
	sf::Vector2f getImageDimension()      { return( image_dimension.back() ); }	//returns the last image dimension

	int getRowSprites(int i) { return( row_sprites[i] ); }	    //returns the current row sprites
	int getRowSprites()      { return( row_sprites.back() ); }	//returns the last row sprites

	int getColumnSprites(int i) { return( column_sprites[i] ); }	    //returns the current column sprites
	int getColumnSprites()      { return( column_sprites.back() ); }	//returns the last column_sprites

	bool getCurrentlyAnimating(int i) { return( currently_animating[i] ); }		//returns if the current character is attacking
	bool getCurrentlyAnimating()	  { return( currently_animating.back() ); }	//returns if the last character is attacking

	const int getType(int i) { return( type[i] ); }		//returns the current type
	const int getType()		 { return( type.back() ); }	//returns the last type

	void setSource(int i, sf::Vector2f temp_source) { source[i] = temp_source; }		//used to reset the current source
	void setSource(sf::Vector2f temp_source)		{ source.back() = temp_source; }	//used to reset the last source

	void setPosition(int i, sf::Vector2f &position) { sprite[i].SetPosition( position ); }		//sets the position of the current sprite
	void setPosition(sf::Vector2f &position)		{ sprite.back().SetPosition( position); }	//sets the position of the last sprite

	void resetSprite(int i, sf::Sprite &temp_sprite);	//resets the ith sprite
	void resetSprite(sf::Sprite &temp_sprite);			//resets the last sprite

	void setCurrentlyAnimating(int i, bool c_attacking) { currently_animating[i] = c_attacking; }	   //used to set if the current character is attacking
	void setCurrentlyAnimating(bool c_attacking)        { currently_animating.back() = c_attacking; }  //used to set if the last character is attacking


};

#endif
