#include <SFML/Graphics.hpp>
#include "Health.h"
#include <iostream>
using namespace std;

/*
//////////////////////////////////////////////////////////////////////////////////////////
//sets the health bar position to above the current character location and modifies the bars width and color if necessary
void Health::renderAll() 
{
	//make it so the temp sf::shape is only created if the player has been hit, that way the shapes aren't being created all the time.
	//could have two render functions, one that only sets the position of the bar because no hits have occurred since the last iteration
	//and the other could be called inside the hit function and could modify the bar width and color since they'll only be modified
	//if the player gets hit.

	//modifies the health bars width depending on the number of hits the player/enemy has taken.
	sf::Shape temp = sf::Shape::Rectangle(0.0, 0.0, bar_widths - ( (bar_widths / max_hitss) * hit_count.back() ), bar_heights, sf::Color( 255, 255, 255 ) );
	health_bar.back() = temp;
	//health_bar.SetPosition( character_position.x - 10, character_position.y + 5 - bar_height );


	int color_switch = max_hitss / 3;	//3 stands for the number of colors(green to yellow to red).

	if(hit_count.back() < color_switch)	//green health bar
	{
		health_bar.back().SetColor( sf::Color(0, 255, 0) );
	}

	else if(hit_count.back() < ( color_switch * 2 ) )	//yellow health bar
	{
		health_bar.back().SetColor( sf::Color(255, 255, 0) );
	}

	else	//red health bar
	{
		health_bar.back().SetColor( sf::Color(255, 0, 0) );
	}
}
////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////
//sets the health bar position to above the current character location and modifies the bars width and color if necessary
void Health::renderAll(int i) 
{
	//make it so the temp sf::shape is only created if the player has been hit, that way the shapes aren't being created all the time.
	//could have two render functions, one that only sets the position of the bar because no hits have occurred since the last iteration
	//and the other could be called inside the hit function and could modify the bar width and color since they'll only be modified
	//if the player gets hit.

	//modifies the health bars width depending on the number of hits the player/enemy has taken.
	sf::Shape temp = sf::Shape::Rectangle(0.0, 0.0, bar_widths - ( (bar_widths / max_hitss) * hit_count[i] ), bar_heights, sf::Color( 255, 255, 255 ) );
	health_bar[i] = temp;
	//health_bar.SetPosition( character_position.x - 10, character_position.y + 5 - bar_height );


	int color_switch = max_hitss / 3;	//3 stands for the number of colors(green to yellow to red).

	if(hit_count[i] < color_switch)	//green health bar
	{
		health_bar[i].SetColor( sf::Color(0, 255, 0) );
	}

	else if(hit_count[i] < ( color_switch * 2 ) )	//yellow health bar
	{
		health_bar[i].SetColor( sf::Color(255, 255, 0) );
	}

	else	//red health bar
	{
		health_bar[i].SetColor( sf::Color(255, 0, 0) );
	}
}
////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////
void Health::renderBarr(sf::Vector2f &position)
{
	health_bar.back().SetPosition( position.x - 10, position.y + 5 - bar_heights );
}
///////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////
void Health::renderBarr(int i, sf::Vector2f &position)
{
	health_bar[i].SetPosition( position.x - 10, position.y + 5 - bar_heights );
}
//////////////////////////////////////////////////////////////////////////////////////////




*/


////////////////////////////////////////////////
//NEW FUNCTIONS

//used to create the health bar for the current character.  All parameters have default values in case not specified.
void Health::initialize( sf::Shape &shape, double m_health, double b_width, double b_height, int m_hits, int h_count )	
{
	health_bar.push_back( shape );			//initializes the shape of the health bar
	max_health.push_back( m_health );		//initializes the max health for the current character
	bar_width.push_back( b_width );			//initializes the bar width for the current character
	bar_height.push_back( b_height );		//initializes the bar height for the current character
	max_hits.push_back( m_hits );			//initializes the max hits for the current character
	hit_count.push_back( h_count );			//initializes the hit count for the current character

	//new
	current_damage.push_back(false);	//the current target is set to not currently being damaged

	//this is used in the render function so that the function call doesn't have to create this shape every iteration.
	//temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width.back() - ( (bar_width.back() / max_hits.back() ) * hit_count.back() ), bar_height.back(), sf::Color( 255, 255, 255 ) );
	temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width.back(), bar_height.back(), sf::Color( 255, 255, 255 ) );
}



void Health::damage(int damage_taken)			//damage taken for the last character created
{
	hit_count.back() += damage_taken;	//increases the current hit count by the damage taken

	if( hit_count.back() > max_hits.back() )	//if the damage taken exceeds the max hit count, it corrects it
	{
		hit_count.back() = max_hits.back();
	}

	//new
	current_damage.back() = true;	//damage is set to true since damage was just taken

}



void Health::damage(int i, int damage_taken)	//damage taken for the current character
{
	hit_count[i] += damage_taken;	//increases the current hit count by the damage taken

	if( hit_count[i] > max_hits[i] )	//if the damage taken exceeds the max hit count, it corrects it
	{
		hit_count[i] = max_hits[i];
	}

	//new
	current_damage[i] = true;	//damage is set to true since damage was just taken
}

/*
//used to change the color of the health bar if necessary and set it's position of the current health bar
void Health::render(int i, sf::Vector2f &position)
{
	health_bar[i].SetColor( temp_shape.GetColor() );

	int color_switch = max_hits[i] / 3;	//3 stands for the number of colors(green to yellow to red).

	if(hit_count[i] < color_switch)	//green health bar
	{
		health_bar[i].SetColor( sf::Color(0, 255, 0) );
	}

	else if(hit_count[i] < ( color_switch * 2 ) )	//yellow health bar
	{
		health_bar[i].SetColor( sf::Color(255, 255, 0) );
	}

	else	//red health bar
	{
		health_bar[i].SetColor( sf::Color(255, 0, 0) );
	}


	//set health bar position
	health_bar[i].SetPosition( position.x - 10, position.y + 5 - bar_height[i] );
}


//used to change the color of the health bar if necessary and set it's position of the last health bar created
void Health::render(sf::Vector2f &position)
{
	health_bar.back() = temp_shape;


	int color_switch = max_hits.back() / 3;	//3 stands for the number of colors(green to yellow to red).

	if(hit_count.back() < color_switch)	//green health bar
	{
		health_bar.back().SetColor( sf::Color(0, 255, 0) );
	}

	else if(hit_count.back() < ( color_switch * 2 ) )	//yellow health bar
	{
		health_bar.back().SetColor( sf::Color(255, 255, 0) );
	}

	else	//red health bar
	{
		health_bar.back().SetColor( sf::Color(255, 0, 0) );
	}


	//set health bar position
	health_bar.back().SetPosition( position.x - 10, position.y + 5 - bar_height.back() );

}

*/

void Health::render(sf::Vector2f &position)
{
	if( current_damage.back() == true )	//if the character has taken damage
	{
		//modifies the size of the health bar based on the number of hits taken
		temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width.back() - ( (bar_width.back() / max_hits.back()) * hit_count.back() ), bar_height.back(), sf::Color( 255, 255, 255 ) );

		health_bar.back() = temp_shape;	//assigns the new size of the health bar


		int color_switch = max_hits.back() / 3;	//3 stands for the number of colors(green to yellow to red).

		if(hit_count.back() < color_switch)	//green health bar
		{
			health_bar.back().SetColor( sf::Color(0, 255, 0) );
		}

		else if(hit_count.back() < ( color_switch * 2 ) )	//yellow health bar
		{
			health_bar.back().SetColor( sf::Color(255, 255, 0) );
		}

		else	//red health bar
		{
			health_bar.back().SetColor( sf::Color(255, 0, 0) );
		}

		current_damage.back() = false;	//reset
	}

	//set health bar position
	health_bar.back().SetPosition( position.x - 10, position.y + 5 - bar_height.back() );
}


void Health::render(int i, sf::Vector2f &position)
{

	if( current_damage[i] == true )	//if the character has taken damage
	{
		//modifies the size of the health bar based on the number of hits taken
		temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width[i] - ( (bar_width[i] / max_hits[i]) * hit_count[i] ), bar_height[i], sf::Color( 255, 255, 255 ) );

		health_bar[i] = temp_shape;	//assigns the new size of the health bar

		int color_switch = max_hits[i] / 3;	//3 stands for the number of colors(green to yellow to red).

		if(hit_count[i] < color_switch)	//green health bar
		{
			health_bar[i].SetColor( sf::Color(0, 255, 0) );
		}

		else if(hit_count[i] < ( color_switch * 2 ) )	//yellow health bar
		{
			health_bar[i].SetColor( sf::Color(255, 255, 0) );
		}

		else	//red health bar
		{
			health_bar[i].SetColor( sf::Color(255, 0, 0) );
		}

		current_damage[i] = false;	//reset
	}

	//set health bar position
	health_bar[i].SetPosition( position.x - 10, position.y + 5 - bar_height[i] );
}

void Health::render(bool damage_taken, sf::Vector2f &position)
{
	if( damage_taken == true )	//if the character has taken damage
	{
		//modifies the size of the health bar based on the number of hits taken
		temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width.back() - ( (bar_width.back() / max_hits.back()) * hit_count.back() ), bar_height.back(), sf::Color( 255, 255, 255 ) );

		health_bar.back() = temp_shape;	//assigns the new size of the health bar


		int color_switch = max_hits.back() / 3;	//3 stands for the number of colors(green to yellow to red).

		if(hit_count.back() < color_switch)	//green health bar
		{
			health_bar.back().SetColor( sf::Color(0, 255, 0) );
		}

		else if(hit_count.back() < ( color_switch * 2 ) )	//yellow health bar
		{
			health_bar.back().SetColor( sf::Color(255, 255, 0) );
		}

		else	//red health bar
		{
			health_bar.back().SetColor( sf::Color(255, 0, 0) );
		}
	}

	//set health bar position
	health_bar.back().SetPosition( position.x - 10, position.y + 5 - bar_height.back() );
}


void Health::render(int i, bool damage_taken, sf::Vector2f &position)
{

	if( damage_taken == true )	//if the character has taken damage
	{
		//modifies the size of the health bar based on the number of hits taken
		temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width[i] - ( (bar_width[i] / max_hits[i]) * hit_count[i] ), bar_height[i], sf::Color( 255, 255, 255 ) );

		health_bar[i] = temp_shape;	//assigns the new size of the health bar

		int color_switch = max_hits[i] / 3;	//3 stands for the number of colors(green to yellow to red).

		if(hit_count[i] < color_switch)	//green health bar
		{
			health_bar[i].SetColor( sf::Color(0, 255, 0) );
		}

		else if(hit_count[i] < ( color_switch * 2 ) )	//yellow health bar
		{
			health_bar[i].SetColor( sf::Color(255, 255, 0) );
		}

		else	//red health bar
		{
			health_bar[i].SetColor( sf::Color(255, 0, 0) );
		}
	}

	//set health bar position
	health_bar[i].SetPosition( position.x - 10, position.y + 5 - bar_height[i] );
}


//draws the last created health bar to the screen
void Health::draw(sf::RenderWindow &App)
{
	App.Draw( health_bar.back() );
}



//draws the ith health bar to the screen
void Health::draw(int i, sf::RenderWindow &App)
{
	App.Draw( health_bar[i] );
}



//erases all the information for the ith health bar
//to erase all, just make a while loop in the program and keep erasing the bars using 0 as 'i' until there arent anymore
void Health::erase(int i)
{
	health_bar.erase( health_bar.begin() + i );
	max_health.erase( max_health.begin() + i );
	bar_width.erase( bar_width.begin() + i );
	bar_height.erase( bar_height.begin() + i );
	max_hits.erase( max_hits.begin() + i );
	hit_count.erase( hit_count.begin() + i );
}


//************************************************************************************//
//OPTIONAL FUNCTIONS.  THESE SETTER FUNCTIONS SHOULD ONLY BE USED DURING INITIALIZATION.
void Health::setBarWidth(double width)
{
	bar_width.back() = width;

	//sets the new size of the health bar
	temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width.back(), bar_height.back(), sf::Color( 255, 255, 255 ) );
	health_bar.back() = temp_shape;

}


void Health::setBarWidth(int i, double width)
{
	bar_width[i] = width;

	//sets the new size of the health bar
	temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width[i], bar_height[i], sf::Color( 255, 255, 255 ) );
	health_bar[i] = temp_shape;
}


void Health::setBarHeight(double height)
{
	bar_height.back() = height;

	//sets the new size of the health bar
	temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width.back(), bar_height.back(), sf::Color( 255, 255, 255 ) );
	health_bar.back() = temp_shape;
}


void Health::setBarHeight(int i, double height)
{
	bar_height[i] = height;

	//sets the new size of the health bar
	temp_shape = sf::Shape::Rectangle(0.0, 0.0, bar_width[i], bar_height[i], sf::Color( 255, 255, 255 ) );
	health_bar[i] = temp_shape;
}



