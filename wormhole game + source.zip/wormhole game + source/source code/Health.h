#ifndef HEALTH_H
#define HEALTH_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
using namespace std;


class Health
{
private:
	/*
	//make all these vectors!
	double max_healths;	//maximum health of the player/enemy
	double bar_widths;	//width of the health bar as a sf::shape::rectangle
	double bar_heights;	//height of the health bar as a sf::shape::rectangle

	int max_hitss;	//number of hits the player/enemy can take before death	//THIS NEEDS TO BE A VECTOR SO MORE THAN ONE ENEMY CAN HAVE A CERTAIN NUMBER OF HITS BEFORE DEATH!
	
	*/

	//temp health bar
	sf::Shape temp_shape;

	//NEW EVERYTHING
	vector<sf::Shape> health_bar;	//fade from green, to yellow, to red.
	vector<double> max_health;	//holds the max health of the current character
	vector<double> bar_width;	//holds the bar width of the current character
	vector<double> bar_height;	//holds the bar height for the current character
	vector<int> max_hits;		//holds the max hits for the current character
	vector<int> hit_count;	//current number of hits the player/enemy has taken
	
	//new
	vector<bool> current_damage;	//true if damage has just been taken, used to render true or false automatically without having to pass it as an argument.



public:
	

	/*
	void initialize( sf::Shape &shape, int h_count = 0 ) { health_bar.push_back(shape); hit_count.push_back(h_count); }	//used when creating a new health bar.
	void setHealthBar(sf::Shape &shape)		{ health_bar.push_back(shape); }	//sets the shape of the health bar in the class by a shape passed to the function
	void setBarWidth(double w)			    { bar_widths = w; }		//sets the width for the health bar
	void setBarHeight(double h)			    { bar_heights = h; }		//sets the height for the health bar
	void setMaxHealth(double health = 100)	{ max_healths = health; }//sets the max health for the player/enemy
	void setMaxHits(int hits = 10)		    { max_hitss = hits; }	//sets the max number of hits before the player/enemy dies
	void hitCountIncrease(int i)			{ hit_count[i]++; }		//increases the number of times the player/enemy has been hit for the ith hit_count.
	void hitCountIncrease()					{ hit_count.back()++; }		//increases the number of times the player has been hit.
	void setHitCount(int h)					{ hit_count.back() = h; }		//for resetting the

	void renderBarr(sf::Vector2f &position);	//resets the health bars position to above the current character position
	void renderBarr(int i, sf::Vector2f &position);//resets the ith health bar position to above the current character/enemy position

	void renderAll();		//sets the health bar position to above the current character location and modifies the bars width 
	void renderAll(int i);	//sets the ith health bar position above the current character location and modifies the bars width

													   //and color if necessary. SHOULD BE CALLED AFTER hitCountIncrease()!

	int getHitCount()		    { return hit_count.back(); }
	int getHitCount(int i)		{ return hit_count[i]; }
	int getMaxHitCount(int i)   { return max_hits[i]; }
	int getMaxHitCount()	    { return max_hits.back(); }

	void erases(int i) { hit_count.erase( hit_count.begin() + i ); health_bar.erase( health_bar.begin() + i ); }



	*/

	//ALL NEW FUNCTIONS. FUNCTIONS ARE TO BE USED IN THIS ORDER.
	void initialize( sf::Shape &shape =  sf::Shape::Rectangle(0.0, 0.0, 90, 6.0, sf::Color(255, 255, 255) ), double m_health = 100, double b_width = 50, double b_height = 5, int m_hits = 10, int h_count = 0 );
	

	void damage(int damage_taken);			//damage taken for the last character created
	void damage(int i, int damage_taken);	//damage taken for the current character

	//void render(int i, sf::Vector2f &position);	//renders the position and color of the health bar for the current character
	//void render(sf::Vector2f &position);		//renders the position and color of the last health bar created.

	//new
	void render(int i, bool damage_taken, sf::Vector2f &position);
	void render(bool damage_taken, sf::Vector2f &position);

	//NEWEST - these don't use the damage_taken variable because it's taken care of in the damage function
	void render(int i, sf::Vector2f &position);
	void render(sf::Vector2f &position);

	void draw(sf::RenderWindow &App);	//draws the health bar to the screen.
	void draw(int i, sf::RenderWindow &App);	//draws the ith health bar to the screen.

	void erase(int i);	//erases all the ith health bar information


	//optional
	int size()					 { return health_bar.size(); }	//returns the number of health bars
	int getHitCount()			 { return hit_count.back(); }	//returns the hit count for the last character created
	int getHitCount(int i)		 { return hit_count[i]; }	//returns the hit count for the current character
	int getMaxHitCount()		 { return max_hits.back(); }	//returns the max hits for the last character created
	int getMaxHitCount(int i)	 { return max_hits[i]; }	//returns the max hits for the current character
	bool getCurrentDamage()      { return current_damage.back(); }	//returns the damage for the last character created
	bool getCurrentDamage(int i) {	return current_damage[i]; }	//returns the damage for the current character 

	void setBarWidth(int i, double width);
	void setBarWidth(double width);

	void setBarHeight(int i, double height);
	void setBarHeight(double height);

	void setMaxHealth(int i, double health) { max_health[i] = health; }
	void setMaxHealth(double health)		{ max_health.back() = health; }

	void setMaxHits(int i, int hits)        { max_hits[i] = hits; }
	void setMaxHits(int hits)				{ max_hits.back() = hits; }

	//void setHitCount(int h_count)			{ hit_count.back() = h_count; }
	//void setHitCount(int i, int h_count)	{ hit_count[i] = h_count; }

	void setHitCount(int h_count)
	{
							//this will happen if you use getHitCount() - 1 is used as the argument; because if 
		if( h_count < 0 )	//the hitcount is already 0, then it will be made less than 0.
		{
			hit_count.back() = 0;
		}

		else
		{
			hit_count.back() = h_count;
		}
	}

	void setHitCount(int i, int h_count)
	{
		if( h_count < 0 )	//this will happen if getHitCount() - 1 is used as an argument and the hit count is already 0
		{
			hit_count[i] = 0;
		}

		else
		{
			hit_count[i] = h_count;
		}
	}

	void setCurrentDamage(bool c_damage)        { current_damage.back() = c_damage; }
	void setCurrentDamage(int i, bool c_damage) { current_damage[i] = c_damage; }


	
};

#endif 