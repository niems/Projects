#ifndef TIMED_H
#define TIMED_H

#include <SFML\Graphics.hpp>

class Timed
{
private:
	sf::Clock clock;
	bool paused;	//if true, the clocks elapsed time isn't added to 'time'.  When it's unpaused after being paused, make sure to reset the sf::Clock clock;
	float elapsed_time;		//this is what is returned; the time that has elapsed

public:
	Timed() { paused = false; elapsed_time = 0.0; }
	float getElapsedTime() { return( elapsed_time ); }			  //returns the elapsed time
	void reset()	{ clock.restart(); elapsed_time = 0.0; }			     //restarts the timer
	void pause()	{ paused = true;   }			    //the elapsed time of the clock isn't added to the 'time' variable
	void resume()   { paused = false; clock.restart(); } //unpauses the clock, resuming adding the clocks elapsed time to 'time'

	void update()
	{
		if( paused == false )
		{
			elapsed_time += clock.getElapsedTime().asSeconds();
			clock.restart();
		}
	}
};

#endif