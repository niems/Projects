#include "Animation.h"
//#include "Character.h"
#include "Weapon.h"

/*
void Animation::update_loop(int i, float animation_limit, Character &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )	//if it's time to update
	{
		entity.update_clock[i].restart();

		if( entity.source[i].x >= entity.texture_dimension[i].x )	//if source[i].x has reached the end of the animation, reset.
		{
			entity.source[i].x = 0.0;	//reset
		}

		//crops out the new animation for the next iteration
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );

		//gets the news sprite to be used in the column
		entity.source[i].x += ( entity.texture_dimension[i].x / entity.column_sprites[i] );
	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite
}


bool Animation::update_runthrough(int i, float animation_limit, Character &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )	//if it's time to update
	{
		entity.update_clock[i].restart();

		if( entity.source[i].x >= entity.texture_dimension[i].x )	//if the animation has finished
		{
			return false;	//returns false if it's done animating
		}

		//crops out the new animation for the next iteration
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );

		//gets the news sprite to be used in the column
		entity.source[i].x += ( entity.texture_dimension[i].x / entity.column_sprites[i] );

	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite

	return true;	//returns true if it's still animating
}


void Animation::update_character(int i, float animation_limit, Character &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )
	{
		entity.update_clock[i].restart();	//reset

		if( entity.velocity[i].x != 0 )	//the character is moving (only the x axis is needed since it's a side scroller)
		{
			entity.source[i].x += entity.texture_dimension[i].x / entity.column_sprites[i];	//changes to the next animation
		}

		else  //the character is standing still
		{
			entity.source[i].x = 0;	//sets the character to the first animation(typically the standing animation).
		}

		if( entity.source[i].x >= entity.texture_dimension[i].x )	//if the animation has reached the end, reset
		{
			entity.source[i].x = 0;	//reset animation
		}

		//updates the animation for the current sprite
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );
	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite
}


void Animation::update_character_reverse(int i, float animation_limit, Character &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )
	{
		entity.update_clock[i].restart();	//reset

		if( entity.velocity[i].x != 0 )	//the character is moving
		{
			entity.source[i].x -= entity.texture_dimension[i].x / entity.column_sprites[i];	//changes to the previous animation(moving backwards)
		}

		else //the character is standing still
		{
			entity.source[i].x = 0;	//sets the character to the first animation(typically the standing animation)
		}

		if( entity.source[i].x < 0 )	//the animation has reached the beginning and must be reset to the end
		{
			entity.source[i].x = entity.texture_dimension[i].x - (entity.texture_dimension[i].x / entity.column_sprites[i] );
		}

		//updates the animation for the current sprite
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );
	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite
}


void Animation::update_enemy(int i, float animation_limit, Character &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )
	{
		entity.update_clock[i].restart();	//reset

		if( entity.velocity[i].x != 0 || entity.velocity[i].y != 0 )	//the character is moving
		{
			entity.source[i].x += entity.texture_dimension[i].x / entity.column_sprites[i];	//changes to the next animation
		}

		else  //the character is standing still
		{
			entity.source[i].x = 0;	//sets the character to the first animation(typically the standing animation).
		}

		if( entity.source[i].x >= entity.texture_dimension[i].x )	//if the animation has reached the end, reset
		{
			entity.source[i].x = 0;	//reset animation
		}

		//updates the animation for the current sprite
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );
	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite
}


void Animation::draw(int i, sf::RenderWindow &App, Character &entity)
{
	App.draw( entity.sprite[i] );
}

*/

////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

void Animation::update_loop(int i, float animation_limit, Weapon &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )	//if it's time to update
	{
		entity.update_clock[i].restart();

		if( entity.source[i].x >= entity.texture_dimension[i].x )	//if source[i].x has reached the end of the animation, reset.
		{
			entity.source[i].x = 0.0;	//reset
		}

		//crops out the new animation for the next iteration
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );

		//gets the news sprite to be used in the column
		entity.source[i].x += ( entity.texture_dimension[i].x / entity.column_sprites[i] );
	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite
}


bool Animation::update_runthrough(int i, float animation_limit, Weapon &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )	//if it's time to update
	{
		entity.update_clock[i].restart();

		if( entity.source[i].x >= entity.texture_dimension[i].x )	//if the animation has finished
		{
			return false;	//returns false if it's done animating
		}

		//crops out the new animation for the next iteration
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );

		//gets the news sprite to be used in the column
		entity.source[i].x += ( entity.texture_dimension[i].x / entity.column_sprites[i] );

	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite

	return true;	//returns true if it's still animating
}


bool Animation::update_runthrough_reverse(int i, float animation_limit, Weapon &entity)
{
	if( entity.update_clock[i].getElapsedTime().asSeconds() >= animation_limit )	//if it's time to update
	{
		entity.update_clock[i].restart();

		if( entity.source[i].x < 0 )	//if the animation has finished
		{
			return false;	//returns false if it's done animating
		}

		//crops out the new animation for the next iteration
		entity.sprite[i].setTextureRect( sf::IntRect( entity.source[i].x, entity.source[i].y, entity.texture_dimension[i].x / entity.column_sprites[i],  entity.texture_dimension[i].y / entity.row_sprites[i] ) );

		//gets the news sprite to be used in the column
		entity.source[i].x -= ( entity.texture_dimension[i].x / entity.column_sprites[i] );
	}

	entity.sprite[i].setPosition( entity.position[i] );	//sets the new position of the sprite

	return true;	//returns true if it's still animating
}


void Animation::draw(int i, sf::RenderWindow &App, Weapon &entity)
{
	App.draw( entity.sprite[i] );
}
