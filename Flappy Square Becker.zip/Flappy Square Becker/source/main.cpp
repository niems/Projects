/*
Started coding on the night of 3-04-2014
Finished coding on the night of 3-08-2014
*/

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <ctime>
#include "Weapon.h"
#include "Physics.h"
#include "Timed.h"
#include "Animation.h"
using namespace std;

string float_to_string(float f)	//converts a float to string
{
	stringstream stream;
	  
	stream << f;

	return stream.str();
}

int main()
{
	///////////////////////////////////////
	//SPLASH SCREEN SETUP
	sf::Color master_options_color = sf::Color(0, 255, 0);	//this will be the color of all the options, as well as the highlighted text color for hover effects
	sf::Color master_nonhighlighted_color = sf::Color(255, 255, 255);	//this is the non-highlighted color for all hover effects

	sf::RenderWindow window(sf::VideoMode(900, 700), "Flappy Square   By: Zach Niemann");
	window.setFramerateLimit( 60 );

	sf::RenderWindow splash_screen( sf::VideoMode(900, 700), "Flappy Square   By: Zach Niemann");
	splash_screen.setFramerateLimit( 60 );
	
	sf::Image splash_screen_background_image;
	sf::Texture splash_screen_background_texture;
	sf::Sprite splash_screen_background_sprite;


	sf::Texture flappy_square_texture;
	sf::Sprite flappy_square_sprite;

	sf::Music splash_screen_music;

	sf::Font splash_screen_font;
	sf::Text current_resolution;	//uses the current resolution for the game
	sf::Text fullscreen_resolution;	//makes the game fullscreen
	sf::Text game_title;	//title of the game
	bool fullscreen_option = false;	//if true, the game screen will turn fullscreen
	bool screen_selection = false;	//if true, the player has selected which mode to play in (fullscreen or not)
	bool current_resolution_color_change = false;	//if true, the mouse is over the text and it's green
	bool fullscreen_resolution_color_change = false;	//if true, the mouse is over the text and it's green

	//window.setKeyRepeatEnabled( false );	//also need to take off the jump_clock condition in the if statement for this to fully work
	//window.setIcon();	//might be interesting

	if( !splash_screen_font.loadFromFile("fonts\\PositiveWarp.ttf") )
	{
		cout << "Failed to load warp font" << endl;
		cin.get();
		window.close();
	}  

	if( !flappy_square_texture.loadFromFile("images\\splash_flappy_square.png") )
	{
		cout << "Failed to load the splash flappy square image" << endl;
		cin.get();
		window.close();
	}

	flappy_square_sprite.setTexture( flappy_square_texture );
	flappy_square_sprite.setPosition( (splash_screen.getSize().x / 2.0) - (flappy_square_texture.getSize().x / 2.0), splash_screen.getSize().y / 1.5);

	//sets up the text
	current_resolution.setFont( splash_screen_font );
	fullscreen_resolution.setFont( splash_screen_font );
	game_title.setFont( splash_screen_font );

	current_resolution.setCharacterSize( 50 );
	fullscreen_resolution.setCharacterSize( 50 );
	game_title.setCharacterSize( 110 );

	current_resolution.setString("KEEP CURRENT RESOLUTION");
	fullscreen_resolution.setString("FULLSCREEN");
	game_title.setString(": Flappy Square :");

	current_resolution.setPosition( (window.getSize().x / 2.0) - (current_resolution.getGlobalBounds().width / 2.0), window.getSize().y / 3.0 );
	fullscreen_resolution.setPosition( (window.getSize().x / 2.0) - (fullscreen_resolution.getGlobalBounds().width / 2.0), window.getSize().y / 2.0 );
	game_title.setPosition( 20.0, 20.0 );

	current_resolution.setColor( master_nonhighlighted_color );
	fullscreen_resolution.setColor( master_nonhighlighted_color );
	game_title.setColor( master_options_color );


	if( !splash_screen_background_image.loadFromFile("images\\becker_background.png") )
	{
		cout << "Failed to load splash screen background" << endl;
		cin.get();
		window.close();
		splash_screen.close();
	}

	splash_screen_background_texture.loadFromImage( splash_screen_background_image );
	splash_screen_background_sprite.setTexture( splash_screen_background_texture );

	sf::Vector2f splash_screen_background_scale( static_cast<float>(splash_screen.getSize().x) / splash_screen_background_texture.getSize().x, static_cast<float>(splash_screen.getSize().y) / splash_screen_background_texture.getSize().y );


	splash_screen_background_sprite.scale( splash_screen_background_scale.x, splash_screen_background_scale.y );



	/////////////////////////////////////////////////////////////
	//DIFFICULTY SETUP
	bool max_difficulty = false;	//determines how hard the game should be
	bool difficulty_selection = false;	//true if the player has chosen a difficulty
	bool easy_difficulty_color_change = false; //if true, the mouse is over the text and it's the highlighted color	
	bool hard_difficulty_color_change = false; //if true, the mouse is over the text and it's the highlighted color

	float difficulty_size = 50;	//size of the text
	sf::Text easy_difficulty_text;
	sf::Text easy_difficulty_description_text;	//gives a description of the easy difficulty
	sf::Text hard_difficulty_text;
	sf::Text hard_difficulty_description_text;	//gives a description of the hard difficulty
	sf::Text difficulty_option_text;	//just holds 'difficult: '

	easy_difficulty_text.setFont( splash_screen_font );
	easy_difficulty_description_text .setFont( splash_screen_font );
	hard_difficulty_text.setFont( splash_screen_font );
	hard_difficulty_description_text.setFont( splash_screen_font );
	difficulty_option_text.setFont( splash_screen_font );

	easy_difficulty_text.setCharacterSize( difficulty_size );
	easy_difficulty_description_text.setCharacterSize( difficulty_size );
	hard_difficulty_text.setCharacterSize( difficulty_size );
	hard_difficulty_description_text.setCharacterSize( difficulty_size );
	difficulty_option_text.setCharacterSize( difficulty_size );

	easy_difficulty_text.setString("NOOB");
	easy_difficulty_description_text.setString("GETS PROGRESSIVELY HARDER");
	hard_difficulty_text.setString("BECKER STATUS");
	hard_difficulty_description_text.setString("AS HARD AS IT GETS");
	difficulty_option_text.setString("DIFFICULTY");

	easy_difficulty_text.setColor( master_nonhighlighted_color );
	easy_difficulty_description_text.setColor( master_options_color );
	hard_difficulty_text.setColor( master_nonhighlighted_color );
	hard_difficulty_description_text.setColor( master_options_color );
	difficulty_option_text.setColor( master_options_color );

	difficulty_option_text.setPosition( (window.getSize().x / 2.0) - (difficulty_option_text.getGlobalBounds().width / 2.0), window.getSize().y / 1.8 );
	easy_difficulty_text.setPosition( (window.getSize().x / 5.0) - (easy_difficulty_text.getGlobalBounds().width / 2.0), window.getSize().y / 2.2 );
	easy_difficulty_description_text.setPosition( (window.getSize().x / 2.0) - (easy_difficulty_description_text.getGlobalBounds().width / 2.0), window.getSize().y / 2.6 );
	hard_difficulty_text.setPosition( (window.getSize().x / 1.3) - (hard_difficulty_text.getGlobalBounds().width / 2.0), window.getSize().y / 2.2 );
	hard_difficulty_description_text.setPosition( (window.getSize().x / 2.0) - (hard_difficulty_description_text.getGlobalBounds().width / 2.0), window.getSize().y / 2.6 );

	//END DIFFICULTY SETUP
	//////////////////////////////////////////////////////////////


	//////////////////////////////////////////////////////////////
	//SAWBLADE SETUP
	sf::Image sawblade_images;
	sf::Texture sawblade_textures;
	sf::Sprite saw_sprites;
	vector<sf::Sprite> sawblade_sprites;	//holds all the sawblades

	float sawblade_rotation_angles = 300.0;	//degrees to turn per iteration
	float sawblade_total_widths = 0.0;	//the total width of all the sawblades.  Used to determine how many are needed to fit the screen
	float sawblade_times = 0.0;	//the time that's elapsed since the last update.  Needed so that all the blades spin at the same speed.

	sf::Clock sawblade_clocks;	//keeps track of how much to rotate the sawblades

	if( !sawblade_images.loadFromFile("images\\sawblade.png") )
	{
		cout << "Failed to load sawblade image." << endl;
		cin.get();
		window.close();
	}

	sawblade_images.createMaskFromColor( sf::Color(255, 0, 0) );
	sawblade_textures.loadFromImage( sawblade_images );
	saw_sprites.setTexture( sawblade_textures );

	sawblade_sprites.push_back( saw_sprites );
	sawblade_sprites.back().setOrigin( sawblade_textures.getSize().x / 2.0, sawblade_textures.getSize().y / 2.0 );
	sawblade_sprites.back().setPosition(sawblade_textures.getSize().x / 2.0, window.getSize().y  );

	sawblade_total_widths = sawblade_textures.getSize().x;	//current sawblade total width

	while( sawblade_total_widths < splash_screen.getSize().x)	//loops until there are enough sawblades to fill the bottom of the screen
	{
		sf::Vector2f last_sawblade_position( sawblade_sprites.back().getPosition() );
		sawblade_sprites.push_back( saw_sprites );
		sawblade_sprites.back().setOrigin( sawblade_textures.getSize().x / 2.0, sawblade_textures.getSize().y / 2.0 );
		sawblade_sprites.back().setPosition(last_sawblade_position.x + sawblade_textures.getSize().x, window.getSize().y  );

		sawblade_total_widths += sawblade_textures.getSize().x;	//an additional sawblade was added
	}


	//END SAWBLADE SETUP
	//////////////////////////////////////////////////////////////

	//mouse setup for the start game screen
	sf::Vector2f splash_mouse_size(5.0, 5.0);
	sf::Vector2f splash_mouse_position( sf::Mouse::getPosition(splash_screen).x, sf::Mouse::getPosition(splash_screen).y );
	sf::FloatRect splash_mouse( splash_mouse_position, splash_mouse_size );


	//while the player hasn't chosen to use the current resolution/fullscreen 
	while( splash_screen.isOpen() )	
	{
		sf::Event events;

		splash_mouse_position = sf::Vector2f( sf::Mouse::getPosition(splash_screen).x, sf::Mouse::getPosition(splash_screen).y );
	    splash_mouse = sf::FloatRect( splash_mouse_position, splash_mouse_size );

		while( splash_screen.pollEvent( events ) )
		{
			if( events.type == sf::Event::Closed )
			{
				splash_screen.close();
				window.close();
			}
		}

		sawblade_times = sawblade_clocks.getElapsedTime().asSeconds();
		//update sawblade animation
		for(int i = 0; i < sawblade_sprites.size(); i++)
		{
			sawblade_sprites[i].rotate( sawblade_rotation_angles * sawblade_times );
		}

		sawblade_clocks.restart();
		if( screen_selection == false )	//if the player hasn't picked a screen resolution yet
		{
			//if the mouse is over the current resolution and it wasn't before
			if( current_resolution.getGlobalBounds().intersects( splash_mouse ) == true && current_resolution_color_change == false)
			{
				current_resolution_color_change = true;
				current_resolution.setColor( master_options_color );
			}

			//if the mouse was over the current resolution but isn't anymore
			else if( current_resolution.getGlobalBounds().intersects( splash_mouse ) == false && current_resolution_color_change == true )
			{
				current_resolution_color_change = false;
				current_resolution.setColor( master_nonhighlighted_color );
			}

			//if the mouse is over the fullscreen resolution and it wasn't before
			if( fullscreen_resolution.getGlobalBounds().intersects( splash_mouse ) == true && fullscreen_resolution_color_change == false)
			{
				fullscreen_resolution_color_change = true;
				fullscreen_resolution.setColor( master_options_color );
			}

			//if the mouse was over the fullscreen resolution but isn't anymore
			else if( fullscreen_resolution.getGlobalBounds().intersects( splash_mouse ) == false && fullscreen_resolution_color_change == true )
			{
				fullscreen_resolution_color_change = false;
				fullscreen_resolution.setColor( master_nonhighlighted_color );
			}

			//if the player presses the left mouse button
			if( sf::Mouse::isButtonPressed( sf::Mouse::Left ) )
			{
				//if the player wants to keep the current resolution
				if( current_resolution_color_change == true )
				{
					fullscreen_option = false;
					screen_selection = true;	//player has picked a resolution
					//splash_screen.close();
				}

				//if the player wants the fullscreen resolution
				else if( fullscreen_resolution_color_change == true )
				{
					fullscreen_option = true;
					screen_selection = true;	//player has picked a resolution
					//splash_screen.close();
				}
			}
		}

		else //the player has picked the screen resolution but not the difficulty
		{
			//if the mouse is over the current resolution and it wasn't before
			if( easy_difficulty_text.getGlobalBounds().intersects( splash_mouse ) == true && easy_difficulty_color_change == false)
			{
				easy_difficulty_color_change = true;
				easy_difficulty_text.setColor( master_options_color );
			}

			//if the mouse was over the current resolution but isn't anymore
			else if( easy_difficulty_text.getGlobalBounds().intersects( splash_mouse ) == false && easy_difficulty_color_change == true )
			{
				easy_difficulty_color_change = false;
				easy_difficulty_text.setColor( master_nonhighlighted_color );
			}

			//if the mouse is over the fullscreen resolution and it wasn't before
			if( hard_difficulty_text.getGlobalBounds().intersects( splash_mouse ) == true && hard_difficulty_color_change == false)
			{
				hard_difficulty_color_change = true;
				hard_difficulty_text.setColor( master_options_color );
			}

			//if the mouse was over the fullscreen resolution but isn't anymore
			else if( hard_difficulty_text.getGlobalBounds().intersects( splash_mouse ) == false && hard_difficulty_color_change == true )
			{
				hard_difficulty_color_change = false;
				hard_difficulty_text.setColor( master_nonhighlighted_color );
			}

			//if the player presses the left mouse button
			if( sf::Mouse::isButtonPressed( sf::Mouse::Left ) )
			{
				//if the player wants to keep the current resolution
				if( easy_difficulty_color_change == true )
				{
					max_difficulty = false;	//set to easy mode
					splash_screen.close();
				}

				//if the player wants the fullscreen resolution
				else if( hard_difficulty_color_change == true )
				{
					max_difficulty = true;	//set to hard mode
					splash_screen.close();
				}
			}

		}

		splash_screen.clear();

		splash_screen.draw( splash_screen_background_sprite );

		for(int i = 0; i < sawblade_sprites.size(); i++)
		{
			splash_screen.draw( sawblade_sprites[i] );
		}

		splash_screen.draw( flappy_square_sprite );
		splash_screen.draw( game_title );

		if( screen_selection == false )	//if the player hasn't picked a screen resolution yet
		{
			splash_screen.draw( current_resolution );
			splash_screen.draw( fullscreen_resolution );
		}

		else //the player has picked a screen resolution but not the difficulty
		{
			splash_screen.draw( difficulty_option_text );
			splash_screen.draw( easy_difficulty_text );
			splash_screen.draw( hard_difficulty_text );

			if( easy_difficulty_color_change == true )
			{
				splash_screen.draw( easy_difficulty_description_text );
			}

			else if( hard_difficulty_color_change == true )
			{
				splash_screen.draw( hard_difficulty_description_text );
			}
		}

		splash_screen.display();
	}

	sawblade_sprites.clear();
	cout << sawblade_sprites.size() << endl;


	if( fullscreen_option == true )	//fullscreen mode
	{
		window.create( sf::VideoMode(900, 700), "Flappy Square   By: Zach Niemann", sf::Style::Fullscreen );
	}


	//END SPLASH SCREEN SETUP
	///////////////////////////////////////



	Physics physics;
	srand( time(0) );

	Animation animation;


	int score = 0;	//the number of spikes flappy bird has jumped through

	string score_string = float_to_string(score);	//the current score as a string

	cout << "Score: " << score << endl;

	bool flappy_bird_alive = true;	//if false, flappy bird has died.
	bool update = false;	//if false, the game is paused.
	bool start_game = false;	//this is for if they haven't started the game yet
	Timed update_clock;	
	float update_clock_limit = 0.5;	//how often you can pause/unpause the game in seconds

	/////////////////////////////////////////////////////////////
	//MUSIC SETUP
	sf::Music background_music;
	int background_music_volume = 20;
	sf::Text mute_text;
	sf::Clock mute_music_clock;	//keeps track of how long it's been since the last mute/unmute
	bool mute_music = false;	//if true, music is muted
	float mute_music_limit = 0.5;	//how often you can mute the music

	mute_text.setFont( splash_screen_font );
	mute_text.setCharacterSize( 50 );
	mute_text.setColor( master_options_color );
	mute_text.setString(": Press M to MUTE sound");
	mute_text.setPosition( 0.0, window.getSize().y / 2.0 );

	if( !background_music.openFromFile("music\\crystallize.ogg") )
	{
		cout << "Failed to load background music." << endl;
		cin.get();
		window.close();
	}

	background_music.setLoop( true );
	background_music.setVolume( background_music_volume );
	background_music.play();

	//END MUSIC SETUP
	////////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////////
	//SOUNDS SETUP
	sf::SoundBuffer jump_buffer;
	sf::Sound jump_sound;
	int jump_sound_volume = 15;

	sf::SoundBuffer achievement_buffer;
	sf::Sound achievement_sound;
	int achievement_sound_volume = 30;

	sf::SoundBuffer game_over_buffer;
	sf::Sound game_over_sound;
	int game_over_sound_volume = 100;
	bool game_over_sound_played = false;	//if true, it has played and won't loop

	if( !jump_buffer.loadFromFile("sounds\\jump.wav") )
	{
		cout << "Failed to load jump sound." << endl;
		cin.get();
		window.close();
	}

	jump_sound.setBuffer( jump_buffer );
	jump_sound.setVolume( jump_sound_volume );

	if( !achievement_buffer.loadFromFile("sounds\\achievement.wav") )
	{
		cout << "Failed to load achievement sound." << endl;
		cin.get();
		window.close();
	}

	achievement_sound.setBuffer( achievement_buffer );
	achievement_sound.setVolume( achievement_sound_volume );

	if( !game_over_buffer.loadFromFile("sounds\\game_over.wav") )
	{
		cout << "Failed to load game over sound." << endl;
		cin.get();
		window.close();
	}

	game_over_sound.setBuffer( game_over_buffer );
	game_over_sound.setVolume( game_over_sound_volume );

	//END SOUNDS SETUP
	/////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////
	//font setup
	sf::Font font;

	if( !font.loadFromFile("fonts\\PositiveWarp.ttf") )
	{
		cout << "Failed to load font 1" << endl;
		cin.get();
		window.close();
	}

	//paused text
	sf::Text paused_text;
	paused_text.setFont( font );
	paused_text.setString("PAUSED");
	paused_text.setColor( master_options_color );
	paused_text.setPosition( window.getSize().x / 2.5, window.getSize().y / 2.5 );
	paused_text.setCharacterSize(80);


	//end font setup
	/////////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////////
	//SCORE SETUP
	sf::Text score_text;
	score_text.setFont( font );
	score_text.setString( score_string );
	score_text.setColor( master_options_color );
	score_text.setPosition( window.getSize().x / 2.1, -10.0 );
	score_text.setCharacterSize( 70 );

	//END SCORE SETUP
	////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////
	//START GAME TEXT
	int character_size = 50;
	bool start_game_color_change = false;	//if true, the mouse is over the start text and the color has changed.
	sf::Text start_game_text;
	sf::Text start_game_instructions1;
	sf::Text start_game_instructions2;

	start_game_text.setFont( font );
	start_game_instructions1.setFont( font );
	start_game_instructions2.setFont( font );

	start_game_text.setColor( master_nonhighlighted_color );
	start_game_instructions1.setColor( master_options_color );
	start_game_instructions2.setColor( master_options_color );

	start_game_text.setCharacterSize( character_size );
	start_game_instructions1.setCharacterSize( character_size );
	start_game_instructions2.setCharacterSize( character_size );

	start_game_text.setPosition( window.getSize().x / 2.3, window.getSize().y / 4.0 );
	start_game_instructions1.setPosition( 0.0, window.getSize().y / 1.6 );
	start_game_instructions2.setPosition( 0.0, window.getSize().y / 1.3 );

	start_game_text.setString("START");
	start_game_instructions1.setString(": Press SPACE to jump");
	start_game_instructions2.setString(": Press ESCAPE to pause");


	//mouse setup for the start game screen
	sf::Vector2f mouse_size(5.0, 5.0);
	sf::Vector2f mouse_position( sf::Mouse::getPosition(window).x, sf::Mouse::getPosition(window).y );

	sf::FloatRect mouse( mouse_position, mouse_size );

	//END START GAME TEXT
	///////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////
	//DEATH TEXT 
	sf::Text death_text;
	vector<string> death_messages;
	string death_message1 = "Try not to suck next time";

	int number_of_death_messages = 1;	//used with rand() to pull from the vector
	int current_death_message = 0;	//default set to 0.  The current death message pulled from the vector.
	int death_text_size = 50;

	bool death_message_selected = false;	//if true, the death message has been picked so it doesn't need to change. 
											//resets when the user starts the game over.

	death_text.setFont( font );
	death_text.setColor( sf::Color(0, 255, 0) );
	death_text.setCharacterSize( death_text_size );


	//puts all the death messages in the vector
	death_messages.push_back( death_message1 );

	//END DEATH TEXT
	/////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	//HIGH SCORE TEXT
	fstream highscore_file;	//used to read in the current highscore of the player for easy mode, and change it if they get a new high score.
	//fstream hard_highscore_file("hs\\hinfo.txt", fstream::in | fstream::out);	//used to read in the current highscore of the player for hard mode, and change it if they get a new high score.

	sf::Text highscore_text;
	string highscore_base_string = ": HIGHSCORE ";
	string current_highscore_string = "";	//holds the players highscore

	int current_highscore = 0;	//read in from the file
	
	if( max_difficulty == false )	//easy mode
	{
		highscore_file.open("hs\\einfo.txt", fstream::in | fstream::out);
		highscore_file >> current_highscore;
	}

	else
	{
		highscore_file.open("hs\\hinfo.txt", fstream::in | fstream::out);
		highscore_file >> current_highscore;
	}

	if( !highscore_file.is_open() )	//if the file didn't open properly
	{
		cout << "Failed to open highscore file." << endl;
		cin.get();
		window.close();
	}
	

	current_highscore_string = float_to_string( current_highscore );
	cout << "current highscore: " << current_highscore << endl;

	highscore_text.setFont( font );
	highscore_text.setColor( master_options_color );
	highscore_text.setCharacterSize( 50 );
	highscore_text.setPosition( 0.0, window.getSize().y / 2.8 );

	highscore_text.setString( highscore_base_string + current_highscore_string );


	//END HIGH SCORE TEXT
	///////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	//RESTART TEXT
	sf::Text restart_text;
	bool restart_game_color_change = false;	//if true, restarts the game.

	restart_text.setFont( font );
	restart_text.setColor( master_nonhighlighted_color );
	restart_text.setCharacterSize( 50 );
	restart_text.setPosition( window.getSize().x / 2.3, window.getSize().y / 4.0 );

	restart_text.setString("RESTART");

	if( flappy_bird_alive == false && restart_game_color_change == false )
	{
		restart_game_color_change = true;	//

		//erase all spike bars

		//restart clocks
	}


	//END RESTART TEXT
	///////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////
	//gravity / jumping setup

	float scale = 6.0;

	sf::Vector2f gravity(0.0, scale * 3.0 * (window.getSize().y / 600.0) );	//gravity is pixels per second in the positive y direction
	sf::Vector2f jump_velocity(0.0, scale * -1.0 * (window.getSize().y / 600.0) );	//jumps at this many pixels per second in the negative y direction


	sf::Vector2f current_velocity(0.0, 0.0);	//current velocity of flappy bird

	Timed jump_clock;	//how long it's been since the last flappy bird jump.  This tells how fast it should be falling
	float jump_limit = 0.15;	//how often flappy bird can jump
	bool jump = false;		//if true, flappy bird has jumped recently and it's still in effect.
	//end gravity / jumping setup
	//////////////////////////////////////////////////////////////


	///////////////////////////////////////////////////////////////
	//FLAPPY BIRD SETUP
	sf::Image flappy_bird_image;
	sf::Texture flappy_bird_texture;
	sf::Texture flappy_bird_dead_texture;
	sf::Sprite flappy_bird_sprite;
	
	float gap_height_start = 0.0;	//how big the gap height starts at for the reset
	float gap_height = 0.0;	//height of the gap that flappy bird jumps through
	float gap_closing = 15.0;	//evertime you score a point, the gap shrinks
	float gap_closing_limit = 0.0;	//the smallest the gap will get

	sf::Vector2f flappy_bird_current_velocity(0.0, 0.0);	//current velocity of the player
	sf::Vector2f flappy_bird_start_position(window.getSize().x / 4.0, window.getSize().y / 4.5);

	if( !flappy_bird_dead_texture.loadFromFile("images\\dead_square.png") )
	{
		cout << "Failed to load dead square" << endl;
		cin.get();
		window.close();
	}


	if( !flappy_bird_image.loadFromFile("images\\tester2.png") )
	{
		cout << "Failed to load flappy bird :(" << endl;
		cin.get();
		window.close();	//closes the window since
	}

	flappy_bird_image.createMaskFromColor( sf::Color(255, 0, 255) );
	flappy_bird_texture.loadFromImage( flappy_bird_image );
	flappy_bird_sprite.setTexture( flappy_bird_texture );

	flappy_bird_sprite.setPosition( flappy_bird_start_position.x, flappy_bird_start_position.y );	//starting pos for flappy bird

	//gap_height = flappy_bird_texture.getSize().y * 6.0;	//this is the gap size flappy bird jumps through.
	gap_height = 300.0;
	gap_height_start = gap_height;	//starting size for reset

	//gap_closing_limit = flappy_bird_texture.getSize().y * 1.6;	//the smallest the gap will get
	gap_closing_limit = 59.0;

	if( max_difficulty == true )	//starts at max difficulty
	{
		gap_height = gap_closing_limit;
	}

	//END FLAPPY BIRD SETUP
	/////////////////////////////////////////////////////////////


	////////////////////////////////////////////////////////////
	//BARS SETUP(the shit you have to jump over/under)
	sf::Image bar_image;
	sf::Texture bar_texture;
	sf::Sprite b_sprite;
	vector<sf::Sprite> bar_sprite;	//holds all the bars that are being used.  They are erased once they fall off the screen
	vector<bool> bar_passed;	//if flappy bird has passed through the bars, this will be true.  Initialized to false.


	//updates if they score. Make sure to reset.
	float bar_spawn_start_limit = 3.0;	//what the bars spawn start at, used to reset

	float elapsed_bar_time = 0.0;	//how long it's been since the bars have been updated

	float bar_spawn_limit = bar_spawn_start_limit;	//the bars spawn this often, in seconds.  //3.0
	float bar_spawn_extended_limit = 1.2;	//the fastest the bars will spawn
	float bar_spawn_decrease_rate = 0.1;	//how fast the bars increase by when you get a point
	Timed bar_spawn_clock;	//keeps track of the last time a bar spawned.

	

	sf::Vector2f bar_start_speed( -200.0 * (window.getSize().x / 800), 0.0 );	//starting speed of the bars, used to reset.

	sf::Vector2f bar_speed = bar_start_speed;	//bars move on the negative x axis  //200.0
	float bar_speed_increase = -5.0;	//the amount the speed increases each iteration
	float bar_speed_limit = -316.0;	//the fastest the bar speed can be
	Timed bar_speed_clock;	//keeps track of how much to move the bar based on the elapsed time

	if( !bar_image.loadFromFile("images\\spike_inverted.png") )
	{
		cout << "Failed to load the bars image." << endl;
		cin.get();
		window.close();
	}

	bar_image.createMaskFromColor( sf::Color(0, 0, 0) );
	bar_texture.loadFromImage( bar_image );
	b_sprite.setTexture( bar_texture );

	if( max_difficulty == true )	//starts at max difficulty
	{
		bar_speed.x = bar_speed_limit;
		bar_spawn_limit = bar_spawn_extended_limit;
	}

	//END BARS SETUP
	///////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////
	//LIGHTNING BARS SETUP
	Weapon lightning;

	sf::Color lightning_color = sf::Color(255, 255, 255, 150);

	sf::Image lightning_image;
	sf::Texture lightning_texture;

	int lightning_row_sprites = 1;
	int lightning_column_sprites = 10;

	float lightning_animation_limit = 0.05;	//how fast the lightning animates
	float top_lightning_rotation = 90.0;	//degrees to rotate the top lightning sprite
	float bottom_lightning_rotation = -90.0;	//degrees to rotate the bottom lightning sprite

	if( !lightning_image.loadFromFile("images\\lightning_animation.png") )
	{
		cout << "Failed to load lightning" << endl;
		cin.get();
		window.close();
	}

	lightning_image.createMaskFromColor( sf::Color(255, 0, 255) );
	lightning_texture.loadFromImage( lightning_image );
	sf::Sprite lightning_sprite;

	//END LIGHTNING BARS SETUP
	//////////////////////////////////////////////////////////


	/////////////////////////////////////////////////////////////
	//BACKGROUND SETUP
	sf::Texture background_texture;
	sf::Sprite background_sprite;

	if( !background_texture.loadFromFile("images\\becker_background.png") )
	{
		cout << "Failed to load background image." << endl;
		cin.get();
		window.close();
	}

	background_sprite.setTexture( background_texture );
	background_sprite.scale( window.getSize().x / static_cast<float>(background_texture.getSize().x), window.getSize().y / static_cast<float>(background_texture.getSize().y) );	//scales the background to fit the window
	//background_sprite.setScale( window.getSize().x / static_cast<float>(background_texture.getSize().x), window.getSize().y / static_cast<float>(background_texture.getSize().y) ); //scales the background to fit the window
	//END BACKGROUND SETUP
	///////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////
	//SAWBLADE SETUP
	sf::Image sawblade_image;
	sf::Texture sawblade_texture;
	sf::Sprite saw_sprite;
	vector<sf::Sprite> sawblade_sprite;	//holds all the sawblades

	float sawblade_rotation_angle = 300.0;	//degrees to turn per iteration
	float sawblade_total_width = 0.0;	//the total width of all the sawblades.  Used to determine how many are needed to fit the screen
	float sawblade_time = 0.0;	//the time that's elapsed since the last update.  Needed so that all the blades spin at the same speed.

	sf::Clock sawblade_clock;	//keeps track of how much to rotate the sawblades

	if( !sawblade_image.loadFromFile("images\\sawblade.png") )
	{
		cout << "Failed to load sawblade image." << endl;
		cin.get();
		window.close();
	}

	sawblade_image.createMaskFromColor( sf::Color(255, 0, 0) );
	sawblade_texture.loadFromImage( sawblade_image );
	saw_sprite.setTexture( sawblade_texture );


	sawblade_sprite.push_back( saw_sprite );
	sawblade_sprite.back().setOrigin( sawblade_texture.getSize().x / 2.0, sawblade_texture.getSize().y / 2.0 );
	sawblade_sprite.back().setPosition(sawblade_texture.getSize().x / 2.0, window.getSize().y  );

	sawblade_total_width = sawblade_texture.getSize().x;	//current sawblade total width

	while( sawblade_total_width < window.getSize().x)	//loops until there are enough sawblades to fill the bottom of the screen
	{
		sf::Vector2f last_sawblade_position( sawblade_sprite.back().getPosition() );
		sawblade_sprite.push_back( saw_sprite );
		sawblade_sprite.back().setOrigin( sawblade_texture.getSize().x / 2.0, sawblade_texture.getSize().y / 2.0 );
		sawblade_sprite.back().setPosition(last_sawblade_position.x + sawblade_texture.getSize().x, window.getSize().y  );

		sawblade_total_width += sawblade_texture.getSize().x;	//an additional sawblade was added

	}


	//END SAWBLADE SETUP
	//////////////////////////////////////////////////////////////


	sf::Event e;
	//game loop
	while( window.isOpen() )
	{

		while( window.pollEvent( e ) )
		{
			if( e.type == sf::Event::Closed )	//window has been closed
			{
				window.close();
			}

		}

		if( sf::Keyboard::isKeyPressed( sf::Keyboard::M ) && mute_music_clock.getElapsedTime().asSeconds() >= mute_music_limit )
		{
			//if they want to mute the music
			if( mute_music == false )
			{
				mute_music = true;
				background_music.setVolume( 0 );
				game_over_sound.setVolume( 0 );
				achievement_sound.setVolume( 0 );
				jump_sound.setVolume( 0 );
			}

			//if they don't want to mute the music
			else
			{
				mute_music = false;
				background_music.setVolume( background_music_volume );
				game_over_sound.setVolume( game_over_sound_volume );
				achievement_sound.setVolume( achievement_sound_volume );
				jump_sound.setVolume( jump_sound_volume );
			}

			mute_music_clock.restart();
		}

		
		if( start_game == false && update == false)	//only runs if the game hasn't started
		{
			//updates the mouse position
			sf::Vector2f mouse_position( sf::Mouse::getPosition(window).x, sf::Mouse::getPosition(window).y );	
			sf::FloatRect mouse( mouse_position, mouse_size );

			//if the mouse is on the start game text
			if( start_game_text.getGlobalBounds().intersects( mouse ) == true && start_game_color_change == false )	
			{
				start_game_color_change = true;	//the mouse is on the start game text
				start_game_text.setColor( master_options_color );	//green start text
			}

			//if the mouse is not over the start game text but the text is still green
			else if( start_game_color_change == true &&  start_game_text.getGlobalBounds().intersects( mouse ) == false )	
			{
				start_game_text.setColor( master_nonhighlighted_color ); //white start text
				start_game_color_change = false;	//the mouse is not over the start text
			}

		
			//the player clicked on the start text
			if( sf::Mouse::isButtonPressed( sf::Mouse::Left ) && start_game_color_change == true )
			{
				start_game = true;	//never runs the start game text while the player is alive
				update = true;	//starts the game

				jump_clock.reset();	//resets this clock so all the gravity doesn't hit the player from the clock updating
				bar_spawn_clock.reset();
				bar_speed_clock.reset();
			}

		}


		//used for pausing/unpausing the game while the player is alive
		if( sf::Keyboard::isKeyPressed( sf::Keyboard::Escape ) && update_clock.getElapsedTime() >= update_clock_limit && flappy_bird_alive == true )
		{
			if( update == true )
			{
				update = false;
				jump_clock.pause();
				bar_spawn_clock.pause();
				bar_speed_clock.pause();

				//window.draw( paused_text );	//draws 'paused' to the screen
				//window.display();

			}

			else
			{
				update = true;
				jump_clock.resume();
				bar_spawn_clock.resume();
				bar_speed_clock.resume();

				if( start_game == false ) //the game hasn't started
				{
					start_game = true;	//the game has started
				}
			}

			update_clock.reset();
		}

		if( flappy_bird_alive == false && update == false )
		{
			//updates the mouse position
			sf::Vector2f mouse_position( sf::Mouse::getPosition(window).x, sf::Mouse::getPosition(window).y );	
			sf::FloatRect mouse( mouse_position, mouse_size );

			
			//if the mouse is over the restart text
			if( restart_text.getGlobalBounds().intersects( mouse ) == true && restart_game_color_change == false )
			{
				restart_text.setColor( master_options_color );	//green restart text
				restart_game_color_change = true;	//the mouse is on the green restart text

			}

			//if the mouse is not over the restart game text but the text is still green
			else if( restart_game_color_change == true && restart_text.getGlobalBounds().intersects( mouse ) == false )
			{
				restart_text.setColor( master_nonhighlighted_color );	//white restart text
				restart_game_color_change = false;	//the mouse is not over the restart text
			}


			//the player clicked on the restart text
			if( sf::Mouse::isButtonPressed( sf::Mouse::Left ) && restart_game_color_change == true )
			{
				//start_game = false;	
				update = true;
				flappy_bird_alive = true;	//it lives :D


				if( max_difficulty == false ) //easy mode
				{
					highscore_file.open("hs\\einfo.txt", fstream::in | fstream::out);	//reopens the file
				}

				else //hard mode
				{
					highscore_file.open("hs\\hinfo.txt", fstream::in | fstream::out);	//reopens the file
				}

				if( !highscore_file.is_open() )	//if the file didn't open properly
				{
					cout << "Failed to open highscore file." << endl;
					cin.get();
					window.close();
				}

				

				game_over_sound_played = false; //reset
				restart_game_color_change = false;	//reset

				if( mute_music == false )
				{
					background_music.setVolume( background_music_volume );
				}

				//reset player sprite
				flappy_bird_sprite.setTexture( flappy_bird_texture );

				//reset bars
				bar_speed = bar_start_speed;
				bar_spawn_limit = bar_spawn_start_limit;

				//reset gap height
				gap_height = gap_height_start; 

				//reset score
				score = 0;
				score_string = float_to_string( score );
				score_text.setString( score_string );

				//reset text color
				restart_text.setColor( master_nonhighlighted_color );

				//reset flappy bird to starting position
				flappy_bird_sprite.setPosition( flappy_bird_start_position.x, flappy_bird_start_position.y );

				//erase all spike bars
				for(int i = bar_sprite.size() - 1; i > -1; i--)
				{
					bar_sprite.erase( bar_sprite.begin() + i );	//erases the current bar because it's off the screen.
					bar_passed.erase( bar_passed.begin() + i );	//erases the current bar passed status.
				}

				//erases all lightning animations
				lightning.eraseAll();

				//restart clocks
				jump_clock.reset();
				bar_spawn_clock.reset();
				bar_speed_clock.reset();

				if( max_difficulty == true )	//starts at max difficulty
				{
					gap_height = gap_closing_limit;
					bar_speed.x = bar_speed_limit;
					bar_spawn_limit = bar_spawn_extended_limit;
				}


			}

		}

		update_clock.update();	//updates outside of the update loop so that you can get out of it after it pauses!

		if( update == true )	//the game isn't paused
		{
			//clock updates
			bar_spawn_clock.update();
			bar_speed_clock.update();
			jump_clock.update();

			//cretes the bars if it's been long enough
			if( bar_spawn_clock.getElapsedTime() >= bar_spawn_limit )
			{
				//bar heights in pixels
				float top_bar_height = rand() % static_cast<int>(window.getSize().y - gap_height - (sawblade_texture.getSize().y * 2.0) ); //the height of the top bar
				float bottom_bar_height = window.getSize().y - gap_height - top_bar_height;	//the bottom bar height is completely dependant on the top bar height

				//finds the number of spikes per upper/lower bar
				int top_number_of_spikes = top_bar_height / bar_texture.getSize().y;
				int bottom_number_of_spikes = bottom_bar_height / bar_texture.getSize().y;

				//finds out how tall the lightning animations should be
				float top_lightning_height = static_cast<float>(top_number_of_spikes) * bar_texture.getSize().y;
				float bottom_lightning_height = (static_cast<float>(bottom_number_of_spikes) * bar_texture.getSize().y) - bar_texture.getSize().y;

				//creates all the top bar spikes
				for(int i = 0; i < top_number_of_spikes; i++)
				{
					bar_sprite.push_back( b_sprite );
					bar_sprite.back().setPosition( window.getSize().x, i * bar_texture.getSize().y );	//places the spikes on top of each other
					bar_passed.push_back( false );	//if flappy bird passes through these bars, it's true.
				}

				
				//creates all the bottom bar spikes
				for(int i = 0; i < bottom_number_of_spikes; i++)
				{
					bar_sprite.push_back( b_sprite );
					bar_sprite.back().setPosition( window.getSize().x + bar_texture.getSize().x, window.getSize().y -(i * bar_texture.getSize().y) );	//places the spikes on top of each other
					bar_passed.push_back( false );	//if flappy bird passes through these bars, it's true.
				}


				//---------------------------------------------------------------------
				//gets the dimensions of the lightning shown on the screen
				sf::Vector2f lightning_dimensions( static_cast<float>(lightning_texture.getSize().x) / lightning_column_sprites, static_cast<float>(lightning_texture.getSize().y) / lightning_row_sprites);

				//top lightning - to delete, check if it's off the left side of the screen
				lightning.initialize( lightning_row_sprites, lightning_column_sprites, lightning_texture, sf::Vector2f(0.0, 0.0), sf::Vector2f(0.0, 0.0), sf::Vector2f(0.0, 0.0), 0 );
				lightning.scale( lightning.size() - 1, sf::Vector2f( top_lightning_height, static_cast<float>(bar_texture.getSize().y) ), sf::Vector2f( lightning_dimensions.x, lightning_dimensions.y ) );
				//lightning.scale( lightning.size() - 1, sf::Vector2f( top_lightning_height, slightning_dimensions.y ), sf::Vector2f( lightning_dimensions.x, lightning_dimensions.y ) );

				lightning.setPosition( lightning.size() - 1, sf::Vector2f( window.getSize().x + bar_texture.getSize().x, 0.0 ), top_lightning_rotation );
				lightning.setSpriteColor( lightning.size() - 1, lightning_color );


				//---------------------------------------------------------------------
				//bottom lightning
				lightning.initialize( lightning_row_sprites, lightning_column_sprites, lightning_texture, sf::Vector2f(0.0, 0.0), sf::Vector2f(0.0, 0.0), sf::Vector2f(0.0, 0.0), 0 );
				lightning.scale( lightning.size() - 1, sf::Vector2f( bottom_lightning_height, static_cast<float>(bar_texture.getSize().y) ), sf::Vector2f( lightning_dimensions.x, lightning_dimensions.y ) );

				lightning.setPosition( lightning.size() - 1, sf::Vector2f( window.getSize().x  + bar_texture.getSize().x, window.getSize().y ), bottom_lightning_rotation );
				lightning.setSpriteColor( lightning.size() - 1, lightning_color );

				bar_spawn_clock.reset();	//resets clock since a bar was just spawned
			}


			 elapsed_bar_time = bar_speed_clock.getElapsedTime();
			//update bar positions
			for(int i = 0; i < bar_sprite.size(); i++)
			{
				bar_sprite[i].setPosition( bar_sprite[i].getPosition().x + (elapsed_bar_time * bar_speed.x), bar_sprite[i].getPosition().y + (elapsed_bar_time * bar_speed.y) );

				//if the current bar sprite is a bottom bar
				if( bar_sprite[i].getPosition().y == window.getSize().y )
				{
					//possible score update
					if( flappy_bird_sprite.getPosition().x > bar_sprite[i].getPosition().x && bar_passed[i] == false ) //if flappy bird has made it through the current bars
					{
						score += 1;	//flappy bird has made it through another pair of spiked bars
						achievement_sound.play();

						bar_passed[i] = true;	//this makes it so this bar doesn't get counted more than once.

						score_string = float_to_string(score);	//the current score as a string
						score_text.setString( score_string );

						cout << "Score: " << score << endl;

						cout << "gap height - gap closing: " << gap_height - gap_closing << endl;
						cout << "gap closing limit: " << gap_closing_limit << endl << endl;

						//if the gap is still able to shrink
						if( (gap_height - gap_closing) >= gap_closing_limit )	
						{
							gap_height -= gap_closing;	//shrinks the gap
							cout << "gap height: " << gap_height << endl;
						}

						//if the bar spawn rate is slower than the fast limit
						if( bar_spawn_limit - bar_spawn_decrease_rate > bar_spawn_extended_limit )
						{
							//decreases the spawn time of the bars
							bar_spawn_limit -= bar_spawn_decrease_rate;	
						}

						//if the bar speed is slower than the fast limit
						if( bar_speed.x + bar_speed_increase > bar_speed_limit )
						{
							//increases the speed the bars move across the screen
							bar_speed.x += bar_speed_increase;
						}
					}

				}

				if( physics.collisionDetection( bar_sprite[i], flappy_bird_sprite ) == true )  // flappy bird hit the boundary D:
				{
					//cout << "hit" << endl;
					//score = 0;
					score_string = float_to_string(score);
					score_text.setString( score_string );
					flappy_bird_alive = false;	//character died
					update = false;	//stops the game

					if( mute_music == false )
					{
						background_music.setVolume( 5 );
					}
					
					if( game_over_sound.getStatus() == sf::Sound::Stopped && game_over_sound_played == false)
					{
						game_over_sound.play();
						game_over_sound_played = true;	//so it wont loop
					}

					//if the player got a new highscore
					if( score > current_highscore )
					{
						current_highscore_string = float_to_string( score );
						highscore_text.setString( highscore_base_string + current_highscore_string );

						if( max_difficulty == false ) //easy mode
						{
							highscore_file.close();
							highscore_file.open("hs\\einfo.txt", fstream::in | fstream::out);
						}

						else //hard mode
						{
							highscore_file.close();
							highscore_file.open("hs\\hinfo.txt", fstream::in | fstream::out);
						}

					

						highscore_file << score;	//writes the new highscore to the file
						highscore_file.close();
					}
					
					//uses dead sprite
					flappy_bird_sprite.setTexture( flappy_bird_dead_texture );
					window.draw( flappy_bird_sprite );

					restart_game_color_change = false;	//reset, true if the player restarts the game
					//start_game = false;	//used for displaying how to play again

					cout << "----------------------------" << endl;
					cout << "DEATH STATS: " << endl;
					cout << "bar speed: " << bar_speed.x << endl;
					cout << "bar spawn rate: " << bar_spawn_limit << endl;
					cout << "gap height: " << gap_height << endl << endl;

				}
			
				//if true, the bar has gone off the screen
				if( physics.offMapLeft( bar_sprite[i].getPosition(), sf::Vector2f( bar_texture.getSize().x, bar_texture.getSize().y ), sf::Vector2f( background_texture.getSize().x, background_texture.getSize().y ) ) == true )
				{
					bar_sprite.erase( bar_sprite.begin() + i );	//erases the current bar because it's off the screen.
					bar_passed.erase( bar_passed.begin() + i );	//erases the current bar passed status.
				}
		
			}
		

			//updates all lightning animations
			for(int i = 0; i < lightning.size(); i++)
			{
				//the lightning animation has gone off screen
				if( physics.offMapLeft( lightning.getPosition(i), sf::Vector2f( lightning.getDimensions(i).x, lightning.getDimensions(i).y ), sf::Vector2f( background_texture.getSize().x, background_texture.getSize().y ) ) == true )
				{
					lightning.erase(i);	//erases the current lightning animation because it's off screen
				}

				else
				{
					if( lightning.getPosition(i).y == 0.0 ) //top lightning
					{
						lightning.setPosition( i, sf::Vector2f( lightning.getPosition(i).x + (elapsed_bar_time * bar_speed.x), lightning.getPosition(i).y + (elapsed_bar_time * bar_speed.y) ), top_lightning_rotation );
					}

					else //bottom lightning
					{
						lightning.setPosition( i, sf::Vector2f( lightning.getPosition(i).x + (elapsed_bar_time * bar_speed.x), lightning.getPosition(i).y + (elapsed_bar_time * bar_speed.y) ), bottom_lightning_rotation );
					}
					//bar_sprite[i].setPosition( bar_sprite[i].getPosition().x + (elapsed_bar_time * bar_speed.x), bar_sprite[i].getPosition().y + (elapsed_bar_time * bar_speed.y) );
				}
			}

			//lightning animations need to update before this resets since they use this clock!
			bar_speed_clock.reset();	//resets since all the bars have just been updated


		
			if( flappy_bird_alive == true )
			{
				if( physics.offMap( flappy_bird_sprite.getPosition(), sf::Vector2f( flappy_bird_texture.getSize().x, flappy_bird_texture.getSize().y ), sf::Vector2f( window.getSize().x, window.getSize().y ) ) == true )
				{
					flappy_bird_alive = false;
					update = false;

					if( mute_music == false )
					{
						background_music.setVolume( 5 );
					}
					
					if( game_over_sound.getStatus() == sf::Sound::Stopped && game_over_sound_played == false)
					{
						game_over_sound.play();
						game_over_sound_played = true;	//so it wont loop
					}

					//if the player got a new highscore
					if( score > current_highscore )
					{
						current_highscore_string = float_to_string( score );
						highscore_text.setString( highscore_base_string + current_highscore_string );

						if( max_difficulty == false) //easy mode
						{
							highscore_file.close();
							highscore_file.open("hs\\einfo.txt", fstream::in | fstream::out);
						}

						else //hard mode
						{
							highscore_file.close();
							highscore_file.open("hs\\hinfo.txt", fstream::in | fstream::out);
						}

						highscore_file << score;	//writes the new highscore to the file
						highscore_file.close();
					}
					
					//uses dead sprite
					flappy_bird_sprite.setTexture( flappy_bird_dead_texture );
					window.draw( flappy_bird_sprite );

					cout << "----------------------------" << endl;
					cout << "DEATH STATS: " << endl;
					cout << "bar speed: " << bar_speed.x << endl;
					cout << "bar spawn rate: " << bar_spawn_limit << endl;
					cout << "gap height: " << gap_height << endl << endl;
				}
			}
		}
			sawblade_time = sawblade_clock.getElapsedTime().asSeconds();
			//update sawblade animation
			for(int i = 0; i < sawblade_sprite.size(); i++)
			{
				sawblade_sprite[i].rotate( sawblade_rotation_angle * sawblade_time );

				if( physics.collisionDetection( sawblade_sprite[i], flappy_bird_sprite ) == true )  // flappy bird hit the boundary D:
				{
					//cout << "hit" << endl;
					//score = 0;
					score_string = float_to_string(score);
					score_text.setString( score_string );
					flappy_bird_alive = false;	//player died
					//gap_height = gap_height_start; //reset gap height
					update = false;	//stops the game

					if( mute_music == false )
					{
						background_music.setVolume( 5 );
					}

					if( game_over_sound.getStatus() == sf::Sound::Stopped && game_over_sound_played == false)
					{
						game_over_sound.play();
						game_over_sound_played = true;	//so it wont loop
					}

					//if the player got a new highscore
					if( score > current_highscore )
					{
						current_highscore_string = float_to_string( score );
						highscore_text.setString( highscore_base_string + current_highscore_string );

						if( max_difficulty == false ) //easy mode
						{
							highscore_file.close();
							highscore_file.open("hs\\einfo.txt", fstream::in | fstream::out);
						}

						else //hard mode
						{
							highscore_file.close();
							highscore_file.open("hs\\hinfo.txt", fstream::in | fstream::out);
						}

						highscore_file << score;	//writes the new highscore to the file
						highscore_file.close();
					}

					//uses dead sprite
					flappy_bird_sprite.setTexture( flappy_bird_dead_texture );
					window.draw( flappy_bird_sprite );

					restart_game_color_change = false;	//reset, true if the player restarts the game
					//start_game = false;	//used for displaying how to play again
				}

				//cout << sawblade_sprite[i].getRotation() << endl;
			}

			sawblade_clock.restart();	//resets because all the sawblades have been updated


			//updates the lightning animation
			for(int i = 0; i < lightning.size(); i++)
			{
				//updates the current lightning animation
				animation.update_loop( i, lightning_animation_limit, lightning );
			}


		if( update == true )
		{
			if( (sf::Keyboard::isKeyPressed( sf::Keyboard::Space ) || sf::Mouse::isButtonPressed( sf::Mouse::Right) ) && jump_clock.getElapsedTime() >= jump_limit )	//flappy bird jumps if it's been long enough!
			{
				jump_clock.reset();	//restarts so that the gravity decreases on flappy bird
				jump = true;	//flappy bird jumped :D
				jump_sound.play();

			}


			if( jump == true )
			{
				if( jump_velocity.y + (jump_clock.getElapsedTime() * gravity.y) < 0.0 ) //the jump is still in effect
				{
					//makes flappy bird jump
					flappy_bird_sprite.setPosition( flappy_bird_sprite.getPosition().x, flappy_bird_sprite.getPosition().y + (jump_clock.getElapsedTime() * gravity.y) + jump_velocity.y );
				}

				else
				{
					jump = false;	//reset since the jump effect wore off
					jump_clock.reset();	//used to make gravity act more natural. Without this, flappy bird drops fast after the jump wears off
				}
			}

			else
			{
				//gravity effects
				flappy_bird_sprite.setPosition( flappy_bird_sprite.getPosition().x, flappy_bird_sprite.getPosition().y + (jump_clock.getElapsedTime() * gravity.y ) );
			}
		}


			window.clear();

			window.draw( background_sprite );

			//draw bars
			for(int i = 0; i < bar_sprite.size(); i++)
			{
				window.draw( bar_sprite[i] );
			}

			//draws the lightning
			for(int i = 0; i < lightning.size(); i++)
			{
				animation.draw( i, window, lightning );
			}

			//draw sawblades
			for(int i = 0; i < sawblade_sprite.size(); i++)
			{
				window.draw( sawblade_sprite[i] );
			}

			window.draw( flappy_bird_sprite );

			window.draw( score_text );


			//cout << "update: " << update << endl;
			//cout << "start game: " << start_game << endl << endl;

			if( update == false && start_game == true && flappy_bird_alive == true)	//game is paused
			{
				window.draw( paused_text );	//draws 'paused' to the screen
			}

			else if( update == false && start_game == false )	//game hasn't started
			{
				window.draw( highscore_text );
				window.draw( mute_text );
				window.draw( start_game_text );
				window.draw( start_game_instructions1 );
				window.draw( start_game_instructions2 );
			}

			//the player has died
			else if( update == false && start_game == true && flappy_bird_alive == false )
			{
				if( death_message_selected == false )	//the death message hasn't been selected
				{
					current_death_message = rand() % number_of_death_messages;	//finds the death message to use
					death_message_selected = true;	//sets it to true so it won't keep changing the message

					death_text.setString( death_messages[current_death_message] );	//sets the new death message
					death_text.setPosition( window.getSize().x / 4.0, window.getSize().y / 3.0 );
				}

			}

			//draws if the player is dead and the death message has been selected
			if( flappy_bird_alive == false && death_message_selected == true )
			{
				//window.draw( death_text );	//draws the text to the screen

				window.draw( highscore_text );
				window.draw( mute_text );
				window.draw( restart_text );

				window.draw( start_game_instructions1 );
				window.draw( start_game_instructions2 );
			}

			window.display();

	}


    return 0;
}