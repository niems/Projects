#ifndef PHYSICS_H
#define PHYSICS_H

#include <iostream>
#include <SFML/Graphics.hpp>
#include <vector>
//#include "Character.h"
using namespace std;

class Physics
{
private:
	sf::FloatRect bounding_box1;
	sf::FloatRect bounding_box2;

public:
	bool collisionDetection(sf::Sprite body1, sf::Sprite body2);	//returns true if a collision detection occurred
	bool collisionDetection(sf::Vector2f body1_position, sf::Vector2f body1_dimensions, sf::Vector2f body2_position, sf::Vector2f body2_dimensions);	//this is only used if the image is being cropped, which means the dimensions need to be taken into account
	
	//objects will be bound to the size of the background image.  This is NOT the same as being bound to the camera view.
	//this will be used for the player to ensure he doesn't walk off the map
	bool offMap(sf::Vector2f object_position, sf::Vector2f object_dimensions, sf::Vector2f background_dimensions);

	//off only the left side of the map
	bool offMapLeft(sf::Vector2f object_position, sf::Vector2f object_dimensions, sf::Vector2f background_dimensions);

	//void offMapCharacterReset(int i, sf::Vector2f background_dimensions, Character &entity);

	//this will be used for projectiles to delete them when they fly off screen
	bool offScreen(sf::Vector2f object_position, sf::Vector2f object_dimensions, sf::View &camera_view, sf::RenderWindow &App);

};

#endif
