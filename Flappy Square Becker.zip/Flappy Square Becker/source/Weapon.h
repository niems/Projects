#ifndef WEAPON_H
#define WEAPON_H

#include "Animation.h"
#include "Health.h"
#include <SFML\Graphics.hpp>
#include <vector>

class Weapon
{
private:
	float distance;
	float elapsed_time;					    //holds the elapsed time for the projectile
	vector<int> damage;						//amount of damage that is caused by the current weapon

	sf::Clock velocity_clock;			     //used to update the weapons position based on the speed and the time elapsed.
	vector<sf::Vector2f> position;	        //holds the current weapons position
	vector<sf::Vector2f> speed;		       //holds the current weapons move speed
	vector<sf::Vector2f> trajectory;	  //holds the current trajectory of the weapon
	
	//used for animation class
	vector<sf::Vector2f> texture_dimension;	  //holds the width and height for the current texture
	vector<const int> row_sprites;			 //holds the row sprites for the current entity
	vector<const int> column_sprites;		//holds the column sprites for the current entity
	
	vector<sf::Clock> update_clock;	 //used for the animation class to see if it's been long enough for the next animation
	vector<sf::Clock> special_clock;	//used for special weapons that use a timer to produce an effect
	vector<sf::Vector2f> source;	//keeps track of where the crop is for the current sprite
	vector<sf::Sprite> sprite;	   //used to store the entity sprite

	vector<int> type;	//not useful for most stuff. This was a quick fix for the clouds.

	bool is_sprite_centered;		//this is used to help the Health class determine how to place the bar by accomodating if the sprite has been centered or not


public:
	//used for every new weapon/projectile.
	void initialize( const int &r_sprites, const int &c_sprites, sf::Texture &texture, sf::Vector2f weapon_start_position, sf::Vector2f weapon_end_position, sf::Vector2f weapon_speed, int weapon_damage );

	void update_projectile_position(int i);			//updates the current projectile if it's moving in a straight line
	void update_follow_projectile_position(int i); //updates the current projectile if it's following an entity(the player or an enemy)

	void scale(sf::Vector2f new_size, sf::Vector2f old_size);	//scales everything correctly when the screen size changes //DON'T USE THIS ONE!

	void scale(int i, sf::Vector2f new_size, sf::Vector2f old_size);	//scales the specific entity
	
	void restartVelocityClock();
	
	void setPosition(int i, sf::Vector2f e_position);	//sets the current position of the sprite
	void setPosition(int i, sf::Vector2f e_position, float angle);	//sets the current position of the sprite
	void rotate(int i, float rotate_angle);	//rotates the current sprite 'rotate_angle' amount
	void centerSprite(int i);
	void setSpriteColor(int i, sf::Color new_color);	//sets the new sprite color, this will also allow the transparency to change
	void setOrigin(int i, sf::Vector2f new_origin);		//sets new origin for the sprite
	void setRotation(int i, float new_angle);		//the new angle to rotate the sprite to
	void setSource(int i, sf::Vector2f new_source);	//sets the new source for the sprite

	void setType(int i, int new_type);	//sets the current type ( quick fix for clouds )

	void erase(int i);	//erases the current weapon
	void eraseAll();	//erases all the weapons in the instance

	int size();	//returns the number of weapons there are

	
	sf::Clock getVelocityClock();
	sf::Vector2f getTextureDimension(int i);
	sf::Vector2f getDimensions(int i);	//returns the dimensions of the current entity that's show, not the sprite sheet dimensions.
	sf::Vector2f getPosition(int i);
	sf::Sprite getSprite(int i);
	int getDamageAmount(int i);	//returns the amount of damage the current weapon causes
	sf::Clock& getSpecialClock(int i);	//returns the special ability clock

	int getType(int i);	//returns current type of weapon( quick fix for clouds )

	friend Animation;	//allows the animation class to use the private members of this class.
	friend Health;		//allows the health class to use the private members of this class.
};


#endif