#include "Physics.h"
//#include "Character.h"
#include <iostream>
#include <cmath>
using namespace std;


bool Physics::collisionDetection(sf::Sprite body1, sf::Sprite body2)
{
	bounding_box1 = body1.getGlobalBounds();
	bounding_box2 = body2.getGlobalBounds();

	if( bounding_box1.intersects( bounding_box2 ) )	
	{
		return true;	//returns true if a collision occurs.
	}

	return false;	//no collision occurred
}


bool Physics::collisionDetection(sf::Vector2f body1_position, sf::Vector2f body1_dimensions, sf::Vector2f body2_position, sf::Vector2f body2_dimensions)
{
	if( ( (body1_position.x + body1_dimensions.x) < body2_position.x ) || ( body1_position.x > ( body2_position.x + body2_dimensions.x ) ) )
	{
		return false;
	}

	if( ( (body1_position.y + body1_dimensions.y) < body2_position.y ) || ( body1_position.y > ( body2_position.y + body2_dimensions.y ) ) )
	{
		return false;
	}

	return true;	//no collision occurred
}



bool Physics::offMap(sf::Vector2f object_position, sf::Vector2f object_dimensions, sf::Vector2f background_dimensions)
{
	if( object_position.x + object_dimensions.x < 0 || object_position.x > background_dimensions.x )
	{
		return true;
	}

	if( object_position.y + object_dimensions.y < 0 || object_position.y > background_dimensions.y )
	{
		return true;	//off screen on the y axis
	}

	return false;	//not off screen
}

bool Physics::offMapLeft(sf::Vector2f object_position, sf::Vector2f object_dimensions, sf::Vector2f background_dimensions)
{
	if( object_position.x + object_dimensions.x < 0 )
	{
		return true; //off the left side on the x axis
	}

	return false;	//not off screen
}


/*
void Physics::offMapCharacterReset(int i, sf::Vector2f background_dimensions, Character &entity)
{

	if( entity.getPosition(i).x < 0 )	//off the left side of the screen
	{
		entity.setPosition( i, sf::Vector2f(0, entity.getPosition(i).y) );
	}

	else if( entity.getPosition(i).x + entity.getDimensions(i).x > background_dimensions.x )	//off the right side of the screen
	{
		entity.setPosition( i, sf::Vector2f( background_dimensions.x - entity.getDimensions(i).x, entity.getPosition(i).y ) );
	}

	if( entity.getPosition(i).y < 0 )	//off the top of the screen
	{
		entity.setPosition( i, sf::Vector2f( entity.getPosition(i).x, 0 ) );
	}

	else if( entity.getPosition(i).y + entity.getDimensions(i).y > background_dimensions.y )	//off the bottom of the screen
	{
		entity.setPosition(i, sf::Vector2f( entity.getPosition(i).x, background_dimensions.y - entity.getDimensions(i).y ) );
	}

}
*/


bool Physics::offScreen(sf::Vector2f object_position, sf::Vector2f object_dimensions, sf::View &camera_view, sf::RenderWindow &App)
{
	if( ( object_position.x + object_dimensions.x ) < ( camera_view.getCenter().x - (App.getSize().x / 2) ) || object_position.x > ( camera_view.getCenter().x + (App.getSize().x / 2) ) )
	{
		return true;	//off screen on the x axis
	}


	if( ( object_position.y + object_dimensions.y ) < ( camera_view.getCenter().y - (App.getSize().y / 2) ) || object_position.y > ( camera_view.getCenter().y + (App.getSize().y / 2) ) )
	{
		return true;	//off screen on the y axis
	}

	return false;	//not off screen
}

