#include "Weapon.h"
#include <SFML\Graphics.hpp>
#include <vector>
#include <cmath>
using namespace std;


void Weapon::initialize( const int &r_sprites, const int &c_sprites, sf::Texture &texture, sf::Vector2f weapon_start_position, sf::Vector2f weapon_end_position, sf::Vector2f weapon_speed, int weapon_damage )
{
	sf::Clock temp_clock;	//used for initialization
	sf::Clock temp_clock2;
	sf::Sprite temp_sprite;	//used for initialization

	temp_sprite.setTexture( texture );
	row_sprites.push_back( r_sprites );
	column_sprites.push_back( c_sprites );
	texture_dimension.push_back( sf::Vector2f( texture.getSize().x, texture.getSize().y ) );
	update_clock.push_back( temp_clock );
	special_clock.push_back( temp_clock2 );
	source.push_back( sf::Vector2f( 0.0, 0.0 ) );
	sprite.push_back( temp_sprite );
	damage.push_back( weapon_damage );

	type.push_back(0);	//default set

	sprite.back().setTextureRect( sf::IntRect( source.back().x, source.back().y, source.back().x + ( texture_dimension.back().x / column_sprites.back() ), source.back().y + ( texture_dimension.back().y / row_sprites.back() ) ) );
	
	position.push_back(weapon_start_position);
	speed.push_back(weapon_speed);
	sprite.back().setPosition( position.back() );

	//finds the distance between the starting and ending position of the weapon
	distance = sqrt( pow( weapon_end_position.x - weapon_start_position.x, 2 ) + pow( weapon_end_position.y - weapon_start_position.y, 2 ) );

	//finds how much the projectile will be traveling in the x and y direction
	trajectory.push_back( sf::Vector2f( ( weapon_end_position.x - weapon_start_position.x ) / distance, ( weapon_end_position.y - weapon_start_position.y ) / distance ) );
}


void Weapon::update_projectile_position(int i)
{
	position[i].x += speed[i].x * velocity_clock.getElapsedTime().asSeconds() * trajectory[i].x;
	position[i].y += speed[i].y * velocity_clock.getElapsedTime().asSeconds() * trajectory[i].y;
}


void Weapon::scale(sf::Vector2f new_size, sf::Vector2f old_size)
{
	//finds the scale amount
	sf::Vector2f scale;
	scale.x = new_size.x / old_size.x;
	scale.y = new_size.y / old_size.y;

	for(int i = 0; i < position.size(); i++)	//scales everything needed
	{
		position[i].x *= scale.x;
		position[i].y *= scale.y;

		sprite[i].scale(scale.x, scale.y);
	}

}


void Weapon::scale(int i, sf::Vector2f new_size, sf::Vector2f old_size)
{
	//finds the scale amount
	sf::Vector2f scale;
	scale.x = new_size.x / old_size.x;
	scale.y = new_size.y / old_size.y;

	sprite[i].scale(scale.x, scale.y);
}


void Weapon::restartVelocityClock()
{
	velocity_clock.restart();
}


void Weapon::setPosition(int i, sf::Vector2f e_position)
{
	position[i] = e_position;
	sprite[i].setPosition( position[i] );
}


void Weapon::setPosition(int i, sf::Vector2f e_position, float angle)
{
	position[i] = e_position;
	sprite[i].setRotation( angle );
	sprite[i].setPosition( position[i] );
}


void Weapon::rotate(int i, float rotate_angle)
{
	sprite[i].rotate( rotate_angle );
}


void Weapon::centerSprite(int i)
{
	sprite[i].setOrigin( (texture_dimension[i].x / column_sprites[i]) / 2.0, (texture_dimension[i].y / row_sprites[i]) / 2.0 );
	is_sprite_centered = true;

}

void Weapon::setSpriteColor(int i, sf::Color new_color)
{
	sprite[i].setColor( new_color );
}

void Weapon::setOrigin(int i, sf::Vector2f new_origin )
{
	sprite[i].setOrigin( new_origin );
}

void Weapon::setRotation(int i, float new_angle)
{
	sprite[i].setRotation( new_angle );
}


void Weapon::setSource(int i, sf::Vector2f new_source)
{
	source[i] = new_source;
}


void Weapon::setType(int i, int new_type)
{
	type[i] = new_type;
}

void Weapon::erase(int i)
{
	row_sprites.erase( row_sprites.begin() + i );
	column_sprites.erase( column_sprites.begin() + i );
	texture_dimension.erase( texture_dimension.begin() + i );
	update_clock.erase( update_clock.begin() + i );
	special_clock.erase( special_clock.begin() + i );
	source.erase( source.begin() + i );
	sprite.erase( sprite.begin() + i );
	damage.erase( damage.begin() + i );
	position.erase( position.begin() + i );
	speed.erase( speed.begin() + i );
	trajectory.erase( trajectory.begin() + i );
}


void Weapon::eraseAll()
{
	for(int i = row_sprites.size() - 1; i > -1; i--)
	{
		row_sprites.erase( row_sprites.begin() + i );
		column_sprites.erase( column_sprites.begin() + i);
		texture_dimension.erase( texture_dimension.begin() + i);
		update_clock.erase( update_clock.begin() + i);
		special_clock.erase( special_clock.begin() + i );
		source.erase( source.begin() + i);
		sprite.erase( sprite.begin() + i);
		damage.erase( damage.begin() + i);
		position.erase( position.begin() + i);
		speed.erase( speed.begin() + i);
		trajectory.erase( trajectory.begin() + i);
	}
}


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

int Weapon::size()
{
	return( sprite.size() );
}


sf::Clock Weapon::getVelocityClock()
{
	return( velocity_clock );
}


sf::Vector2f Weapon::getTextureDimension(int i)
{
	return( texture_dimension[i] );
}


sf::Vector2f Weapon::getDimensions(int i)
{
	return( sf::Vector2f( texture_dimension[i].x / static_cast<float>(column_sprites[i]), texture_dimension[i].y / static_cast<float>(row_sprites[i]) ) );
}


sf::Vector2f Weapon::getPosition(int i)
{
	return( position[i] );
}


sf::Sprite Weapon::getSprite(int i)
{
	return( sprite[i] );
}


int Weapon::getDamageAmount(int i)
{
	return( damage[i] );
}


sf::Clock& Weapon::getSpecialClock(int i)
{
	return( special_clock[i] );
}


int Weapon::getType(int i)
{
	return( type[i] );
}
