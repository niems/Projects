#ifndef ANIMATION_H
#define ANIMATION_H

#include <vector>
#include <SFML/Graphics.hpp>
#include <iostream>

//class Character;
class Weapon;

using namespace std;


class Animation
{
public:
	/*
	//for the character class
	void update_loop(int i, float animation_limit, Character &entity);				   //updates the current looping animation and sets the new sprite position
	bool update_runthrough(int i, float animation_limit, Character &entity);	      //updates the current runthrough animation and sets the new sprite position. Returns 'false' if the animation has finished
	void update_character(int i, float animation_limit, Character &entity);	     //updates the current character animation and sets the new sprite position
	void update_character_reverse(int i, float animation_limit, Character &entity);//updates the current character animation in reverse
	void update_enemy(int i, float animation_limit, Character &entity);	  //updates the current enemy animation


	void draw(int i, sf::RenderWindow &App, Character &entity);	//draws the current sprite to the window
	*/

	//for the weapon class
	void update_loop(int i, float animation_limit, Weapon &entity);		    //updates the current looping animation and sets the new sprite position
	bool update_runthrough(int i, float animation_limit, Weapon &entity);  //updates the current runthrough animation and sets the new sprite position. Returns 'false' if the animation has finished
	bool update_runthrough_reverse(int i, float animation_limit, Weapon &entity);

	void draw(int i, sf::RenderWindow &App, Weapon &entity);	//draws the current sprite to the window

};

#endif